<?php
require_once("config/class_object.php");
include_once("header_and_footer/headers.php");
?>
    <style>
/*.position {
    position: fixed;
    bottom: 0;
}*/
    </style>
    <div class="container-fluid my-2">
        <div class="row">
            <div class="col-12">
                <h1 class=" bg-dark bg-gradient text-light rounded text-center">Feedback</h1>
                <div class="text-center">
                    <!-- <img src="https://images.coachingforleaders.com/cb:rKEX.32abc/w:auto/h:auto/q:mauto/f:best/ig:avif/http://coachingforleaders.com/wp-content/uploads/2013/05/feedback.png" class="img-thumbnail rounded-pill" style="height:150px" alt=""> -->
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-3"></div>
            <div class="col-sm-6">
                <p class="rounded p-1 text-center text-white" style="background-color: <?=$_REQUEST['color']??""?>;"><?=$_REQUEST['msg']??""?></p>
                <form action="process.php" method="POST" enctype="multipart/form-data">
                <?php
                if(isset($_SESSION['user'])){
                    $query = "SELECT * FROM user WHERE email = '".$_SESSION['user']['email']."'";
                    $result = $user->execute_query($query);
                    if ($result->num_rows>0){
                        $row=mysqli_fetch_assoc($result);
                        extract($row);
                ?>
                    <div class="form-group input-group my-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text py-3"> <i class="fa-solid fa-user"></i> </span>
                        </div>
                        <input name="full_name" class="form-control" placeholder="Full name" type="text" value="<?=$first_name." ".$last_name?>" readonly>
                    </div>
                    <!-- form-group// -->
                    <div class="form-group input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text py-3"> <i class="fa fa-envelope"></i> </span>
                        </div>
                        <input name="feedback_email" class="form-control" placeholder="Email address" type="email" value="<?=$email;?>" readonly>
                    </div>
                    <?php
                         }
                }
                    else{
                    ?>
                    <div class="form-group input-group my-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text py-3"> <i class="fa-solid fa-user"></i> </span>
                        </div>
                        <input name="full_name" class="form-control" placeholder="Full name" type="text" required>
                    </div>
                    <!-- form-group// -->
                    <div class="form-group input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text py-3"> <i class="fa fa-envelope"></i> </span>
                        </div>
                        <input name="feedback_email" class="form-control" placeholder="Email address" type="email" required>
                    </div>
                    <?php
                        
                     }
                    ?>
                    <div class="form-group input-group my-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text py-5"> <i class="fa-solid fa-message"></i> </span>
                        </div>
                        <textarea name="feedback" class="form-control" placeholder="Feedback" type="text" required></textarea>
                    </div>
                    <!-- form-group// -->
                    <div class="form-group">
                        <button type="reset" class="btn btn-danger btn-block"> Cancel </button>
                        <button type="submit" name="send_feedback" value="feedback" class="btn btn-primary btn-block"> Send Feedback
                        </button>

                    </div> <!-- form-group// -->
                </form>
            </div>
            <div class="col-sm-3"></div>
        </div>
    </div>
    <?php
include_once("header_and_footer/footers.php");
?>