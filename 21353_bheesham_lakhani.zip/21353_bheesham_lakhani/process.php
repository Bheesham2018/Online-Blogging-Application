<?php
session_start();
require_once("config/class_object.php");
// echo "<pre>";
// print_r($_REQUEST);
// print_r($_FILES);
// echo "</pre>";
// die;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

$mail = new PHPMailer();

$mail->isSMTP();

$mail->Host = 'smtp.gmail.com';
$mail->Port = 587;
$mail->SMTPAuth = true;
$mail->Username = 'bheeshamkumar2018@gmail.com';
$mail->Password = 'hplupexwxekzrhub';
$mail->setFrom('bheeshamkumar2018@gmail.com', 'Bheesham');
date_default_timezone_set("Asia/Karachi");
extract($_REQUEST);
extract($_FILES);
// .........................................register_user...................................................
if(isset($register_user)){
		$query = "SELECT * FROM user  WHERE email = '".$email."'";
		$check_email = $user->execute_query($query);
		if($check_email->num_rows>0){
			header("location:register_from.php?msg=This Email is Already Registered&color=red");
		}
		else{
			$dob= strtotime($_REQUEST['date_of_birth']);
			$now = time();
			$age=$now - $dob;
			// echo $age;
			$a = $age/60/60/24/365.25;
			$age_is = floor($a);
			if($age_is>=15){
			$dir = "uploads";
			if(!is_dir($dir)){
				if(!mkdir($dir)){
					echo "Directory could not be created....!";
				}
			}
			//mailing
				$name = $first_name." ".$last_name;
				$mail->addReplyTo("bk23877284@gmail.com", "Bheesham_k");
				$mail->addAddress($email , $name );
				$mail->Subject = 'Notification';
				$mail->msgHTML(" Welcome ".$first_name." ".$last_name."\r\nYour account are Successfully Created , Your Request are in pending And Status is inactive \r\n ");
			//mailing

			$profile_picture = $_FILES['profile_pic']['name'];
			$profile_picture_path_name = $_FILES['profile_pic']['tmp_name'];
			$profile_path = $dir."/".time()."_".$profile_picture;
			if($_FILES['profile_pic']["size"]<=1000000){
				if(move_uploaded_file($profile_picture_path_name, $profile_path)){
					$date_of_birth = date('Y-m-d', strtotime($date_of_birth));
					$query="INSERT INTO user VALUES (Null,2,'".$first_name."','".$last_name."','".$email."','".$password."','".$gender."','".$date_of_birth."','".$profile_path."','".$address."','Pending','Inactive',null,Null)";
						// echo $query;
						// die;
					$result = $user->execute_query($query);
					if (!$mail->send()) {
						header("location:register_form.php?msg=Data send Failed...&color=red");
						exit;
						}
					if($result){
						header("location:login.php?msg=Registraction Successfull Please Check Your Email&color=green&email=$email");
					}
					else{
						header("location:register_form.php?msg=Registraction Failed&color=red");
					}
					}
					else{
						header("location:register_form.php?msg=Image Size is Greater than 1 mb&color=red");
					}
				}
		}
		else{
			header("location:register_form.php?msg=Your age is Less Than 15 Try Again...!&color=red");
		}
		
	}
}
// .........................................register_user...................................................

//........................................user_login...............................................
elseif(isset($login)){
	$query = "SELECT * FROM user WHERE email = '".$email."' && password = '".$password."'";
	// echo $query;
	// die;
	$result = $user->execute_query($query);
	if($result->num_rows>0){
		$row = mysqli_fetch_assoc($result);
			extract($row);
			if($role_id==1){
				// echo "Done";
				if($is_active=="Active"){
					$_SESSION['user'] = $row;
					// echo "done";
					setcookie('admin_image',$user_image);
					setcookie("admin_name",$first_name." ".$last_name);
					header("location:admin_dashboard.php?title=Admin_page");
				}
				// die;
				else{
					header("location:login.php?msg=Your account is Inactive&color=red");
				}
			}
			elseif ($role_id==2) {
				if ($is_approved=="Approved") {
					if ($is_active=="Active") {
						$_SESSION['user'] = $row;
						setcookie("user_image",$user_image);
						setcookie("user_name",$first_name." ".$last_name);
						header("location:index.php?title=Home");
					}
					else{
						header("location:login.php?msg=Your account is Inactive&color=red");
					}
				}
				elseif($is_approved=="Rejected"){
					header("location:login.php?msg=Your Request has been Rejected Try again...&color=red");
				}
				else{
					header("location:login.php?msg=Your Request are in Pending&color=red");
				}
			}
			else{
			header("location:login.php?msg=incorrect email and password Try again&color=red");
			}
		}
	else{
		header("location:login.php?msg=Incorrect Email and Password&color=red");
	}
}
//........................................user_login...............................................

// ....................................register by admin.............................................
elseif(isset($admin_register)){
	// echo "<pre>";
	// print_r($_REQUEST);
	// print_r($_FILES);
	// echo "</pre>";
	// die;
	$query = "SELECT * FROM user  WHERE email = '".$email."' ";
	$result = $user->execute_query($query);
	if($result->num_rows>0){
		header("location:admin_dashboard.php?msg=This Email is Already Registered&color=red");
	}
	if($age>=15){
		$dob= strtotime($_REQUEST['date_of_birth']);
		$now = time();
		$age=$now - $dob;
		// echo $age;
		$a = $age/60/60/24/365.25;
		$age_is = floor($a);
	$dir = "uploads";
      if(!is_dir($dir)){
         if(!mkdir($dir)){
            echo "Directory could not be created....!";
         }
      }
	  $name = $first_name." ".$last_name;
		$mail->addReplyTo("bk23877284@gmail.com", "Bheesham_k");
		$mail->addAddress($email , $name );
		$mail->Subject = 'Notification';
		$mail->msgHTML(" Welcome ".$first_name." ".$last_name."\r\nYour account are Successfully Created , Now you may login \r\n ");
      $profile_picture = $_FILES['profile_pic']['name'];
      $profile_picture_path_name = $_FILES['profile_pic']['tmp_name'];
      $profile_path = $dir."/".time()."_".$profile_picture;
      if($_FILES['profile_pic']["size"]<=1000000){
     	 if(move_uploaded_file($profile_picture_path_name, $profile_path)){
			$date_of_birth = date('Y-m-d', strtotime($date_of_birth));
      		$query="INSERT INTO user VALUES (Null,'".$select_role."','".$first_name."','".$last_name."','".$email."','".$password."','".$gender."','".$date_of_birth."','".$profile_path."','".$address."','Aproved','Active',null,Null)";
      		$result = $user->execute_query($query);
			if(!$mail->send()){
				header("location:admin_dashboard.php?email did not send &color=green&title=Admin_Page");
			}
	      	if($result){
	      		header("location:admin_dashboard.php?msg=Registraction Successfully And Email Send Successfully&color=green&title=Admin_Page");
	      	}
	      	else{
	      		header("location:admin_dashboard.php?msg=Registraction Failed&color=red&title=Admin_Page");
	      	}
      	}
      	else{
      		header("location:admin_dashboard.php?msg=Image Size is Greater than 1 mb&color=red&title=Admin_Page");
      	}
      }
   }
   else{
   	header("location:admin_dashboard?msg=Age is less than 15 Try Again...!&color=red&title=Admin_Page");
   }
}
// ....................................register by admin.............................................

// ..................................create blog.......................................................
elseif(isset($create_blog)){
	// echo "<pre>";
	// print_r($_REQUEST);
	// print_r($_FILES);
	// echo "</pre>";
	// die;
	$dir = "blog_images";
      if(!is_dir($dir)){
         if(!mkdir($dir)){
            echo "Directory could not be created....!";
         }
      }
      $blog_picture = $_FILES['blog_image']['name'];
      $blog_picture_path_name = $_FILES['blog_image']['tmp_name'];
      $blog_picture_path = $dir."/".time()."_".$blog_picture;
      $user_id = $_SESSION['user']['user_id'];
  	 	// echo $user_id;
  	 	// die;
  	 	if(isset($post_per_page)&& $post_per_page<=0){
  	 		header("location:admin_dashboard.php?msg=Post Per page must not be less Than or Equal to zero&color=red&title=Admin_Page");
  	 	}else{
     	 if(move_uploaded_file($blog_picture_path_name, $blog_picture_path)){
      		$query="INSERT INTO blog VALUES (null,'".$user_id."','".$blog_title."','".$post_per_page."','".$blog_picture_path."','"."Active"."',null,Null)"; 
      			// echo $query;
      			// die();
      		$result = $user->execute_query($query);
	      	if($result){
	      		header("location:admin_dashboard.php?msg=Blog Created Successfully&color=green&title=Admin_Page");
	      	}
	      	else{
	      		header("location:admin_dashboard.php?msg=Creation Failed&color=red&title=Admin_Page");
	      	}
      	}
      }
}
elseif(isset($add_category)){
	$category_description = htmlspecialchars($category_description);
	$query = "INSERT INTO category VALUES (null,'".$category_title."','".$category_description."','Active',null,null)";
	echo $query;
	$result = $user->execute_query($query);
	if($result){
		header("location:admin_dashboard.php?msg=Category Added Successfully&color=green&title=Admin_Page");
	}
	else{
		header("location:admin_dashboard.php?msg=Creation Failed&color=red&title=Admin_Page");
	}
}
// ..................................create blog.......................................................

// ..................................create post.....................................
elseif(isset($add_post)){
	extract($_REQUEST);
	extract($_FILES);
	// echo "<pre>";
	// print_r($_REQUEST);
	// print_r($_FILES);
	// echo "</pre>";
	// die;
	$get_email_query ="SELECT user.email,user.first_name AS f_name,user.last_name AS l_name ,following_blog.follower_id, blog.blog_title FROM USER JOIN blog ON user.user_id=blog.user_id JOIN following_blog ON user.user_id=following_blog.follower_id WHERE blog.blog_id ='".$select_blog."' && following_blog.status='Followed'"; 
	$get_email=$user->execute_query($get_email_query);
	if($get_email->num_rows>0){
		while($rows= mysqli_fetch_assoc($get_email)){
			extract($rows);
			$name = $f_name." ".$l_name;
			$mail->addReplyTo("bk23877284@gmail.com", "Bheesham_k");
			$mail->addBCC($email , $name );
			$mail->Subject = 'Notification';
			$mail->msgHTML(" Hello ".$f_name." ".$l_name."\r\n New Post are Uploaded On <b>".$blog_title."</b>\r\n Post title is ".$post_title);
			$mail->send();
		}
	}
	$dir_post_image = "post_featured_image";
      if(!is_dir($dir_post_image)){
         if(!mkdir($dir_post_image)){
            echo "Directory could not be created....!";
         }
      }
	  $featured_image = $_FILES['post_image']['name'];
      $featured_image_path_name = $_FILES['post_image']['tmp_name'];
      $featured_image_path = $dir_post_image."/".time()."_".$featured_image;
	  if(move_uploaded_file($featured_image_path_name, $featured_image_path)){
		$connection = mysqli_connect("localhost","root","","21353_bheesham_lakhani");
		$post_summary = htmlspecialchars($post_summary);
		$post_desc = htmlspecialchars($post_desc);
		$post_title  = htmlspecialchars($post_title);
		$query ="INSERT INTO post VALUES (Null,'".$select_blog."','".$post_title."','".$post_summary."','".$post_desc."','".$featured_image_path."','Active','".$comment."',null,Null)";
		$result = mysqli_query($connection, $query);
		$last_id = mysqli_insert_id($connection);
	}
	if(isset($_FILES['post_attachment'])){
		if(!$_FILES['post_attachment']['name'][0] == ""){
		$dir_attachment = "post_attachement";
		if(!is_dir($dir_attachment)){
		   if(!mkdir($dir_attachment)){
			  echo "Directory could not be created....!";
		   }
		}
		$i=0;
		foreach($_FILES['post_attachment']['name'] as $key => $value) {
			$file_extention = explode('.',$_FILES['post_attachment']['name'][$key]);
			$files_ext =  $file_extention[1];
			$attachment_name = $file_name[$i];
	 		$attachment_path_name = $_FILES['post_attachment']['tmp_name'][$key];
	 		$attachment_path = $dir_attachment."/".rand()."-".$file_name[$i].'.'.$files_ext;
			// echo $attachment_name;
			if( move_uploaded_file($attachment_path_name, $attachment_path)){
				$query = "INSERT INTO post_atachment VALUES(Null,'".$last_id."','".$attachment_name."','".$attachment_path."','Active',null,Null)";
				// echo $query; 
				// die;
				$result = $user->execute_query($query);
			}
			$i++;
		}
		// die;
		foreach($Multiple as $key => $value){
			$query = "INSERT INTO post_category VALUES(Null,'".$last_id."','".$value."',null,Null)";
			// echo $query;
			// die;
			$result = $user->execute_query($query);
		}
			if($result){
				header("location:admin_dashboard.php?msg=Post,post_category and Attachment are added Successfully&color=green&title=Admin_Page");
			}
			else{
				header("location:admin_dashboard.php?msg=Creation Failed&color=red&title=Admin_Page");
			}
	}
	}
}
// ..................................create post.....................................

//....................................feedback..........................................
elseif(isset($send_feedback)){
	// echo "<pre>";
	// print_r($_REQUEST);
	// print_r($_FILES);
	// echo "</pre>";
	// die;
	$query = "SELECT * FROM user WHERE email = '".$feedback_email."'";
	$result = $user->execute_query($query);
	if ($row = mysqli_fetch_assoc($result)) {
		extract($row);
	}
	// print_r($row);
	// die;
	$user_id = $user_id??"Null";
	// echo $user_id;
	// die();
	$query = "INSERT INTO user_feedback VALUES (null,$user_id,'".$full_name."','".$feedback_email."','".$feedback."',null) ";
	$result = $user->execute_query($query);
	if($result){
		$query = "SELECT * FROM user WHERE role_id=1";
		$result=$user->execute_query($query);
		if($result->num_rows>0){
			while($row=mysqli_fetch_assoc($result)){
				extract($row);
				$name = $first_name." ".$last_name;
				$mail->addReplyTo("bk23877284@gmail.com", "Bheesham_k");
				$mail->addBCC($email , $name );
				$mail->Subject = 'Notification';
				$mail->msgHTML("New Feedback are Given by ".$full_name." and email is ".$feedback_email." \r\n ");
				$mail->send();
			}
		}
		header("location:feedback_response_page.php?title=FeedBack_Response");
	}
	else{
		header("location:feedback.php?msg=Feedback Did Not Send&color=red&title=Feedback");
	}
}

elseif (isset($update_blog)) {
	echo "<pre>";
	print_r($_REQUEST);
	print_r($_FILES);
	echo "</pre>";
	extract($_FILES);
	extract($_REQUEST);
	if (isset($_FILES['new_image']['name'])&& $_FILES['new_image']['name']!="") {
		$dir = "blog_images";
		if(!is_dir($dir)){
			if(!mkdir($dir)){
				echo "Directory could not be created....!";
			}
		}
		$blog_picture = $_FILES['new_image']['name'];
		$blog_picture_path_name = $_FILES['new_image']['tmp_name'];
		$blog_picture_path = $dir."/".time()."_".$blog_picture;
		if(move_uploaded_file($blog_picture_path_name, $blog_picture_path)){
			$query="UPDATE blog SET blog_title = '".$blog_title."', post_per_page='".$post_per_page."', blog_background_image = '".$blog_picture_path."', updated_at = NOW() WHERE blog_id = '".$blog_id."'"; 
			echo $query;
			die;
			$result = $user->execute_query($query);
			if($result){
				header("location:admin_dashboard.php?msg=Blog id $blog_id has been Updated Successfully&color=green&title=Admin_Page");
			}
			else{
				header("location:admin_dashboard.php?msg=Updation Failed&color=red&title=Admin_Page");
			}
		}
	}
	else{
		$query = "UPDATE blog SET blog_title = '".$blog_title."', post_per_page='".$post_per_page."', blog_background_image = '".$old_image."', updated_at = NOW() WHERE blog_id = '".$blog_id."'";
		// echo "sdks";
		// die;
		$result = $user->execute_query($query);
		if($result){
			header("location:admin_dashboard.php?msg=Blog id $blog_id has been Updated Successfully&color=green&title=Admin_Page");
		}
		else{
			header("location:admin_dashboard.php?msg=Updation Failed&color=red&title=Admin_Page");
		}
	}

}
elseif(isset($update_category)){
	// extract($_REQUEST);
	$query="UPDATE category SET category_title = '".$category_title."', category_description='".$category_description."', updated_at = NOW() WHERE category_id = '".$category_id."'"; 
			$result = $user->execute_query($query);
			if($result){
				header("location:admin_dashboard.php?msg=Category Id $category_id has been Updated Successfully&color=green&title=Admin_Page");
			}
			else{
				header("location:admin_dashboard.php?msg=Updation Failed&color=red&title=Admin_Page");
			}
}
elseif(isset($edit_user_detail)){
	if(isset($_FILES['new_profile_pic']['name'])&& $new_profile_pic['name']!=""){
		// echo "image";
		$dir = "uploads";
      if(!is_dir($dir)){
         if(!mkdir($dir)){
            echo "Directory could not be created....!";
         }
      }
		$profile_picture = $_FILES['new_profile_pic']['name'];
      $profile_picture_path_name = $_FILES['new_profile_pic']['tmp_name'];
      $profile_path = $dir."/".time()."_".$profile_picture;
		$date_of_birth = date('Y-m-d', strtotime($date_of_birth));
		if($new_profile_pic['size']<=100000){
			if(move_uploaded_file($profile_picture_path_name, $profile_path)){
			$query = "UPDATE user SET role_id = '".$select_role."', first_name = '".$first_name."', last_name ='".$last_name."', email = '".$email."', password = '".$password."', gender = '".$gender."', date_of_birth = '".$date_of_birth."', user_image = '".$profile_path."', address = '".$address."',updated_at = Now() WHERE user_id = '".$user_id_is."' ";
			// echo $query;
			// die;
			setcookie("user_image",$profile_path);
			setcookie("user_name" ,$first_name." ".$last_name);
			$result=$user->execute_query($query);
			if($result){
				header("location:admin_dashboard.php?msg= User_id =".$user_id_is." Has been Updated Successfully&color=green&title=Admin_Page");
				}
				else{
					header("location:admin_dashboard.php?msg= User_id =".$user_id_is." did not Updated&color=red&title=Admin_Page");
				}
			}
		}
		
	}
	else{
		$query = "UPDATE user SET role_id = '".$select_role."', first_name = '".$first_name."', last_name ='".$last_name."', email = '".$email."', password = '".$password."', gender = '".$gender."', date_of_birth = '".$date_of_birth."', user_image = '".$old_user_image."', address = '".$address."',updated_at = Now() WHERE user_id = '".$user_id_is."' ";
		// echo $query;
		setcookie("user_name" ,$first_name." ".$last_name);
		$result = $user->execute_query($query);
		if($result){
			header("location:admin_dashboard.php?msg= User_id =".$user_id_is." Has been Updated Successfully&color=green&title=Admin_Page");
		}
		else{
			header("location:admin_dashboard.php?msg= User_id =".$user_id_is." did not Updated&color=red&title=Admin_Page");
		}
	}
}

elseif(isset($edit_admin_detail)){
	if(isset($_FILES['new_admin_image']['name'])&& $new_admin_image['name']!=""){
		// echo "image";
		$dir = "uploads";
      if(!is_dir($dir)){
         if(!mkdir($dir)){
            echo "Directory could not be created....!";
         }
      }
		$profile_picture = $_FILES['new_admin_image']['name'];
      $profile_picture_path_name = $_FILES['new_admin_image']['tmp_name'];
      $profile_path = $dir."/".time()."_".$profile_picture;
		$date_of_birth = date('Y-m-d', strtotime($date_of_birth));
		if($new_admin_image['size']<=100000){
			if(move_uploaded_file($profile_picture_path_name, $profile_path)){
			$query = "UPDATE user SET first_name = '".$first_name."', last_name ='".$last_name."', email = '".$email."', password = '".$password."', gender = '".$gender."', date_of_birth = '".$date_of_birth."', user_image = '".$profile_path."', address = '".$address."',updated_at = Now() WHERE user_id = '".$admin_id."' ";
			$result=$user->execute_query($query);
			setcookie("admin_image",$profile_path);
			setcookie("admin_name",$first_name." ".$last_name);
			if($result){
				header("location:admin_dashboard.php?msg= User_id =".$admin_id." Has been Updated Successfully&color=green&title=Admin_Page");
				}
				else{
					header("location:admin_dashboard.php?msg= User_id =".$admin_id." did not Updated&color=red&title=Admin_Page");
				}
			}
		}
		
	}
	else{
		$query = "UPDATE user SET  first_name = '".$first_name."', last_name ='".$last_name."', email = '".$email."', password = '".$password."', gender = '".$gender."', date_of_birth = '".$date_of_birth."', user_image = '".$old_admin_image."', address = '".$address."',updated_at = Now() WHERE user_id = '".$admin_id."' ";
		// echo $query;
			setcookie("admin_name",$first_name." ".$last_name);
		$result = $user->execute_query($query);
		if($result){
			header("location:admin_dashboard.php?msg= User_id =".$admin_id." Has been Updated Successfully&color=green&title=Admin_Page");
		}
		else{
			header("location:admin_dashboard.php?msg= User_id =".$admin_id." did not Updated&color=red&title=Admin_Page");
		}
	}
}
elseif(isset($edit_detail_by_user)){
	// echo "<pre>";
	// print_r($_REQUEST);
	// print_r($_FILES);
	// echo "</pre>";
	// die();
	if(isset($_FILES['edit_image_by_user']['name'])&& $edit_image_by_user['name']!=" "){
		// echo "image";
		$dir = "uploads";
      if(!is_dir($dir)){
         if(!mkdir($dir)){
            echo "Directory could not be created....!";
         }
      }
      // die;
		$profile_picture = $_FILES['edit_image_by_user']['name'];
      $profile_picture_path_name = $_FILES['edit_image_by_user']['tmp_name'];
      $profile_path = $dir."/".time()."_".$profile_picture;
		$date_of_birth = date('Y-m-d', strtotime($date_of_birth));
		if($edit_image_by_user['size']<=100000){
			// echo $profile_path;
			// die;
			if(move_uploaded_file($profile_picture_path_name, $profile_path)){
			$query = "UPDATE user SET first_name = '".$first_name."', last_name ='".$last_name."', email = '".$email."', password = '".$password."', gender = '".$gender."', date_of_birth = '".$date_of_birth."', user_image = '".$profile_path."', address = '".$address."',updated_at = Now() WHERE user_id = '".$user_id_is."' ";
			// echo $query;
			// die;
			setcookie("user_image",$profile_path);
			setcookie("user_name",$first_name." ".$last_name);
			$result=$user->execute_query($query);
			if($result){
				header("location:index.php?msg= User_id =".$user_id_is." Has been Updated Successfully&color=green&title=Home");
				}
				else{
					header("location:index.php?msg= User_id =".$user_id_is." did not Updated&color=red&title=Home");
				}
			}
		}
		else{
			header("location:register_form.php?msg=Image size is Greater Than 1MB&color=red");
		}
		
	}
	else{
		$query = "UPDATE user SET  first_name = '".$first_name."', last_name ='".$last_name."', email = '".$email."', password = '".$password."', gender = '".$gender."', date_of_birth = '".$date_of_birth."', user_image = '".$old_user_image."', address = '".$address."',updated_at = Now() WHERE user_id = '".$user_id_is."' ";
			setcookie("user_name",$first_name." ".$last_name);
		// echo $query;
		// die;
		$result = $user->execute_query($query);
		if($result){
			header("location:index.php?msg= User_id =".$user_id_is." Has been Updated Successfully&color=green&title=Home");
		}
		else{
			header("location:index.php?msg= User_id =".$user_id_is." did not Updated&color=red&title=Home");
		}
	}

}
elseif(isset($edit_post_with_attachment)){
	extract($_REQUEST);
	extract($_FILES);
	// echo "<pre>";
	// print_r($_REQUEST);
	// print_r($_FILES);
	// echo "</pre>";
	// die;
	$get_email_query ="SELECT user.email,user.first_name AS f_name,user.last_name AS l_name ,following_blog.follower_id, blog.blog_title FROM USER JOIN blog ON user.user_id=blog.user_id JOIN following_blog ON user.user_id=following_blog.follower_id WHERE blog.blog_id ='".$select_blog."' && following_blog.status='Followed'"; 
		$get_email=$user->execute_query($get_email_query);
		if($get_email->num_rows>0){
			while($rows= mysqli_fetch_assoc($get_email)){
			extract($rows);
			$name = $f_name." ".$l_name;
			$mail->addReplyTo("bk23877284@gmail.com", "Bheesham_k");
			$mail->addBCC($email , $name );
			$mail->Subject = 'Notification';
			$mail->msgHTML(" Hello ".$f_name." ".$l_name."\r\n Post are Updated Now <b>".$blog_title."</b>\r\n Post title is ".$post_title);
			$mail->send();
		}
	}
	$dir_post_image = "post_featured_image";
      if(!is_dir($dir_post_image)){
         if(!mkdir($dir_post_image)){
            echo "Directory could not be created....!";
         }
      }
	  $featured_image = $_FILES['post_image']['name'];
      $featured_image_path_name = $_FILES['post_image']['tmp_name'];
      $featured_image_path = $dir_post_image."/".time()."_".$featured_image;
      if(isset($_FILES['post_image'])){
      	 if(move_uploaded_file($featured_image_path_name, $featured_image_path)){
			$query="UPDATE post SET blog_id = '".$select_blog."', post_title = '".$post_title."', post_summary = '".$post_summary."',post_description = '".$post_desc."', is_comment_allowed='".$comment."', featured_image = '".$featured_image_path."', updated_at = Now() WHERE post_id = '".$update_post_id."'";
			// echo $query;
			$user->execute_query($query);
      }
      else{
      	$query="UPDATE post SET blog_id = '".$select_blog."', post_title = '".$post_title."', post_summary = '".$post_summary."',post_description = '".$post_desc."', is_comment_allowed='".$comment."', featured_image = '".$old_post_image."', updated_at = Now() WHERE post_id = '".$update_post_id."'";
			// echo $query;
			// die;
			$user->execute_query($query);
      }
	 
	}
		if(!$_FILES['post_attachment']['name'][0] == ""){
		$dir_attachment = "post_attachement";
		if(!is_dir($dir_attachment)){
		   if(!mkdir($dir_attachment)){
			  echo "Directory could not be created....!";
		   }
		}
		$i=0;
		$query = "DELETE FROM post_atachment WHERE post_id = '".$update_post_id."'";
		$result=$user->execute_query($query);
		foreach($_FILES['post_attachment']['name'] as $key => $value) {
			$file_extention = explode('.',$_FILES['post_attachment']['name'][$key]);
			$files_ext =  $file_extention[1];
			$attachment_name = $file_name[$i];
	 		$attachment_path_name = $_FILES['post_attachment']['tmp_name'][$key];
	 		$attachment_path = $dir_attachment."/".rand()."-".$file_name[$i].'.'.$files_ext;
			// echo $attachment_name;
			if( move_uploaded_file($attachment_path_name, $attachment_path)){
				$query = "INSERT INTO post_atachment VALUES(Null,'".$update_post_id."','".$attachment_name."','".$attachment_path."','Active',null,NOW())";
				// echo $query; 
				// die;
				$result = $user->execute_query($query);
			}
			$i++;
		}
		// die;
		$query = "DELETE FROM post_category WHERE post_id = '".$update_post_id."'";
		$result=$user->execute_query($query);
		foreach($category as $key => $value){
			$query = "INSERT INTO post_category VALUES(Null,'".$update_post_id."','".$value."',null,NOW())";
			// echo $query;
			$result = $user->execute_query($query);
		}
		// die;

		// die;
			if($result){
				header("location:admin_dashboard.php?msg=Post Updated Successfully&color=green&title=Admin_Page");
			}
			else{
				header("location:admin_dashboard.php?msg=Updation Failed Failed&color=red&title=Admin_Page");
			}
	}
}
elseif(isset($theme_setting)){
	// echo "<pre>";
	// print_r($_REQUEST);
	// echo "</pre>";
	// die(); 
	$query = "SELECT * FROM setting WHERE user_id = '".$_SESSION['user']['user_id']."'";
	$result = $user->execute_query($query);
	print_r($result);
	// die;
	if($result->num_rows>0){
		// echo "dsijdis";
		foreach($theme as $keys => $values){
			// echo $values;
			// die;
			$query = "UPDATE setting SET setting_key='".$keys."', setting_value = '".$values."', updated_at = NOW() WHERE user_id = '".$_SESSION['user']['user_id']."'";
			// echo $query;
			$result = $user->execute_query($query);
			
		}
		if ($result) {
				header("location:index.php?msg=Theme Update Successfully&color=green&title=Home");
		}
		// die;

	}
	foreach($theme as $keys =>$values){
		// echo $values;
		$query = "INSERT INTO setting VALUES (null, '".$_SESSION['user']['user_id']."','".$keys."','".$values."','".$_theme_setting."',Null,Null)";
			// echo $query;
			$result=$user->execute_query($query);
			if($result){
				header("location:index.php?msg=Theme_setting are applied&color=green&title=Home");
			}
			else{
			header("location:index.php?msg=Theme_setting are not apply&color=red&title=Home");

			}
	}
}
elseif(isset($forgot_email)){
	// echo "<pre>";
	// print_r($_REQUEST);
	$query = "SELECT * FROM user WHERE email = '".$email."'";
	$result= $user->execute_query($query);
	if($result->num_rows>0){
		$row=mysqli_fetch_assoc($result);
		extract($row);
		$mail->addReplyTo("bk23877284@gmail.com", "Bheesham_k");
		$mail->addAddress($email);
		$mail->Subject = 'Notification';
		$mail->msgHTML(" Your Password is ".$password."You may login You account");
		$mail->send();
		header("location:login.php?msg=Email Send Successfully&color=green&title=Forgot_Password");
	}
	else{
		header("location:forget_password.php?msg=Email did not send&color=red&title=Forgot_Password");

	}
}
elseif(isset($action) && $action=="active_theme"){
	$setting = "SELECT * FROM setting WHERE user_id = '".$user_id."'";
	$execute = $user->execute_query($setting);
	if($execute->num_rows>0){
		$query = "UPDATE setting SET setting_status = 'Active', updated_at = Now() WHERE user_id='".$user_id."'";
	$result = $user->execute_query($query);
	if($result){
		header("location:index.php?msg=Theme is Active&color=green&title=Home");
	}
	else{
		header("location:index.php?msg=Theme is Not Change&color=red&title=Home");
	}
	}
	else{
	header("location:index.php?msg=Record Not Found...&color=red&title=Home");
	}
}
elseif(isset($action) && $action=="inactive_theme"){
	$setting = "SELECT * FROM setting WHERE user_id = '".$user_id."'";
	$execute = $user->execute_query($setting);
	if($execute->num_rows>0){
		// print_r($execute);
		// die;
	$query = "UPDATE setting SET setting_status = 'Inactive', updated_at = Now() WHERE user_id='".$user_id."'";
	// echo $query;
	// die;
	$result = $user->execute_query($query);
	if($result){
		header("location:index.php?msg=Theme is Inactive&color=green&title=Home");
		}
		else{
			header("location:index.php?msg=Not Change&color=red&title=Home");
		}
	}
	else{
		header("location:index.php?msg=Record Not Found...&color=red&title=Home");
	}
}
?>