<?php
if(!isset($_REQUEST['title'])&& $_REQUEST['title']!=="Total_Blog_Posts"){
 header("login.php?title=Home");
 die;
}
require_once("config/class_object.php");
include_once("header_and_footer/headers.php");
?>
<?php
extract($_REQUEST);
// print_r($_REQUEST);
	// echo "<pre>";
	// print_r($_REQUEST);
	// echo "</pre>";
	// echo "done";
	// die;
	$limit = $_GET['post_per_page']??1;		
	// echo $limit;
	$page = isset($_GET['page'])?$_GET['page']:1;
	$offset = 	($page-1)*$limit;

	$query = "SELECT user.first_name, user.last_name, post.* , blog.blog_title FROM post JOIN blog ON post.blog_id = blog.blog_id JOIN user ON user.user_id=blog.user_id WHERE blog.blog_id='".$blog_id."' && post_status = 'Active' ORDER BY post_id DESC LIMIT $offset, $limit";
	// echo $query;
	// die;
	$result = $user->execute_query($query);
	if($result->num_rows>0){
		?>
		<div class="row mx-0">
			<div class="col-sm-12 my-1">
				<h3 class=" my-1   bg-dark bg-gradient p-2 text-white text-center ">
				<?=$_REQUEST['blog_name']?> Blog Posts</h3>
			</div>
		</div>
		<div class="container-fluid">
			<div class="row my-2">
		<?php 
		$i=1;
		while ($row = mysqli_fetch_assoc($result)) {
			extract($row);
			?>
			<div class="col-sm-4 my-2">
				<div class="card w-100" style="background-color: rgb(212 212 216);">
				  <img src="<?=$featured_image?>" class="card-img-top w-100 " style="height: 200px;" alt="...">
				  <div class="card-body">
				    <h5 class="card-title"><?=substr($post_title, 0,30).'...'?></h5>
				    <h6><?=$created_at?></h6>
				    <h4>By: <i><?=$first_name." ".$last_name?></i></h4>
					<p class="text-dark text_dec"><?=substr($post_summary, 0,80).'...'?></p>
				    <a href="total_post.php?action=total_post&title=View_Post&post_id=<?=$post_id?>" class="btn btn-primary w-100">Read More</a>
				  </div>
				</div>
			</div>
			
			<?php
		}
		echo "</div> </div>";
	}
?>
<nav aria-label="Page navigation example">
	<ul class="pagination justify-content-center">
		<?php
		$get_post_for_pagination = "SELECT * FROM post WHERE blog_id = '".$blog_id."'";
		// echo $get_post_for_pagination;
		$execute_post_query = $user->execute_query($get_post_for_pagination);
		if(mysqli_num_rows($execute_post_query)>0){
			$total_records = mysqli_num_rows($execute_post_query);
			// echo "limit:".$limit;
			$total_page = ceil($total_records/$limit);
			// echo $total_page;
			// echo $limit;
			// echo $total_records;
			echo "<ul class='pagination justify-content-center'>";
			for($i=1;$i<=$total_page; $i++){
				?>
				<li class="page-item"><a class="page-link" href="total_blog_posts.php?page=<?=$i?>&post_per_page=<?=$post_per_page?>&blog_id=<?=$blog_id?>&blog_name=<?=$blog_name?>"><?=$i?></a></li>
				<?php
				// echo $_REQUEST['blog_name'];
			}
			echo"</ul>";
		}
		?>				
</nav>
<?php
include_once("header_and_footer/footers.php");

?>