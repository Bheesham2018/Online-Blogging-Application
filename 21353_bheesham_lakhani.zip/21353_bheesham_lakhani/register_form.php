<?php
	include_once("header_and_footer/headers.php")
?>
<div class="container-fluid my-2">
	<div class="row mx-0" style="background-color:#C7C7C7;">
		<div class="col-sm-3"></div>
		<div class="col-sm-6" style="overflow: none;">
			<h4 class="my-3 text-center register bg-dark bg-gradient text-light">Create Account</h4>
				<form action="process.php" method="POST" enctype="multipart/form-data" onsubmit="return click_submit()">
					<!-- first name  -->
					<p class="rounded p-1 text-center text-white" style="background-color: <?=$_REQUEST['color']??""?>;"><?=$_REQUEST['msg']??""?></p>
				  <div class="mb-3">
				    <label for="" class="form-label">First Name</label>
					<div class="d-flex">
						<span class="input-group-text"> <i class="fa fa-user"></i> </span>
				    	<input type="text" name="first_name" class="form-control f_name" id="first_name" placeholder="Enter Your First Name">
					</div>
			    		<div id="first_name_message" class="message_color"></div>
				  </div>
				  <!-- last name -->
				  <div class="mb-3">
				    <label for="" class="form-label">Last Name</label>
				    <div class="d-flex">
						<span class="input-group-text"> <i class="fa fa-user"></i> </span>
				    	<input type="text" name="last_name" class="form-control l_name" id="last_name" placeholder="Enter Your Last Name" >
				  	</div>
		  	  			<div id="last_name_message" class="message_color"></div>
				  </div>
				  <!-- email -->
				  <div class="mb-3">
				    <label for="" class="form-label">Email address</label>
				    <div class="d-flex">
						<span class="input-group-text"> <i class="fa fa-envelope"></i> </span>
					    <input type="email" name="email" class="form-control email" id="email" placeholder="Enter Your Email">
				    </div>
				    	<div id="email_message" class="message_color"></div>
				  </div>
				  <!-- password -->
				  <div class="mb-3">
				    <label for="" class="form-label">Password</label>
				    <div class="d-flex">
						<span class="input-group-text"> <i class="fa fa-lock"></i> </span>
					    <input type="password" name="password" class="form-control password" id="password" placeholder="Enter Your Password" minlength="8">
					    <input type="checkbox" name="" id="check" onchange="showPass(this)">
				    </div>				    	
				    <div id="password_message" class="message_color"></div>
				  </div>
				  <!-- gender -->
				  <div class="mb-3">
				    <label for="" class="form-label">Gender</label>
				  	<div class="d-flex">
						<span class="input-group-text d-flex"> <i class="fa fa-person-half-dress"></i> </span>
				    	<div class=" form-control gender">
						    <input type="radio"  name="gender" id="" value="Male"> Male
						    <input type="radio"  name="gender" id="" value="Female"> Female
				    	</div>
				  	</div>
				  </div>
				  <!-- date of birth -->
				  <div class="mb-3">
				  	<label for="" class="form-label d-block">Date of Birth</label>
				  	<div class="d-flex">	
						<span class="input-group-text d-flex"> <i class="fa fa-calendar-days"></i> </span>
				  		<div class=" form-control date">
				  			<input type="text" id="date-input" name="date_of_birth" placeholder="Enter your Date of Birth" class="form-control "/>
				  		</div>
				  	</div>
				   </div>
				   <!-- image -->
				   <div class="mb-3">
				    <label for="" class="form-label">Profile Picture</label>
				    <div class="d-flex">
						<span class="input-group-text d-flex"> <i class="fa fa-image"></i> </span>
				    	<input type="file" class="form-control this_image" name="profile_pic" id="image">
				    </div>
				    <div class="rounded p-1 text-center text-white " style="background-color:<?$_REQUEST['color']?>;"><?=$_REQUEST['img_msg']??""?></div>
				  </div>
				  <!-- address -->
				  <div class="mb-3">
				    <label for="" class="form-label">Address</label>
				    <div class="d-flex">
						<span class="input-group-text d-flex"> <i class="fa fa-home"></i> </span>
					 	<input type="text" class="form-control address" name="address" id="address"placeholder="Enter Your Address">
				    </div>
				  </div>
				  <!-- submit -->
				  <button type="reset" class="btn btn-danger">Cancel</button>
				  <button type="submit" value="Register" name="register_user" class="btn btn-primary">Register</button>
				 <a href="forget_password.php?title=Forgot_Password" class="btn btn-warning">Forget Password</a>
				</form>
				<p class="text-center">Have an account? <a href="login.php?title=Login">Log In</a> </p>
			</div>
		</div>
		<div class="col-sm-3"></div>
	</div>
</div>
<?php
include_once("require_files/client_side_validation.php");
include_once("header_and_footer/footers.php")
?>
	
</div>