<?php
require_once("config/class_object.php");
include_once("header_and_footer/headers.php");
?>
<div class="container-fluid"style="min-height:510px;">
<div class="row">
    <div class="col-3"></div>
    <div class="col-6">
		<p class="rounded p-1 text-center text-white" style="background-color: <?=$_REQUEST['color']??""?>;"><?=$_REQUEST['msg']??""?></p>

			<h4 class="my-3 text-center register bg-dark bg-gradient text-light">Forgot Account</h4>
        <form action="process.php" method="POST">
        <div class="mb-3">
            <label for="" class="form-label">Email address</label>
            <div class="d-flex">
                <span class="input-group-text"> <i class="fa fa-envelope"></i> </span>
                <input type="email" name="email" class="form-control" placeholder="Enter Your Email">
            </div>
                <button type="submit" name="forgot_email" value="forgor_email" class="btn btn-primary btn-block my-2"> Send Email
                </button>
        </form>
    </div>
    <div class="col-3"></div>
</div>
</div>
<?php
include_once("header_and_footer/footers.php");
?>