<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';
$mail = new PHPMailer();

$mail->isSMTP();

$mail->Host = 'smtp.gmail.com';
$mail->Port = 587;
$mail->SMTPAuth = true;
$mail->Username = 'bheeshamkumar2018@gmail.com';
$mail->Password = 'hplupexwxekzrhub';
$mail->setFrom('bheeshamkumar2018@gmail.com', 'Bheesham');

require_once("config/class_object.php");
extract($_REQUEST); 
if (isset($action) && $action =="create"){
    ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Create Blog</h1>
            </div>
            <div class="col-3"></div>
            <div class="col-6">
                 <form action="process.php" method="POST" enctype="multipart/form-data"> <!--onsubmit="return _blog_()" -->
                    <div class="mb-3">
                        <label for="" class="form-label">Blog Name</label>
                        <input type="text" id="title_outline" name="blog_title" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="" class="form-label">Post Per Page</label>
                        <input type="number" id="post_per_page" name="post_per_page" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="" class="form-label">Blog Background Image</label>
                        <input type="file" id="blog_desc" name="blog_image" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-danger">Cancel</button>
                    <button type="submit" name="create_blog" value="create_blog" class="btn btn-primary">Add Blog</button>
                </form>
            </div>
            <div class="col-3"></div>
        </div>
    </div>
    <script>
    //  
    </script>
    <?php
}

// print_r($_REQUEST);
elseif(isset($action) && $action=="search_here"){
    $run_query = "SELECT user.first_name, user.last_name ,post.* , blog.blog_title FROM post JOIN blog ON post.blog_id = blog.blog_id JOIN user ON user.user_id=blog.user_id WHERE post.post_title LIKE '%".$search_is."%' OR   user.first_name = '".$search_is."' OR post.created_at='".$search_is."'";
    // echo $run_query;
    // die;
    $execute_query = $user->execute_query($run_query);
    if($execute_query->num_rows>0){
        while($rows= mysqli_fetch_assoc($execute_query)){
            extract($rows);
            // die;
            ?>
            <div class="row rounded m-0 my-3 box-shadow" style="background-color: rgb(212 212 216);">
                            <div class="col-sm-3 justify-content-center">
                                <img src="<?=$featured_image?>" class="img-thumbnail rounded height_width" alt="">
                            </div>
                            <div class="col-sm-4">
                                <div class="row">
                                    <div class="col-12">
                                        <h2><?=$post_title?></h2>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <h6><?=$created_at?></h6>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <h4>By: <i><?=$first_name." ".$last_name?></i></h4>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-5">
                                <p class="text-dark text_dec"><?=$post_summary?></p>
                            </div>
                            <?php 
                            if(isset($_SESSION['user']['user_id'])){
                                ?>
                                <div class="row">
                                    <div class="col-12">
                                        <a href="total_post.php?action=total_post&title=View_Post&post_id=<?=$post_id?>" class="text_dec text-dark float-end">Read More</a>
                                    </div>
                                </div>
                                <?php
                            }
                            else{
                                ?>
                                <div class="row">
                                    <div class="col-12">
                                    </div>
                                </div>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
            <?php
        }
    }
    else{
    echo "<p class='text-center text-red'> Record Not Found</p>";
    }
}
// .....................................show all comments...........................
elseif(isset($action) && $action=="comment_is"){
    // echo "hello";
    $get_comment = "SELECT user.user_image,user.first_name, user.last_name, post_comment.* FROM post_comment JOIN post ON post.post_id=post_comment.post_id JOIN user ON post_comment.user_id = user.user_id WHERE post.post_id='".$all_comment."' && post_comment.is_active='Active' ORDER BY post_comment_id DESC";
    $result=$user->execute_query($get_comment);
    if($result->num_rows>0){
        while($row = mysqli_fetch_assoc($result)){
            extract($row);
            ?>
             <div class="row my-2 mx-0 text-<?=$title_color?>">
                <div class="col-sm-8  border rounded">
                    <div class="d-flex">
                        <img src="<?=$user_image?>" style="height:40px; width:40px;" class="img-thumbnail rounded-pill" alt="...">
                        <h5><?=$first_name." ".$last_name?></h5>
                        </div>
                    <div class="row">
                        <div class="col-1"></div>
                        <div class="col-11">
                            <p><?=$created_at?></p> 
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-1"></div>
                        <div class="col-11">
                            <p><?=$comment?></p>
                        </div>
                    </div>
                </div>
            </div>
            <?php
        }
    }
}
elseif(isset($action)&&$action=="hide_comment"){
    // echo "mksdfkdm";
    $get_comment = "SELECT user.user_image,user.first_name, user.last_name, post_comment.* FROM post_comment JOIN post ON post.post_id=post_comment.post_id JOIN user ON post_comment.user_id = user.user_id WHERE post.post_id='".$all_comment."' && post_comment.is_active='Active' ORDER BY post_comment_id DESC LIMIT 2";
        // echo $get_comment;
        // die;
        $comment_result = $user->execute_query($get_comment);
        // print_r($comment_result);
        // die;
        $result = $user->execute_query($get_comment);
        if($result->num_rows>0){
            while ($rows=mysqli_fetch_assoc($result)) {
                extract($rows);
                ?>
                <div class="row my-2  mx-0 text-<?=$title_color?>" >
                    <div class="col-sm-8  border rounded" >
                        <div class="d-flex">
                            <img src="<?=$user_image?>" style="height:40px; width:40px;" class="img-thumbnail rounded-pill" alt="...">
                            <h5><?=$first_name." ".$last_name?></h5>
                            </div>
                        <div class="row">
                            <div class="col-1"></div>
                            <div class="col-11">
                                <p><?=$created_at?></p> 
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-1"></div>
                            <div class="col-11">
                                <p><?=$comment?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
            }
        }
}
// .....................................show all comments...........................

// ............................................................................
elseif(isset($action) && $action=="follow_blog"){
    $follower_id= $_SESSION['user']['user_id'];
    $get_follower_data = "DELETE FROM following_blog WHERE follower_id = '".$follower_id."'&& blog_following_id='".$blog_id."'";
    // echo $get_follower_data;   
    // die; 
    $execute_data = $user->execute_query($get_follower_data);

    $get_follower_data = "SELECT * FROM following_blog WHERE follower_id = '".$follower_id."'&& blog_following_id='".$blog_id."' && status = 'Followed'";
    $execute_data = $user->execute_query($get_follower_data);
    if($execute_data->num_rows>0){
        echo "<p class='rounded p-1 text-center text-white bg-dark bg-gradient'>You Have Already Followed</p>";
    }
    // echo $follower_id;
    // die;
    else{    
    $query = "INSERT INTO following_blog VALUES(null, $follower_id, $blog_id,'Followed',null,null)";
    // echo $query;
    // die;
    $result = $user->execute_query($query);
        echo "<p class='rounded p-1 text-center text-white bg-dark bg-gradient'>Followed</p>";

    }
}
elseif(isset($action) && $action=="unfollow_blog"){
    $follower_id= $_SESSION['user']['user_id'];
     $get_follower_data = "SELECT * FROM following_blog WHERE follower_id = '".$follower_id."'&& blog_following_id='".$blog_id."' && status = 'Unfollowed'";
    $execute_data = $user->execute_query($get_follower_data);
        $query = "UPDATE following_blog SET status='Unfollowed',updated_at = NOW() WHERE blog_following_id='".$blog_id."'";
         $result=$user->execute_query($query);
        echo "<p class='rounded p-1 text-center text-white bg-dark bg-gradient'>Unfollowed</p>";
}
// ................................................................................
elseif(isset($action) && $action=="send_comment"){
    // echo "<pre>";
    // print_r($_REQUEST);
    // echo "</pre>";
    $query= "INSERT INTO post_comment VALUES (null , '".$post_id."','".$_SESSION['user']['user_id']."','".$comment_is."','Active',Null)";
        // echo $query;
        $result = $user->execute_query($query);
        // if($result){
            // echo "comment send succesfully";
        // }

}
elseif(isset($action) && $action=="numberAttachment"){
    // echo $attachment;
    for ($i=1; $i <=$attachment ; $i++) { 
        ?>
        <label for="">File Name <?=$i?></label>
        <div class="d-flex">
        <input type="text" name="file_name[]" class="form-control" placeholder="Add Attachment <?=$i?>">
        <input type="file" name="post_attachment[]" class="form-control my-1" required>
        </div>
        <?php
    }
}
// .....................................blog........................................
    elseif(isset($action) && $action=="active_blog_status"){
        $query = "UPDATE blog SET blog_status = 'active' WHERE blog_id ='".$blog_id."'"; 
        $user->execute_query($query);
    }
    elseif(isset($action) && $action=="inactive_blog_status"){
        $query = "UPDATE blog SET blog_status = 'inactive' WHERE blog_id ='".$blog_id."'"; 
        $user->execute_query($query);
    }
// .................................blog..........................................
// .................................comments......................................
elseif(isset($action) && $action=="active_comment_status"){
    $query = "UPDATE post_comment SET is_active = 'active' WHERE  post_comment_id='".$comment_id."'"; 
    $user->execute_query($query);
}
elseif(isset($action) && $action=="inactive_comment_status"){
    $query = "UPDATE post_comment SET is_active = 'Inactive' WHERE  post_comment_id='".$comment_id."'"; 
    $user->execute_query($query);
}
// ................................comments........................................

// ..............cat...................................
    elseif(isset($action) && $action=="active_category_status"){
        $query = "UPDATE category SET category_status = 'active' WHERE category_id ='".$category_id."'"; 
        $user->execute_query($query);
    }
    elseif(isset($action) && $action=="inactive_category_status"){
        $query = "UPDATE category SET category_status = 'inactive' WHERE category_id ='".$category_id."'"; 
        $user->execute_query($query);
    }
// ............................................category.....................................

// ...........................................user_status_ change..........................
    elseif(isset($action) && $action=="status_of_user_change_to_active"){
        $query = "UPDATE user SET is_active = 'active' WHERE user_id ='".$user_id."'"; 
        $user->execute_query($query);
    }
    elseif(isset($action) && $action=="status_of_user_change_to_inactive"){
        $query = "UPDATE user SET is_active = 'inactive' WHERE user_id ='".$user_id."'"; 
        $user->execute_query($query);
    }



// ...........................................user_status_ change..........................
elseif(isset($action) && $action=="approve_user_request_"){
    $query="SELECT * FROM user WHERE user_id = '".$user_id."'";
    // echo $query;
    // die;
    $result=$user->execute_query($query);
    $row=mysqli_fetch_assoc($result);
    extract($row);
    $query = "UPDATE user SET is_approved = 'Approved' , is_active = 'Active' WHERE user_id ='".$user_id."'"; 
    $user->execute_query($query);
    $mail->addReplyTo("bk23877284@gmail.com", "Bheesham_k");
    $mail->addAddress($email , $first_name );
    $mail->Subject = 'Notification';
    $mail->msgHTML("Your Request Has been Accepted @ONLINE BLOG MANAGEMENT SYSTEM \r\n ");
    $mail->send();
    // echo "dsjdnasjk";
}
elseif(isset($action) && $action=="rejected_user_request_"){
        $query="SELECT * FROM user WHERE user_id = '".$user_id."'";
        // echo $query;
        // die;
        $result=$user->execute_query($query);
        $row=mysqli_fetch_assoc($result);
        extract($row);
        $mail->msgHTML("Your Request Has been Rejected contact with admin @ONLINE BLOG MANAGEMENT SYSTEM \r\n ");
        $query = "UPDATE user SET is_approved = 'Rejected' , is_active = 'inactive' WHERE user_id ='".$user_id."'"; 
        $user->execute_query($query);
        $mail->addReplyTo("bk23877284@gmail.com", "Bheesham_k");
        $mail->addAddress($email , $first_name );
        $mail->Subject = 'Notification';
        $mail->send();
        
}
// ...........................................user_status_ change..........................
// .............................post staus active and inactive......
elseif(isset($action) && $action=="update_post_status_active"){
    //  echo $user_id;
    // die;
    $query = "UPDATE post SET post_status = 'Active' WHERE post_id ='".$post_id."'"; 
    $user->execute_query($query);
}
elseif(isset($action) && $action=="update_post_status_inactive"){
    $query = "UPDATE post SET post_status = 'Inactive' WHERE post_id ='".$post_id."'"; 
    $user->execute_query($query);
}

// ...........................comment status change....................................
// comment_status_change
elseif(isset($action) && $action=="comment_status_change_active"){
    //  echo $user_id;
    // die;
    $query = "UPDATE post SET is_comment_allowed = 1 WHERE post_id ='".$post_id."'"; 
    $user->execute_query($query);
}
elseif(isset($action) && $action=="comment_status_change_inactive"){
    $query = "UPDATE post SET is_comment_allowed = 0 WHERE post_id ='".$post_id."'"; 
    $user->execute_query($query);
}
// comment_status_change
// ...........................comment status change....................................
elseif (isset($action) && $action =="update"){
        // ..........................blog_query.........................
        $query = "SELECT * FROM blog WHERE  user_id = '".$_SESSION['user']['user_id']."'ORDER BY blog_id DESC" ;
        $result = $user->execute_query($query);
        // ..........................blog_query.........................
    ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Update Blog</h1>
            </div>
        </div>
    </div>
        <?php  
        if($result->num_rows>0){
            ?>
            <div class="table-responsive">
                <table id="update_blog" class="hover">
                    <thead>
                        <tr>
                            <th class="text-center">Blog Picture</th>
                            <th class="text-center">Blog Title</th>
                            <th class="text-center">Post Per Page</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php  
                    while($row=mysqli_fetch_assoc($result)):
                    extract($row);
                    ?>
                    <tr>
                        <td><img src="<?=$blog_background_image?>" class="img-thumbnail image" alt="..."></td>
                        <td class="text-center"><?=$blog_title?></td>
                        <td class="text-center"><?=$post_per_page?></td>
                        <td class="text-center"><?=$blog_status?></td>
                        <td class="text-center">
                            <a href="edit.php?action=edit_blog&title=Edit_Blog&blog_id=<?=$blog_id?>" class="btn btn-primary">Edit</a>
                            <a class="btn btn-danger my-2">Cancel</a>
                        </td>
                    </tr>
                    <?php
                    endwhile;
                    ?>
                    </tbody>
                </table>
            </div>
            <?php
             }
             else{
                 echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
             }
}
elseif (isset($action) && $action =="update_blog_status"){
        // ..........................blog_query.........................
        $query = "SELECT * FROM blog WHERE  user_id = '".$_SESSION['user']['user_id']."' ORDER BY blog_id DESC";
        $result = $user->execute_query($query);
        // ..........................blog_query.........................
    ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Update Blog Status</h1>
            </div>
        </div>
    </div>
    <?php  
        if($result->num_rows>0){
            ?>
            <div class="table-responsive"> 
                <table id="update_blog_status" class="hover">
                    <thead>
                        <tr>
                            <th class="text-center">Blog Picture</th>
                            <th class="text-center">Blog Title</th>
                            <th class="text-center">Post Per Page</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php  
                    while($row=mysqli_fetch_assoc($result)):
                    extract($row);
                    $_SESSION['blog']=$row;
                    ?>
                    <tr>
                        <td><img src="<?=$blog_background_image?>" class="img-thumbnail" alt="..."></td>
                        <td class="text-center"><?=$blog_title?></td>
                        <td class="text-center"><?=$post_per_page?></td>
                        <td class="text-center"><?=$blog_status?></td>
                        <td class="text-center">
                            <button  class="btn btn-primary show" onclick="active_status_blog(<?=$blog_id?>)">Active</button>
                            <button  class="btn btn-success my-2 hide " onclick="inactive_status_blog(<?=$blog_id?>)">Inactive</button>
                        </td>
                    </tr>
                        <?php
                    endwhile;
                    ?>
                    </tbody>
                </table>
            </div>
            <?php
            }
            else{
                echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
            }
}
elseif(isset($action)&& $action=="active_blog" ){
    // ..........................blog_query.........................
    $query = "SELECT * FROM blog WHERE  user_id = '".$_SESSION['user']['user_id']."' && blog_status = 'Active' ORDER BY blog_id DESC ";
    $result = $user->execute_query($query);
    // ..........................blog_query.........................
 ?>
    <div class="row">
        <div class="col-12">
            <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Active Blog</h1>
        </div>
    </div>
    <!-- active_blog -->
    <?php  
        if($result->num_rows>0){
            ?>
            <div class="table-responsive">
                <table id="active_blog" class="hover">
                    <thead>
                        <tr>
                            <th class="text-center">Blog Picture</th>
                            <th class="text-center">Blog Title</th>
                            <th class="text-center">Post Per Page</th>
                            <th class="text-center">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php  
                    while($row=mysqli_fetch_assoc($result)):
                    extract($row);
                    $_SESSION['blog']=$row;
                    ?>
                    <tr>
                        <td><img src="<?=$blog_background_image?>" class="img-thumbnail" style="height: 130px; width: 70%;" alt="..."></td>
                        <td class="text-center"><?=$blog_title?></td>
                        <td class="text-center"><?=$post_per_page?></td>
                        <td class="text-center"><?=$blog_status?></td>
                    </tr>
                        <?php
                    endwhile;
                    ?>
                    </tbody>
                </table>
            </div>
            <?php
            }
            else{
                echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
            }
}
elseif(isset($action)&& $action=="inactive_blog" ){
    // ..........................blog_query.........................
    $query = "SELECT * FROM blog WHERE  user_id = '".$_SESSION['user']['user_id']."' && blog_status = 'Inactive' ORDER BY blog_id DESC ";
    $result = $user->execute_query($query);
    // ..........................blog_query.........................
    ?>
    <div class="row">
        <div class="col-12">
            <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Inactive Blog</h1>
        </div>
    </div>
    <!-- inactive_blog -->
    <?php  
        if($result->num_rows>0){
            ?>
            <div class="table-responsive">
                <table id="inactive_blog" class="hover">
                    <thead>
                        <tr>
                            <th class="text-center">Blog Picture</th>
                            <th class="text-center">Blog Title</th>
                            <th class="text-center">Post Per Page</th>
                            <th class="text-center">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                      <?php  
                    while($row=mysqli_fetch_assoc($result)):
                        extract($row);
                        $_SESSION['blog']=$row;
                        ?>
                    <tr>
                        <td><img src="<?=$blog_background_image?>" class="img-thumbnail" style="height: 130px; width: 70%;" alt="..."></td>
                        <td class="text-center"><?=$blog_title?></td>
                        <td class="text-center"><?=$post_per_page?></td>
                        <td class="text-center"><?=$blog_status?></td>
                    </tr>
                    <?php
                    endwhile;
                    ?>
                    </tbody>
                </table>
            </div>
            <?php
                 }
                 else{
                     echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
                 }
}
elseif(isset($action)&& $action=="all_category" ){
        // .................all category code.............
        $query = "SELECT * FROM category ORDER BY category_id DESC";
        $result = $user->execute_query($query);
        // print_r($result);
        // die;
        // .................all category code.............
    ?>
    <div class="row">
        <div class="col-12">
            <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">All Category</h1>
        </div>
    </div>
    <?php
    if($result->num_rows>0){
    ?>
    <div class="table-responsive">
        <table id="all_category" class="hover">
            <thead>
                <tr>
                    <th class="text-center">Category Name</th>
                    <th class="text-center">Category Description</th>
                    <th class="text-center">Created Date</th>
                    <th class="text-center">Status</th>
                </tr>
            </thead>
            <tbody>

                <?php
                while($row = mysqli_fetch_assoc($result)):
                    extract($row);
                ?>
                <tr>
                    <td class="text-center"><?=$category_title?></td>
                    <td class="text-center"><?=$category_description?></td>
                    <td class="text-center"><?=$created_at?></td>
                    <td class="text-center"><?=$category_status?></td>
                </tr>
                <?php
                endwhile;
                ?>
            </tbody>
        </table>
    </div>
    <?php
         }
         else{
             echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
         }
}
//add_category
elseif (isset($action) && $action =="add_category"){
    ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Add Category</h1>
            </div>
            <div class="col-sm-3"></div>
            <div class="col-sm-6">
                <form action="process.php" method="POST">
                    <div class="mb-3">
                        <label class="form-label">Category Name</label>
                        <input type="text" name="category_title" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label  class="form-label">Short Description</label>
                        <textarea type="text" name="category_description" class="form-control" placeholder="Short Description" rows="10" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-danger">Cancel</button>
                    <button type="submit" value="Add category" name="add_category" class="btn btn-primary">Add</button>
                </form>
            </div>
            <div class="col-sm-3"></div>
        </div>
 </div>
    <?php
}
//update category
elseif(isset($action)&& $action=="update_category" ){
    // .................all category code.............
    $query = "SELECT * FROM category ORDER BY category_id DESC";
    $result = $user->execute_query($query);
    // print_r($result);
    // die;
    // .................all category code.............
    ?>
    <div class="row">
        <div class="col-12">
            <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Update Categories</h1>
        </div>
    </div>
    <?php
    if($result->num_rows>0){
    ?>
    <div class="table-responsive">
        <table id="update_category" class="hover">
            <thead>
                <tr>
                    <th class="text-center">Category Name</th>
                    <th class="text-center">Category Description</th>
                    <th class="text-center">Status</th>
                    <th class="text-center">Action</th>


                </tr>
            </thead>
            <tbody>

                <?php
                while($row = mysqli_fetch_assoc($result)):
                    extract($row);
                ?>
                <tr>
                    <td class="text-center"><?=$category_title?></td>
                    <td class="text-center"><?=$category_description?></td>
                    <td class="text-center"><?=$category_status?></td>
                    <td class="text-center">
                    <a href="edit.php?action=edit_category&title=Edit_Category&category_id=<?=$category_id?>" class="btn btn-primary">Edit</a>
                    <a class="btn btn-danger my-2">Cancel</a> 
                    </td>
                </tr>
                <?php
                endwhile;
                ?>
            </tbody>
        </table>
    </div>
    <?php
        }
        else{
            echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
        }
}
elseif (isset($action) && $action =="update_category_status"){
        // .................all category code.............
        $query = "SELECT * FROM category ORDER BY category_id DESC";
        $result = $user->execute_query($query);
        // print_r($result);
        // die;
        // .................all category code.............
    ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Update Categoty Status</h1>
            </div>
        </div>
    </div>
   <?php
    if($result->num_rows>0){
    ?>
    <div class="table-responsive">
        <table id="update_category_status" class="hover">
            <thead>
                <tr>
                    <th class="text-center">Category Name</th>
                    <th class="text-center">Category Description</th>
                    <th class="text-center">Status</th>
                    <th class="text-center">Action</th>


                </tr>
            </thead>
            <tbody>

                <?php
                while($row = mysqli_fetch_assoc($result)):
                    extract($row);
                ?>
                <tr>
                    <td class="text-center"><?=$category_title?></td>
                    <td class="text-center"><?=$category_description?></td>
                    <td class="text-center"><?=$category_status?></td>
                    <td class="text-center">
                    <button type="button" class="btn btn-primary" onclick="active_category_status(<?=$category_id?>)">Active</button>
                    <button type="button"class="btn btn-success my-2" onclick="inactive_category_status(<?=$category_id?>)">InActive</button> 
                    </td>
                </tr>
                <?php
                endwhile;
                ?>
            </tbody>
        </table>
    </div>
    <?php
         }
         else{
             echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
         }
}
elseif(isset($action)&& $action=="active_category" ){
            // .................all category code.............
            $query = "SELECT * FROM category WHERE  category_status='Active' ORDER BY category_id DESC";
            $result = $user->execute_query($query);
            // print_r($result);
            // die;
            // .................all category code.............
    ?>
    <div class="row">
        <div class="col-12">
            <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Active Category</h1>
        </div>
    </div>
    <?php
    if($result->num_rows>0){
    ?>
    <div class="table-responsive">
        <table id="active_category" class="hover">
            <thead>
                <tr>
                    <th class="text-center">Category Name</th>
                    <th class="text-center">Category Description</th>
                    <th class="text-center">Created At</th>
                    <th class="text-center">Status</th>
                </tr>
            </thead>
            <tbody>

                <?php
                while($row = mysqli_fetch_assoc($result)):
                    extract($row);
                ?>
                <tr>
                    <td class="text-center"><?=$category_title?></td>
                    <td class="text-center"><?=$category_description?></td>
                    <td class="text-center"><?=$created_at?></td>
                    <td class="text-center"><?=$category_status?></td>
                </tr>
                <?php
                endwhile;
                ?>
            </tbody>
        </table>
    </div>
    <?php
         }
         else{
             echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
         }
}

elseif(isset($action)&& $action=="inactive_category" ){
    // .................all category code.............
    $query = "SELECT * FROM category WHERE  category_status='Inactive' ORDER BY category_id DESC";
    $result = $user->execute_query($query);
    // print_r($result);
    // die;
    // .................all category code.............
    ?>
    <div class="row">
        <div class="col-12">
            <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Inctive Category</h1>
        </div>
    </div>
    <?php
    if($result->num_rows>0){
    ?>
    <div class="table-responsive">
        <table id="inactive_category" class="hover">
            <thead>
                <tr>
                    <th class="text-center">Category Name</th>
                    <th class="text-center">Category Description</th>
                    <th class="text-center">Created At</th>
                    <th class="text-center">Status</th>
                </tr>
            </thead>
            <tbody>

                <?php
                while($row = mysqli_fetch_assoc($result)):
                    extract($row);
                ?>
                <tr>
                    <td class="text-center"><?=$category_title?></td>
                    <td class="text-center"><?=$category_description?></td>
                    <td class="text-center"><?=$created_at?></td>
                    <td class="text-center"><?=$category_status?></td>
                </tr>
                <?php
                endwhile;
                ?>
            </tbody>
        </table>
    </div>
    <?php
        }
        else{
            echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
        }
}
//....................................user detail.................................
elseif(isset($action)&& $action=="user_status" ){
    //...........................user query.........................

    $query = "SELECT user.* , role.role_type FROM user JOIN role ON user.role_id = role.role_id  ORDER BY user.user_id DESC";
    $result = $user->execute_query($query);

    //...........................user query.........................
    ?>
    <div class="row">
        <div class="col-12">
            <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Change User Status </h1>
        </div>
    </div>
    <?php 
    if($result->num_rows>0){
    ?>
    <div class="table-responsive">
        <table id="user_status" class="hover">
            <thead>
                <tr>
                    <th class="text-center">Image</th>
                    <th class="text-center">Full Name</th>
                    <th class="text-center">Email</th>
                    <th class="text-center">Role Type</th>
                    <th class="text-center">Status</th>
                    <th class="text-center">Action</th>
                </tr>
            </thead>
            <tbody>

                <?php while($row = mysqli_fetch_assoc($result)): extract($row); ?>
                <tr>
                    <td class="text-center"><img src="<?=$user_image?>" class="img-thumbnail " alt="" style="border-radius: 0%; width:70%; height: 100px;"></td>
                    <td class="text-center"><?=$first_name." ".$last_name?></td>
                    <td class="text-center"><?=$email?></td>
                    <td class="text-center"><?=$role_type?></td>
                    <td class="text-center"><?=$is_active?></td>
                    <td class="text-center">
                    <button type="button"  class="btn btn-primary" onclick="status_of_user_change_to_active(<?=$user_id?>)">Active</button>
                    <button type="button" class="btn btn-success" onclick="status_of_user_change_to_inactive(<?=$user_id?>)">Inactive</button>
                    </td>
                </tr>
                <?php
                endwhile;
                ?>
            </tbody>
        </table>
    </div>
    <?php
         }
         else{
             echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
         }
}

// .....................................edit user detail..............................................

elseif(isset($action)&& $action=="edit_user_detail" ){
    //...........................user query.........................

    $query = "SELECT user.*,role.role_type  FROM user JOIN role ON role.role_id=user.role_id WHERE user.role_id = 2  ORDER BY user_id DESC";
    // echo $query;
    // die;
    $result = $user->execute_query($query);

    //...........................user query.........................
    ?>
    <div class="row">
        <div class="col-12">
            <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Edit User Detail </h1>
        </div>
    </div>
    <?php 
    if($result->num_rows>0){
    ?>
    <div class="table-responsive">
        <table id="edit_user_detail" class="hover">
            <thead>
                <tr>
                    <th class="text-center">Image</th>
                    <th class="text-center">Full Name</th>
                    <th class="text-center">Email</th>
                    <th class="text-center">Role Type</th>
                    <th class="text-center">Status</th>
                    <th class="text-center">Action</th>
                </tr>
            </thead>
            <tbody>

                <?php while($row = mysqli_fetch_assoc($result)): extract($row); ?>
                <tr>
                    <td class="text-center"><img src="<?=$user_image?>" class="img-thumbnail " alt="" style="border-radius: 0%; width:70%; height: 100px;"></td>
                    <td class="text-center"><?=$first_name." ".$last_name?></td>
                    <td class="text-center"><?=$email?></td>
                    <td class="text-center"><?=$role_type?></td>
                    <td class="text-center"><?=$is_active?></td>
                    <td class="text-center">
                    <a href="edit.php?action=edit_user_detail&title=Edit_User_Detail&user_id=<?=$user_id?>" type="button" class="btn btn-primary">Edit profile</a>
                    <a href="#" type="button" class="btn btn-danger">Cancel</a>
                    </td>
                </tr>
                <?php
                endwhile;
                ?>
            </tbody>
        </table>
    </div>
    <?php
        }
        else{
            echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
        }
}

// .....................................edit user detail..............................................

elseif(isset($action)&& $action=="user_request" ){
    //...........................user query.........................

        $query = "SELECT * FROM user WHERE role_id = 2 && is_approved ='"."Pending"."' ORDER BY user_id DESC";
        $result = $user->execute_query($query);

    //...........................user query.........................
    ?>

    <div class="row">
        <div class="col-12">
            <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">User Request</h1>
        </div>
    </div>
   <?php 
    if($result->num_rows>0){
    ?>
    <div class="table-responsive">
        <table id="user_request" class="hover">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>

                <?php 
                while($row = mysqli_fetch_assoc($result)): extract($row); ?>
                <tr>
                    <td><img src="<?=$user_image?>" class="img-thumbnail " alt="" style="border-radius: 0%; width:70%; height: 100px;"></td>
                    <td><?=$first_name." ".$last_name?></td>
                    <td><?=$email?></td>
                    <td><?=$is_active?></td>
                    <td>
                        <?php $name = $first_name." ".$last_name;?>
                    <button type="button" class="btn btn-primary" onclick="approve_user_request_('<?= $user_id?>','<?=htmlspecialchars($email)?>','<?=$name?>')">Approve</button>
                    <button type="button" class="btn btn-danger" onclick="rejected_user_request_('<?= $user_id?>','<?=htmlspecialchars($email)?>','<?=$name?>')">Reject</button>
                    </td>
                </tr>
                <?php
                endwhile;
                ?>
            </tbody>
        </table>
    </div>
    <?php
        }
        else{
            echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
        }
}
elseif(isset($action)&& $action=="new_user" ){
        //...........................user query.........................

    $query = "SELECT * FROM USER  WHERE role_id = 2 AND is_active = 'Active' ORDER BY user_id DESC LIMIT 20";
    $result = $user->execute_query($query);

    //...........................user query.........................
    ?>
    <div class="row">
        <div class="col-12">
            <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">New Users</h1>
        </div>
    </div>
    <?php 
    if($result->num_rows>0){
    ?>
    <div class="table-responsive">
        <table id="new_user" class="hover">
            <thead>
                <tr>
                    <th class="text-center">Image</th>
                    <th  class="text-center">Full Name</th>
                    <th  class="text-center">Email</th>
                    <th  class="text-center">Status</th>
                    <th  class="text-center">Approved</th>
                </tr>
            </thead>
            <tbody>

                <?php while($row = mysqli_fetch_assoc($result)): extract($row); ?>
                 <tr>
                    <td class="text-center"><img src="<?=$user_image?>" class="img-thumbnail " alt="" style="border-radius: 0%; width:70%; height: 100px;"></td>
                    <td class="text-center"><?=$first_name." ".$last_name?></td>
                    <td class="text-center"><?=$email?></td>
                    <td class="text-center"><?=$is_active?></td>
                    <td class="text-center"><?=$is_approved?></td>
                </tr>
                <?php
                endwhile;
                ?>
            </tbody>
        </table>
    </div>
    <?php
         }
         else{
             echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
         }
}
elseif(isset($action)&& $action=="approved_user" ){
     //...........................user query.........................

        $query = "SELECT * FROM user WHERE role_id = 2 && is_approved ='"."Approved"."' ORDER BY user_id DESC";
        $result = $user->execute_query($query);

    //...........................user query.........................
    ?>
    <div class="row">
        <div class="col-12">
            <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Approved Users</h1>
        </div>
    </div>
     <?php 
        if($result->num_rows>0){
        ?>
        <table id="approved_user" class="hover">
            <thead>
                <tr>
                    <th class="text-center">Image</th>
                    <th  class="text-center">Full Name</th>
                    <th  class="text-center">Email</th>
                    <th  class="text-center">Status</th>
                    <th  class="text-center">Approved</th>
                </tr>
            </thead>
            <tbody>

                <?php while($row = mysqli_fetch_assoc($result)): extract($row); ?>
                <tr>
                    <td class="text-center"><img src="<?=$user_image?>" class="img-thumbnail " alt="" style="border-radius: 0%; width:70%; height: 100px;"></td>
                    <td class="text-center"><?=$first_name." ".$last_name?></td>
                    <td class="text-center"><?=$email?></td>
                    <td class="text-center"><?=$is_active?></td>
                    <td class="text-center"><?=$is_approved?></td>
                </tr>
                <?php
                endwhile;
                ?>
            </tbody>
        </table>
    </div>
    <?php
         }
         else{
             echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
         }
}
elseif(isset($action)&& $action=="pending_user" ){
         //...........................user query.........................

        $query = "SELECT * FROM user WHERE role_id = 2 && is_approved ='"."Pending"."' ORDER BY user_id DESC ";
        $result = $user->execute_query($query);

    //...........................user query.........................
    ?>
  
    <div class="row">
        <div class="col-12">
            <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Pending Users</h1>
        </div>
    </div>
    <div class="table-responsive">
           <?php 
        if($result->num_rows>0){
        ?>
        <table id="pending_user" class="hover">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Approved</th>
                </tr>
            </thead>
            <tbody>

                <?php while($row = mysqli_fetch_assoc($result)): extract($row); ?>
                <tr>
                    <td><img src="<?=$user_image?>" class="img-thumbnail " alt="" style="border-radius: 0%; width:70%; height: 100px;"></td>
                    <td><?=$first_name." ".$last_name?></td>
                    <td><?=$email?></td>
                    <td><?=$is_active?></td>
                    <td><?=$is_approved?></td>
                </tr>
                <?php
                endwhile;
                ?>
            </tbody>
        </table>
    </div>
    <?php
         }
         else{
             echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
         }
}
elseif(isset($action)&& $action=="rejected_user" ){
       //...........................user query.........................

        $query = "SELECT * FROM user WHERE role_id = 2 && is_approved ='"."Rejected"."' ORDER BY user_id DESC ";
        $result = $user->execute_query($query);

    //...........................user query.........................
    ?>
    <div class="row">
        <div class="col-12">
            <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Rejected Users</h1>
        </div>
    </div>
        <div class="table-responsive">
           <?php 
        if($result->num_rows>0){
        ?>
        <table id="rejected_user" class="hover">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Approved</th>
                </tr>
            </thead>
            <tbody>

                <?php while($row = mysqli_fetch_assoc($result)): extract($row); ?>
                <tr>
                    <td><img src="<?=$user_image?>" class="img-thumbnail " alt="" style="border-radius: 0%; width:70%; height: 100px;"></td>
                    <td><?=$first_name." ".$last_name?></td>
                    <td><?=$email?></td>
                    <td><?=$is_active?></td>
                    <td><?=$is_approved?></td>
                </tr>
                <?php
                endwhile;
                ?>
            </tbody>
        </table>
    </div>
    <?php
         }
         else{
             echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
         }
}
//active users
elseif(isset($action)&& $action=="active_user" ){
    //...........................user query.........................

        $query = "SELECT * FROM user WHERE role_id = 2 && is_active ='"."Active"."' ORDER BY user_id DESC ";
        $result = $user->execute_query($query);

    //...........................user query.........................
    ?>
    ?>
    <div class="row">
        <div class="col-12">
            <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Active Users</h1>
        </div>
    </div>
    <div class="table-responsive">
        <?php if($result->num_rows>0){?>
        <table id="active_user" class="hover">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Gender</th>
                    <th>Created Date</th>
                    <th>Address</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>

                <?php
                while($row = mysqli_fetch_assoc($result)):
                extract($row);    
                ?>
                <tr>
                    <td><img src="<?=$user_image?>" class="img-thumbnail " alt="" style="border-radius: 0%; width:70%; height: 100px;"> </td>
                    <td><?=$first_name." ".$last_name?></td>
                    <td><?=$email?></td>
                    <td><?=$gender?></td>
                    <td><?=$created_at?></td>
                    <td><?=$address?></td>
                    <td><?=$is_active?></td>
                </tr>
                <?php
                    endwhile;
                        ?>
            </tbody>
        </table>
    </div>
    <?php
         }
         else{
             echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
         }
}
//inactive users
elseif(isset($action)&& $action=="inactive_user" ){ 
    //...........................user query.........................

        $query = "SELECT * FROM user WHERE role_id = 2 && is_active ='"."Inactive"."' ORDER BY user_id DESC ";
        $result = $user->execute_query($query);

    //...........................user query.........................
    ?>
    <div class="row">
        <div class="col-12">
            <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">InActive Users</h1>
        </div>
    </div>
    <div class="table-responsive">
        <?php if($result->num_rows>0){?>
        <table id="inactive_user" class="hover">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Gender</th>
                    <th>Created Date</th>
                    <th>Address</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>

                <?php
                while($row = mysqli_fetch_assoc($result)):
                extract($row);    
                ?>
                <tr>
                    <td><img src="<?=$user_image?>" class="img-thumbnail " alt="" style="border-radius: 0%; width:70%; height: 100px;"> </td>
                    <td><?=$first_name." ".$last_name?></td>
                    <td><?=$email?></td>
                    <td><?=$gender?></td>
                    <td><?=$created_at?></td>
                    <td><?=$address?></td>
                    <td><?=$is_active?></td>
                </tr>
                <?php
                    endwhile;
                        ?>
            </tbody>
        </table>
    </div>
    <?php
         }
         else{
             echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
         }
}
//....................................user_detail.................................
// creat post
elseif (isset($action) && $action =="create_post"){
    ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Create Post</h1>
            </div>
            <div class="col-sm-3"></div>
            <div class="col-sm-6">
                <form action="process.php" method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="" class="form-label">Post Title</label>
                        <input type="text" name="post_title" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="" class="form-label">Post Summary</label>
                        <textarea type="text" name="post_summary" class="form-control" rows="6" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="" class="form-label">Featured Image</label>
                        <input type="file" name="post_image" class="form-control" required>
                    </div>
                    <label for="" class="form-label d-flex">Enter your Attachment Number</label>
                    <div class="mb-3 d-flex">
                        <input type="number" id="number_of_attachment" name="attachment" class="form-control d-flex">
                        <input type="button" onclick="numberAttachment()" name="add_attachment" value="+" class="btn btn-primary"/>
                    </div>
                    <div class="mb-3" id="attachment_number">
                        
                    </div>
                    <div class="mb-3">
                        <label  class="form-label">Short Description</label>
                        <textarea type="text" name="post_desc" class="form-control" rows="10" placeholder="Short Description" required></textarea>
                    </div>
                    <div class="mb-3">
                    <label  class="form-label">Comment</label>
                        <div class=" form-control">
                            <input type="radio" name="comment" id="" value="1"> Allow
                            <input type="radio" name="comment" id="" value="0"> Not Allowed
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="" class="form-label" id="select_blog">Select Blog</label>
                        <div class="form-control">
                            <select name="select_blog" id="example" class="form-control" required>
                                <option id="blog" value="">...Select One...</option>
                                <?php
                                    $query = "SELECT * FROM blog WHERE user_id = '".$_SESSION['user']['user_id']."'";
                                    // echo $query;
                                    // die;
                                    $result = $user->execute_query($query);
                                    // print_r($result);
                                    // die;
                                    if(mysqli_num_rows($result)>0){
                                        while ($row = mysqli_fetch_assoc($result)) {
                                            extract($row);
                                            ?>
                                <option value="<?=$blog_id?>"><?=$blog_title?></option>
                                <?php
                                    }
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="" class="form-label">Select Category</label>
                        <div class="btn-group d-block" role="group" aria-label="Basic checkbox toggle button group">
                        <div class="mb-3 form-control" >
                            <?php
                            $query = "SELECT * FROM category WHERE category_status='Active'";
                            $result = $user->execute_query($query);
                            if($result->num_rows>0):
                                // $i=0;
                                ?>
                                <select id="Multi-select-category" name="Multiple" data-placeholder="Select Category" multiple data-multi-select>
                                <?php 
                                while($row = mysqli_fetch_assoc($result)):
                                    // $i++;
                                    extract($row);
                            ?>
                                <option value="<?=$category_id?>"><?=$category_title?></option>
                                <!-- <input type="checkbox" name="category[]" id="" value="<?=$category_id?>"> <?=$category_title?> -->
                                <?php
                                endwhile;
                                ?>
                                </select>
                                <?php
                            endif;
                                ?>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-danger">Cancel</button>
                    <button type="submit" name="add_post" value="add post" class="btn btn-primary">Add Post</button>
                </form>
            </div>
            <div class="col-sm-3"></div>
        </div>
    </div>
    <?php
}

// update_post
elseif (isset($action) && $action =="update_post"){
    // print_r($_REQUEST);

    $query = "SELECT post.*, blog.blog_title FROM post JOIN blog ON post.`blog_id`=blog.`blog_id` JOIN USER ON user.`user_id` = blog.`user_id` WHERE post_status ='Active' && user.user_id = '".$_SESSION['user']['user_id']."' ORDER BY post.post_id DESC ";
    // echo $query;
    // die;
    $result = $user->execute_query($query);
    ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Edit Post</h1>
            </div>
        </div>
    </div>
    <!-- update_post -->
    <?php 
    if ($result->num_rows>0){
    ?>
    <div class="table-responsive">
        <table id="update_post" class="hover">
            <thead >
                <tr>
                    <th class="text-center">S.NO</th>
                    <th class="text-center">featured Image</th>
                    <th class="text-center">Blog Name</th>
                    <th class="text-center">Post Title</th>
                    <th class="text-center">Post Summary</th>
                    <th class="text-center">Description</th>
                    <th class="text-center">Status</th>
                    <th class="text-center">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $i=0;
                while ($row = mysqli_fetch_assoc($result)):
                    extract($row);
                ?>
                <tr>
                    <td class="text-center"><?=++$i?></td>
                    <td class="text-center"><img src="<?=$featured_image?>" class="img-thumbnail" alt="..." style="border-radius: 0%; width:70%; height: 100px;"></td>
                    <td class="text-center"><?=$blog_title?></td>
                    <td class="text-center"><?=$post_title?></td>
                    <td class="text-center"><?=substr("$post_summary",0,100).'...'?></td>
                    <td class="text-center"><?=substr("$post_description",0,100).'...'?></td>
                    <td class="text-center"><?=$post_status?></td>
                    <td class="text-center">
                    <a href="edit.php?action=edit_post&title=Edit_Post&update_post_id=<?=$post_id?>" class="btn btn-primary">Edit</a>
                    <a href="#" class="btn btn-danger">Cancel</a>
                    </td>
                </tr>
                <?php
                 endwhile;
                ?>
            </tbody>
        </table>
    </div>
    <?php
         }
         else{
             echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
         }
}
// update_post_status
elseif (isset($action) && $action =="update_post_status"){
    $query = "SELECT post.*,blog.blog_title FROM post JOIN blog ON post.`blog_id`=blog.`blog_id` JOIN USER ON user.`user_id` = blog.`user_id` WHERE user.user_id = '".$_SESSION['user']['user_id']."' ORDER BY post.post_id DESC";
    $result = $user->execute_query($query);
    ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Update Post Status</h1>
            </div>
        </div>
    </div>
    <?php 
    if ($result->num_rows>0){
    ?>
    <div class="table-responsive">
        <table id="update_post_status" class="hover">
            <thead >
                <tr>
                    <th class="text-center">S.NO</th>
                    <th class="text-center">Featured Image</th>
                    <th class="text-center">Blog Name</th>
                    <th class="text-center">Post Title</th>
                    <th class="text-center">Post Summary</th>
                    <th class="text-center">Description</th>
                    <th class="text-center">Status</th>
                    <th class="text-center">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $i=0;
                while ($row = mysqli_fetch_assoc($result)):
                    extract($row);
                ?>
                <tr>
                    <td class="text-center"><?=++$i?></td>
                    <td class="text-center"><img src="<?=$featured_image?>" class="img-thumbnail" alt="..." style="border-radius: 0%; width:70%; height: 100px;"></td>
                    <td class="text-center"><?=$blog_title?></td>
                    <td class="text-center"><?=$post_title?></td>
                    <td class="text-center"><?=substr("$post_summary",0,100).'...'?></td>
                    <td class="text-center"><?=substr("$post_description",0,100).'...'?></td>
                    <td class="text-center"><?=$post_status?></td>
                    <td class="text-center">
                    <button href="#" class="btn btn-primary" onclick="update_post_status_active(<?=$post_id?>)">Active</button>
                    <button href="#" class="btn btn-success" onclick="update_post_status_inactive(<?=$post_id?>)">Inactive</button>
                    </td>
                </tr>
                <?php
                 endwhile;
                ?>
            </tbody>
        </table>
    </div>
    <?php
         }
         else{
             echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
         }
}
// comment_update
elseif (isset($action) && $action =="comment_update"){
    $query = "SELECT post.*, blog.blog_title FROM post JOIN blog ON post.`blog_id`=blog.`blog_id` JOIN USER ON user.`user_id` = blog.`user_id` WHERE user.user_id = '".$_SESSION['user']['user_id']."' ORDER BY post.post_id DESC";
    $result = $user->execute_query($query);
    ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Update Post Comment</h1>
            </div>
        </div>
    </div>
    <?php 
    if ($result->num_rows>0){
    ?>
    <div class="table-responsive">
        <table id="comment_update" class="hover">
            <thead >
                <tr>
                    <th class="text-center">S.NO</th>
                    <th class="text-center">Featured Image</th>
                    <th class="text-center">Blog Name</th>
                    <th class="text-center">Post Title</th>
                    <th class="text-center">Post Summary</th>
                    <th class="text-center">Description</th>
                    <th class="text-center">Status</th>
                    <th class="text-center">Comment Status</th>
                    <th class="text-center">Comment Action</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $i=0;
                while ($row = mysqli_fetch_assoc($result)):
                    extract($row);
                    if(isset($is_comment_allowed) && $is_comment_allowed==1){
                        $is_comment_allowed = "Allowed";
                    }
                    else{
                        $is_comment_allowed = "Not Allowed";

                    }
                ?>
                <tr>
                    <td class="text-center"><?=++$i?></td>
                    <td class="text-center"><img src="<?=$featured_image?>" class="img-thumbnail" alt="..." style="border-radius: 0%; width:70%; height: 100px;"></td>
                    <td class="text-center"><?=$blog_title?></td>
                    <td class="text-center"><?=$post_title?></td>
                    <td class="text-center"><?=substr("$post_summary",0,100).'...'?></td>
                    <td class="text-center"><?=substr("$post_description",0,100).'...'?></td>
                    <td class="text-center"><?=$post_status?></td>
                    <td class="text-center"><?=$is_comment_allowed?></td>
                    <td class="text-center">
                    <button href="#" class="btn btn-primary" onclick="comment_status_change_active(<?=$post_id?>)">Active</button>
                    <button href="#" class="btn btn-success" onclick="comment_status_change_inactive(<?=$post_id?>)">Inactive</button>
                    </td>
                </tr>
                <?php
                 endwhile;
                ?>
            </tbody>
        </table>
    </div>
    <?php
         }
         else{
             echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
         }
}
//active post
elseif(isset($action)&& $action=="active_post" ){
    $query = "SELECT post.*, blog.blog_title FROM post JOIN blog ON post.`blog_id`=blog.`blog_id` JOIN USER ON user.`user_id` = blog.`user_id` WHERE post_status = 'Active' && user.user_id = '".$_SESSION['user']['user_id']."' ORDER BY post_id DESC";
    $result = $user->execute_query($query);
    ?>
    <div class="row">
        <div class="col-12">
            <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Active Post</h1>
        </div>
    </div>
    <?php 
    if ($result->num_rows>0){
    ?>
    <div class="table-responsive">
        <table id="active_post" class="hover">
            <thead >
                <tr>
                    <th class="text-center">S.NO</th>
                    <th class="text-center">Featured Image</th>
                    <th class="text-center">Blog Name</th>
                    <th class="text-center">Post Title</th>
                    <th class="text-center">Post Summary</th>
                    <th class="text-center">Description</th>
                    <th class="text-center">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $i=0;
                while ($row = mysqli_fetch_assoc($result)):
                    extract($row);
                ?>
                <tr>
                    <td class="text-center"><?=++$i?></td>
                    <td class="text-center"><img src="<?=$featured_image?>" class="img-thumbnail" alt="..." style="border-radius: 0%; width:70%; height: 100px;"></td>
                    <td class="text-center"><?=$blog_title?></td>
                    <td class="text-center"><?=$post_title?></td>
                    <td class="text-center"><?=substr("$post_summary",0,100).'...'?></td>
                    <td class="text-center"><?=substr("$post_description",0,100).'...'?></td>
                    <td class="text-center"><?=$post_status?></td>
                </tr>
                <?php
                 endwhile;
                ?>
            </tbody>
        </table>
    </div>
    <?php
     }
     else{
         echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
     }
}
// inactive_post
elseif(isset($action)&& $action=="inactive_post" ){
    $query = "SELECT post.*, blog.blog_title FROM post JOIN blog ON post.`blog_id`=blog.`blog_id` JOIN USER ON user.`user_id` = blog.`user_id` WHERE post_status = 'Inactive' &&  user.user_id = '".$_SESSION['user']['user_id']."' ORDER BY post_id DESC";
    $result = $user->execute_query($query);
    ?>
    <div class="row ">
        <div class="col-12">
            <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Inactive Post</h1>
        </div>
    </div>
    <?php 
    if ($result->num_rows>0){
    ?>
    <div class="table-responsive">
        <table id="inactive_post" class="hover">
            <thead >
                <tr>
                    <th class="text-center">S.NO</th>
                    <th class="text-center">Featured Image</th>
                    <th class="text-center">Blog Name</th>
                    <th class="text-center">Post Title</th>
                    <th class="text-center">Post Summary</th>
                    <th class="text-center">Description</th>
                    <th class="text-center">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $i=0;
                while ($row = mysqli_fetch_assoc($result)):
                    extract($row);
                ?>
                <tr>
                    <td class="text-center"><?=++$i?></td>
                    <td class="text-center"><img src="<?=$featured_image?>" class="img-thumbnail" alt="..." style="border-radius: 0%; width:70%; height: 100px;"></td>
                    <td class="text-center"><?=$blog_title?></td>
                    <td class="text-center"><?=$post_title?></td>
                    <td class="text-center"><?=substr("$post_summary",0,100).'...'?></td>
                    <td class="text-center"><?=substr("$post_description",0,100).'...'?></td>
                    <td class="text-center"><?=$post_status?></td>
                </tr>
                <?php
                 endwhile;
                ?>
            </tbody>
        </table>
    </div>
    <?php
      }
      else{
          echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
      }
}
// feedback
elseif(isset($action)&& $action=="feedback" ){
    $query = "SELECT * FROM user_feedback ORDER BY feedback_id DESC";
    // echo $query;
    // die;
    $result = $user->execute_query($query);
    ?>
    <div class="row">
        <div class="col-12">
            <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Feedback</h1>
        </div>
    </div>
    <?php if($result->num_rows>0){?>
        <table id="feedback" class="hover">
            <thead>
                <tr> 
                    <th class="text-center">S.NO</th>
                    <th class="text-center">Is Registered</th>
                    <th class="text-center">Full Name</th>
                    <th class="text-center">Email</th>
                    <th class="text-center">Message</th>
                    <th class="text-center">Date</th>
                </tr>
            </thead>
            <tbody>

                <?php
                $i=0;
                while($row = mysqli_fetch_assoc($result)):
                    extract($row);
                    $registered = isset($user_id)&& $user_id!=""?"Registered":"Anonymous";
                    $reg_color = isset($user_id)&& $user_id!=""?"success":"danger";
                ?>
                <tr>
                    <td class="text-center"><?=++$i?></td>
                    <td class="text-center text-<?=$reg_color?>"><?=$registered?></td>
                    <td class="text-center"><?=$user_name?></td>
                    <td class="text-center"><?=$user_email?></td>
                    <td class="text-center"><?=$feedback?></td>
                    <td class="text-center"><?=$created_at?></td>
                </tr>
                <?php
                endwhile;
                ?>
            </tbody>
        </table>
    <?php
        }
        else{
            echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
        }
}
// followers_are
elseif(isset($action)&& $action=="followers_are" ){
    $query = "SELECT user.first_name,user.last_name, blog.blog_title, following_blog.* FROM following_blog JOIN USER ON user.user_id = following_blog.follower_id JOIN blog ON blog.blog_id = following_blog.blog_following_id WHERE following_blog.status='Followed' && blog.user_id='".$_SESSION['user']['user_id']."' ORDER BY follow_id DESC";
    // echo $query;
    // die;
    $result = $user->execute_query($query);
    ?>
    <div class="row">
        <div class="col-12">
            <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Followers</h1>
        </div>
    </div>
    <?php if($result->num_rows>0){?>
        <table id="followers_are" class="hover">
            <thead>
                <tr>
                    <th class="text-center">Full Name</th>
                    <th class="text-center">Blog Title</th>
                    <th class="text-center">Status</th>
                    <th class="text-center">Followed Date</th>
                </tr>
            </thead>
            <tbody>

                <?php
                while($row = mysqli_fetch_assoc($result)):
                    extract($row);
                ?>
                <tr>
                    <td class="text-center"><?=$first_name." ".$last_name?></td>
                    <td class="text-center"><?=$blog_title?></td>
                    <td class="text-center"><?=$status?></td>
                    <td class="text-center"><?=$created_at?></td>
                </tr>
                <?php
                endwhile;
                ?>
            </tbody>
        </table>
    <?php
         }
         else{
             echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
         }
}
// user_status

// negative_comment
elseif(isset($action)&& $action=="comments_are" ){
    $query = "SELECT user.first_name,user.last_name,post.post_title,post_comment.*,blog.blog_title FROM post_comment JOIN user ON post_comment.user_id = user.user_id JOIN post ON post.post_id=post_comment.post_id JOIN blog ON blog.blog_id = post.blog_id WHERE blog.user_id = '".$_SESSION['user']['user_id']."' ORDER BY post_comment_id DESC";
    // echo $query;
    // die;
    $result = $user->execute_query($query);
    ?>
    <div class="row">
        <div class="col-12">
            <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Comments</h1>
        </div>
    </div>
    <?php if($result->num_rows>0){?>
        <table id="comments_are" class="hover">
            <thead>
                <tr>
                    <th class="text-center">S.NO</th>
                    <th class="text-center">Full Name</th>
                    <th class="text-center">Blog Name</th>
                    <th class="text-center">Post Title</th>
                    <th class="text-center">Comment</th>
                    <th class="text-center">Staus</th>
                    <th class="text-center">Comment Date</th>
                    <th class="text-center">Action</th>
                </tr>
            </thead>
            <tbody>

                <?php
                $i=0;
                while($row = mysqli_fetch_assoc($result)):
                    extract($row);
                ?>
                <tr>
                    <td class="text-center"><?=++$i?></td>
                    <td class="text-center"><?=$first_name." ".$last_name?></td>
                    <td class="text-center"><?=$blog_title?></td>
                    <td class="text-center"><?=$post_title?></td>
                    <td class="text-center"><?=$comment?></td>
                    <td class="text-center"><?=$is_active?></td>
                    <td class="text-center"><?=$created_at?></td>
                    <td class="text-center">
                    <button href="#" class="btn btn-primary" onclick="active_comment_status(<?=$post_comment_id?>)">Active</button>
                    <button href="#" class="btn btn-success" onclick="inactive_comment_status(<?=$post_comment_id?>)">Inactive</button>
                    </td>
                </tr>
                <?php
                endwhile;
                ?>
            </tbody>
        </table>
    <?php
        }
    else{
        echo "<p class='rounded bg-danger text-center text-white'>Record Not Found</p>";
    }
}
elseif(isset($action) && $action=="add_user"){
    ?> 
        <div class="container-fluid my-2">
        <div class="row">
        <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Add New User </h1>
            <div class="col-sm-3"></div>
            <div class="col-sm-6" style="overflow: none;">
                <h4 class="my-3 text-center register bg-dark bg-gradient text-light">Add user</h4>
                <form action="process.php" method="POST" enctype="multipart/form-data"
                    onsubmit="return click_submit()">
                    <!-- first name -->
                    <form>
                        <!-- first name  -->
                        <div class="mb-3">
                            <label for="" class="form-label">First Name</label>
                            <div class="d-flex">
                                <span class="input-group-text"> <i class="fa fa-user"></i> </span>
                                <input type="text" class="form-control" name="first_name" id="first_name"
                                    placeholder="Enter Your First Name" required>
                            </div>
                        </div>
                        <!-- last name -->
                        <div class="mb-3">
                            <label for="" class="form-label">Last Name</label>
                            <div class="d-flex">
                                <span class="input-group-text"> <i class="fa fa-user"></i> </span>
                                <input type="text" class="form-control" name="last_name" id="last_name"
                                    placeholder="Enter Your Last Name"required>
                            </div>
                        </div>
                        <!-- email -->
                        <div class="mb-3">
                            <label for="" class="form-label">Email address</label>
                            <div class="d-flex">
                                <span class="input-group-text"> <i class="fa fa-envelope"></i> </span>
                                <input type="email" class="form-control" name="email" id="email"
                                    placeholder="Enter Your Email" required>
                            </div>
                        </div>
                        <!-- password -->
                        <div class="mb-3">
                            <label for="" class="form-label">Password</label>
                            <div class="d-flex">
                                <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
                                <input type="password" class="form-control" name="password" id="password"
                                    placeholder="Enter Your Password" required> 
                                <input type="checkbox" name="" id="check" onchange="showPass(this)">
                            </div>
                        </div>
                        <!-- gender -->
                        <div class="mb-3">
                            <label for="" class="form-label">Gender</label>
                            <div class="d-flex">
                                <span class="input-group-text d-flex"> <i class="fa fa-person-half-dress"></i>
                                </span>
                                <div class=" form-control">
                                    <input type="radio" name="gender" id="" value="Male" required> Male
                                    <input type="radio" name="gender" id="" value="Female" required> Female
                                </div>
                            </div>
                        </div>
                        <!-- date of birth -->
                        <div class="mb-3">
                            <label for="" class="form-label d-block">Date of Birth</label>
                            <div class="d-flex">
                                <span class="input-group-text d-flex"> <i class="fa fa-calendar-days"></i>
                                </span>
                                <div class=" form-control border border-0">
                                    <input type="text" id="date-input" placeholder="Date of Birth"
                                        name="date_of_birth" class="form-control"required />
                                </div>
                            </div>
                        </div>
                        <!-- image -->
                        <div class="mb-3">
                            <label for="" class="form-label">Profile Picture</label>
                            <div class="d-flex">
                                <span class="input-group-text d-flex"> <i class="fa fa-image"></i> </span>
                                <input type="file" name="profile_pic" class="form-control" id="image" required>
                            </div>
                            <div class="rounded p-1 text-center text-white" style="background-color: <?=$_REQUEST['img_color']??""?>;"><?=$_REQUEST['img_msg']??""?></div>
                        </div>
                        <!-- address -->
                        <div class="mb-3">
                            <label for="" class="form-label">Address</label>
                            <div class="d-flex">
                                <span class="input-group-text d-flex"> <i class="fa fa-home"></i> </span>
                                <input type="text" name="address" class="form-control" id="address"
                                    placeholder="Enter Your Address" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label" id="select_role">Select Role Type</label>
                            <div class="form-control">
                                <select name="select_role" class="form-control" required>
                                    <option id="role" value="">...Select One...</option>
                                    <?php
                                        $query = "SELECT * FROM role";
                                        $result = $user->execute_query($query);
                                        // print_r($result);
                                        // die;
                                        if(mysqli_num_rows($result)>0){
                                            while ($row = mysqli_fetch_assoc($result)) {
                                                extract($row);
                                                ?>
                                    <option id="role" value="<?=$role_id?>"><?=$role_type?></option>
                                    <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <!-- submit -->
                        <button type="reset" class="btn btn-danger">Cancel</button>
                        <button type="submit" value="submit" name="admin_register"
                            class="btn btn-primary">Register</button>
                    </form>
                </form>
            </div>
        </div>
        <div class="col-sm-3"></div>
    </div>
    <?php
}
?>