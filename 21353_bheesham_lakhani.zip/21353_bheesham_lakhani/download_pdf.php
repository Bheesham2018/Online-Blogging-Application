<?php
require_once("config/class_object.php");
require_once("fpdf/fpdf.php");

extract($_REQUEST);
if(isset($user_email)){
    $query="SELECT * FROM user WHERE email='".$user_email."'";
    // echo $query;
    // die;
    $result = $user->execute_query($query);
    if($result->num_rows>0){
        $row=mysqli_fetch_assoc($result);
        extract($row);
        $download_pdf = new FPDF();
        $download_pdf->Addpage();
        $download_pdf->setFont("Times","B","24");
        $download_pdf->Cell(0,10,"Your Data",1,0,"C",0);
        $download_pdf->setFont("Times","I","24");
        $download_pdf->ln(50);
        $download_pdf->Cell(0,10,"Name : ".$first_name." ".$last_name,0,1,"C",0);
        $download_pdf->Cell(0,10,"Email : ".$email,0,1,"C",0);
        $download_pdf->Cell(0,10,"Password : ".$password,0,1,"C",0);
        $download_pdf->Output("D","$first_name.pdf");

    }
    else{
        header("location:login.php?msg=You have already downloaded The Data&color=red");
    }
}
else{
    header("location:login.php?msg=Something went wrong Try Again.....!&color=red");
}


?>