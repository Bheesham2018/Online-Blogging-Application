	<?php
	// session_start();
	if(!isset($_REQUEST['title'])&&$_REQUEST['title']!=='Home'){
		header("locaion:login.php?msg=Please Login First&color=red&title=Home");
		die;
	}
	require_once("config/class_object.php");
	include_once("header_and_footer/headers.php");
	extract($_REQUEST);
	// echo "<pre>";
	// print_r($_REQUEST);
	// print_r($_FILES);
	// echo "</pre>";
	// die;
	?>
	<?php
	if(isset($action) && $action=="edit_blog"){
		$query = "SELECT * FROM blog WHERE blog_id = '".$blog_id."'";
		// echo $query;
		$result = $user->execute_query($query);
		if($result->num_rows>0){
			$row = mysqli_fetch_assoc($result);
			extract($row);
			?>
			<div class="container-fluid">
		        <div class="row">
		            <div class="col-12">
		                <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Edit Blog</h1>
		            </div>
		            <div class="col-sm-3"></div>
		            <div class="col-sm-6">
		                 <form action="process.php" method="POST" enctype="multipart/form-data"> <!--onsubmit="return _blog_()" -->
		                    <div class="mb-3">
		                        <label for="" class="form-label">Blog Name</label>
		                        <input type="text" id="title_outline" name="blog_title" class="form-control" value="<?=$blog_title?>" required>
		                    </div>
		                    <div class="mb-3">
		                        <label for="" class="form-label">Post Per Page</label>
		                        <input type="number" id="post_per_page" name="post_per_page" class="form-control" value="<?=$post_per_page?>" required>
		                    </div>
		                    <div class="mb-3" >
		                        <label for="" class="form-label">Blog Background Image</label><span class="mx-3"><img  class="rounded-pill" src="<?=$blog_background_image?>" height="30" width="30" alt=""></span>
		                        <div class="text-start">
									<input type="hidden" name="old_image" id="" value="<?=$blog_background_image?>">
									<input type="file" name="new_image" class="form-control">
								</div>
		                    </div>
							<input type="hidden" name="blog_id" value="<?=$blog_id?>"/>
		                    <button type="reset" class="btn btn-danger">Cancel</button>
		                    <button type="submit" name="update_blog" value="edit_blog" class="btn btn-primary">Update</button>
		                </form>
		            </div>
		            <div class="col-sm-3"></div>
		        </div>
		    </div>
			<?php
		}
	}
	elseif(isset($action)&& $action=="edit_post"){
		$query= "SELECT * FROM post WHERE post_id = '".$update_post_id."'";
		$result = $user->execute_query($query);
		$rows = mysqli_fetch_assoc($result);
		extract($rows);
		// echo "kdnssdkl";
		?>
		<div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Update Post</h1>
	            </div>
		            <div class="col-sm-3"></div>
		            <div class="col-sm-6">
		                <form action="process.php" method="POST" enctype="multipart/form-data">
		                    <div class="mb-3">
		                        <label for="" class="form-label">Post Title</label>
		                        <input type="text" name="post_title" class="form-control" value="<?=$post_title?>" required>
		                    </div>
		                    <div class="mb-3">
		                        <label for="" class="form-label">Post Summary</label>
		                        <textarea type="text" name="post_summary" class="form-control"  rows="6" required> <?=$post_summary?></textarea>
		                    </div>
		                    <div class="mb-3">
		                        <label for="" class="form-label">Featured Image</label>
		                        <input type="hidden" name="old_post_image" id="" value="<?=$featured_image?>"> <span><img src="<?=$featured_image?>" alt="" height="20"></span>
		                        <input type="file" name="post_image" class="form-control">
		                    </div>
		                    <label for="" class="form-label d-flex">Enter your Attachment Number</label>
		                    <div class="mb-3 d-flex">
		                        <input type="number" id="number_of_attachment" name="attachment" class="form-control d-flex">
		                        <input type="button" onclick="numberAttachment()" name="add_attachment" value="+" class="btn btn-primary"/>
		                    </div>
		                    <div class="mb-3" id="attachment_number">
		                        
		                    </div>
		                    <div class="mb-3">
		                        <label  class="form-label">Short Description</label>
		                        <textarea type="text" name="post_desc" class="form-control" placeholder="Short Description" rows="10" required><?=$post_description?></textarea>
		                    </div>
		                    <div class="mb-3">
		                    <label  class="form-label">Comment</label>
		                        <div class=" form-control">
		                        	<?php 
		                        	// $check = (isset($is_comment_allowed)&& $is_comment_allowed==1)?"checked":"";
		                        	// echo $check;
		                        	?>
		                            <input type="radio" name="comment" id="" value="1" required> Allow
		                            <input type="radio" name="comment" id="" value="0" required> Not Allowed
		                        </div>
		                    </div>
		                    <div class="mb-3">
		                        <label for="" class="form-label" id="select_blog">Select Blog</label>
		                        <div class="form-control">
		                            <select name="select_blog" id="example" class="form-control" required>
		                                <option id="blog" value="">...Select One...</option>
		                                <?php
		                                    $query = "SELECT * FROM blog WHERE user_id = '".$_SESSION['user']['user_id']."'";
		                                    // echo $query;
		                                    // die;
		                                    $result = $user->execute_query($query);
		                                    // print_r($result);
		                                    // die;
		                                    if(mysqli_num_rows($result)>0){
		                                        while ($row = mysqli_fetch_assoc($result)) {
		                                            extract($row);
		                                            $selected = isset($blog_title)?"Selected":"";
		                                            ?>
		                                <option value="<?=$blog_id?>" <?=$selected?> ><?=$blog_title?></option>
		                                <?php
		                                    }
		                                }
		                                ?>
		                            </select>
		                        </div>
		                    </div>
		                    <div class="mb-3">
							<label for="" class="form-label">Select Category</label>
							<div class="btn-group d-block" role="group" aria-label="Basic checkbox toggle button group">
							<div class="mb-3 form-control" >
								<?php
								$query = "SELECT * FROM category WHERE category_status='Active'";
								$result = $user->execute_query($query);
								if($result->num_rows>0):
									// $i=0;
									?>
									<!-- <select id="Multi-select-category" name="Multiple" data-placeholder="Select Category" multiple data-multi-select> -->
									<?php 
									while($row = mysqli_fetch_assoc($result)):
										// $i++;
										extract($row);

								?>
									<!-- <option value=""></option> -->
									<input type="checkbox" name="category[]" id="" value="<?=$category_id?>"> <?=$category_title?> <br>
									<?php
									endwhile;
									?>
									<!-- </select> -->
									<?php
								endif;
                                ?>
                            </div>
                        </div>
                    </div>
		                    <button type="submit" class="btn btn-danger">Cancel</button>
		                    <input type="hidden" name="update_post_id" value="<?=$update_post_id?>">
		                    <button type="submit" name="edit_post_with_attachment" value="edit_post" class="btn btn-primary">Add Post</button>
		                </form>
		            </div>
		            <div class="col-sm-3"></div>
		        </div>
		    </div>
	<?php
	}
	elseif(isset($action) && $action=="edit_category"){
		// echo "<pre>";
		// print_r($_REQUEST);
		// echo "</pre>";
		// die;
		$query = "SELECT * FROM category WHERE category_id = '".$category_id."'";
		$result = $user->execute_query($query);
		$row = mysqli_fetch_assoc($result);
		extract($row);
		?>
		<div class="container-fluid">
		        <div class="row">
		            <div class="col-12">
		                <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center">Edit Category</h1>
		            </div>
		            <div class="col-sm-3"></div>
		            <div class="col-sm-6">
		                 <form action="process.php" method="POST" enctype="multipart/form-data"> <!--onsubmit="return _blog_()" -->
		                    <div class="mb-3">
		                        <label for="" class="form-label">Category Title</label>
		                        <input type="text" id="title_outline" name="category_title" class="form-control" value="<?=$category_title?>" required>
		                    </div>
		                    <div class="mb-3">
		                        <label for="" class="form-label">Category Description</label>
		                        <textarea type="text"  name="category_description" class="form-control" rows="10" required> <?=$category_description?></textarea>
		                    </div>
							<input type="hidden" name="category_id" value="<?=$category_id?>"/>
		                    <button type="reset" class="btn btn-danger">Cancel</button>
		                    <button type="submit" name="update_category" value="edit_category" class="btn btn-primary">Update</button>
		                </form>
		            </div>
		            <div class="col-sm-3"></div>
		        </div>
		    </div>
		<?php

	}

	elseif (isset($action)&& $action =="edit_user_detail") {
		// echo "<pre>";
		// print_r($_REQUEST);
		// echo "</pre>";
		// die;

		$query = "SELECT * FROM user WHERE user_id = $user_id";
		$result = $user->execute_query($query);
		if ($result->num_rows>0) {
			$row = mysqli_fetch_assoc($result);
			extract($row);
		?>

			<div class="container-fluid my-2">
				<div class="row">
					<div class="col-sm-3"></div>
					<div class="col-sm-6" style="overflow: none;">
						<p class="rounded p-1 text-center text-white" style="background-color: <?=$_REQUEST['color']??""?>;"><?=$_REQUEST['msg']??""?></p>
						<h4 class="my-3 text-center register bg-dark bg-gradient text-light">Update Profile</h4>
							<form action="process.php" method="POST" enctype="multipart/form-data">
								<!-- first name  -->
								<div class="mb-3">
									<div class="text-center">
										<img src="<?=$user_image?>" class="rounded-pill" alt="..." style="height: 200px; width: 25%;">
									</div>
								</div>	
							<div class="mb-3">
								<label for="" class="form-label">First Name</label>
								<div class="d-flex">
									<span class="input-group-text"> <i class="fa fa-user"></i> </span>
									<input type="text" name="first_name" class="form-control f_name" id="first_name" placeholder="Enter Your First Name" value="<?=$first_name?>">
								</div>
							</div>
							<!-- last name -->
							<div class="mb-3">
								<label for="" class="form-label">Last Name</label>
								<div class="d-flex">
									<span class="input-group-text"> <i class="fa fa-user"></i> </span>
									<input type="text" name="last_name" class="form-control l_name" id="last_name" placeholder="Enter Your Last Name" value="<?=$last_name?>">
								</div>
							</div>
							<!-- email -->
							<div class="mb-3">
								<label for="" class="form-label">Email address</label>
								<div class="d-flex">
									<span class="input-group-text"> <i class="fa fa-envelope"></i> </span>
									<input type="email" name="email" class="form-control email" id="email" placeholder="Enter Your Email" value="<?=$email?>" readonly>
								</div>
									<div id="email_message" class="message_color"></div>
							</div>
							<!-- password -->
							<div class="mb-3">
								<label for="" class="form-label">Password</label>
								<div class="d-flex">
									<span class="input-group-text"> <i class="fa fa-lock"></i> </span>
									<input type="password" name="password" class="form-control password" id="password" placeholder="Enter Your Password" minlength="8" value="<?=$password?>" readonly>
									<input type="checkbox" name="" id="check" onchange="showPass(this)">
								</div>				    	
							</div>
							<!-- gender -->
							<div class="mb-3">
								<label for="" class="form-label">Gender</label>
								<div class="d-flex">
									<span class="input-group-text d-flex"> <i class="fa fa-person-half-dress"></i> </span>
									<div class=" form-control gender">
										<input type="radio"  name="gender" id="" value="<?=$gender?>" 
										<?php 
										if(isset($gender) && $gender=='Male')
											echo "checked";

										?>
									> Male
										<input type="radio"  name="gender" id="" value="<?=$gender?>" <?php 
										if (isset($gender) && $gender=='Female')
											echo "checked";
										?>> Female
									</div>
								</div>
							</div>
							<!-- date of birth -->
							<div class="mb-3">
								<label for="" class="form-label d-block">Date of Birth</label>
								<div class="d-flex">	
									<span class="input-group-text d-flex"> <i class="fa fa-calendar-days"></i> </span>
									<div class=" form-control date">
										<input type="text" id="date-input" name="date_of_birth" placeholder="Enter your Date of Birth" class="form-control " value="<?=$date_of_birth?>" />
									</div>
								</div>
							</div>
							<!-- image -->
							<div class="mb-3">
								<input type="hidden" name="old_user_image" value="<?=$user_image?>">
								<label for="" class="form-label">Profile Picture</label>
								<div class="d-flex">
									<span class="input-group-text d-flex"> <i class="fa fa-image"></i> </span>
									<input type="file" class="form-control" name="new_profile_pic" id="image">
								</div>
								<div class="rounded p-1 text-center text-white "> style="background-color:<?$_REQUEST['color']?>;"><?=$_REQUEST['img_msg']??""?></div>
							</div>
							<!-- address -->
							<div class="mb-3">
								<label for="" class="form-label">Address</label>
								<div class="d-flex">
									<span class="input-group-text d-flex"> <i class="fa fa-home"></i> </span>
									<input type="text" class="form-control address" name="address" id="address"placeholder="Enter Your Address" value="<?=$address?>">
								</div>
							</div>
							<div class="mb-3">
									<label for="" class="form-label" id="select_role">Select Role Type</label>
									<div class="form-control">
										<select name="select_role" class="form-control" required>
											<option id="role" value="">...Select One...</option>
											<?php
												$query = "SELECT * FROM role";
												$result = $user->execute_query($query);
												// print_r($result);
												// die;
												if(mysqli_num_rows($result)>0){
													while ($row = mysqli_fetch_assoc($result)) {
														extract($row);
														?>
											<option id="role" value="<?=$role_id?>"><?=$role_type?></option>
											<?php
												}
											}
											?>
										</select>
									</div>
							</div>
							<!-- submit -->
							<input type="hidden" name="user_id_is" value="<?=$user_id?>">
							<button type="reset" class="btn btn-danger">Cancel</button>
							<button type="submit" value="edit_user_detail" name="edit_user_detail" class="btn btn-primary">Edit User Detail</button>
							</form>
						</div>
					</div>
					<div class="col-sm-3"></div>
				</div>
			</div>
		<?php
		}
	}
	elseif (isset($action)&& $action =="edit_admin_detail") {
		// echo "<pre>";
		// print_r($_REQUEST);
		// echo "</pre>";
		// die;

		$query = "SELECT * FROM user WHERE user_id = $user_id";
		$result = $user->execute_query($query);
		if ($result->num_rows>0) {
			$row = mysqli_fetch_assoc($result);
			extract($row);
		?>

			<div class="container-fluid my-2">
				<div class="row">
					<div class="col-sm-3"></div>
					<div class="col-sm-6" style="overflow: none;">
						<p class="rounded p-1 text-center text-white" style="background-color: <?=$_REQUEST['color']??""?>;"><?=$_REQUEST['msg']??""?></p>
						<h4 class="my-3 text-center register bg-dark bg-gradient text-light">Update Profile</h4>
							<form action="process.php" method="POST" enctype="multipart/form-data">
								<!-- first name  -->
								<div class="mb-3">
									<div class="text-center">
										<img src="<?=$user_image?>" class="rounded-pill img-fluid" style="height: 200px; width:25%" alt="..." >
									</div>
								</div>	
							<div class="mb-3">
								<label for="" class="form-label">First Name</label>
								<div class="d-flex">
									<span class="input-group-text"> <i class="fa fa-user"></i> </span>
									<input type="text" name="first_name" class="form-control f_name" id="first_name" placeholder="Enter Your First Name" value="<?=$first_name?>">
								</div>
							</div>
							<!-- last name -->
							<div class="mb-3">
								<label for="" class="form-label">Last Name</label>
								<div class="d-flex">
									<span class="input-group-text"> <i class="fa fa-user"></i> </span>
									<input type="text" name="last_name" class="form-control l_name" id="last_name" placeholder="Enter Your Last Name" value="<?=$last_name?>">
								</div>
							</div>
							<!-- email -->
							<div class="mb-3">
								<label for="" class="form-label">Email address</label>
								<div class="d-flex">
									<span class="input-group-text"> <i class="fa fa-envelope"></i> </span>
									<input type="email" name="email" class="form-control email" id="email" placeholder="Enter Your Email" value="<?=$email?>">
								</div>
									<div id="email_message" class="message_color"></div>
							</div>
							<!-- password -->
							<div class="mb-3">
								<label for="" class="form-label">Password</label>
								<div class="d-flex">
									<span class="input-group-text"> <i class="fa fa-lock"></i> </span>
									<input type="password" name="password" class="form-control password" id="password" placeholder="Enter Your Password" minlength="8" value="<?=$password?>" >
									<input type="checkbox" name="" id="check" onchange="showPass(this)">
								</div>				    	
							</div>
							<!-- gender -->
							<div class="mb-3">
								<label for="" class="form-label">Gender</label>
								<div class="d-flex">
									<span class="input-group-text d-flex"> <i class="fa fa-person-half-dress"></i> </span>
									<div class=" form-control gender">
										<input type="radio"  name="gender" id="" value="<?=$gender?>" 
										<?php 
										if(isset($gender) && $gender=='Male')
											echo "checked";

										?>
									> Male
										<input type="radio"  name="gender" id="" value="<?=$gender?>" <?php 
										if (isset($gender) && $gender=='Female')
											echo "checked";
										?>> Female
									</div>
								</div>
							</div>
							<!-- date of birth -->
							<div class="mb-3">
								<label for="" class="form-label d-block">Date of Birth</label>
								<div class="d-flex">	
									<span class="input-group-text d-flex"> <i class="fa fa-calendar-days"></i> </span>
									<div class=" form-control date">
										<input type="text" id="date-input" name="date_of_birth" placeholder="Enter your Date of Birth" class="form-control " value="<?=$date_of_birth?>" />
									</div>
								</div>
							</div>
							<!-- image -->
							<div class="mb-3">
								<input type="hidden" name="old_admin_image" value="<?=$user_image?>">
								<label for="" class="form-label">Profile Picture</label>
								<div class="d-flex">
									<span class="input-group-text d-flex"> <i class="fa fa-image"></i> </span>
									<input type="file" class="form-control" name="new_admin_image" id="image">
								</div>
								<div class="rounded p-1 text-center text-white "> style="background-color:<?$_REQUEST['color']?>;"><?=$_REQUEST['img_msg']??""?></div>
							</div>
							<!-- address -->
							<div class="mb-3">
								<label for="" class="form-label">Address</label>
								<div class="d-flex">
									<span class="input-group-text d-flex"> <i class="fa fa-home"></i> </span>
									<input type="text" class="form-control address" name="address" id="address"placeholder="Enter Your Address" value="<?=$address?>">
								</div>
							</div>
							<!-- submit -->
							<input type="hidden" name="admin_id" value = "<?=$user_id?>">
							<button type="reset" class="btn btn-danger">Cancel</button>
							<button type="submit" value="admin_detail_edit" name="edit_admin_detail" class="btn btn-primary">Edit  Detail</button>
							</form>
						</div>
					</div>
					<div class="col-sm-3"></div>
				</div>
			</div>
		<?php
		}
	}
	elseif(isset($action) && $action == "edit_profile_by_user") {
		// echo "<pre>";
		// print_r($_REQUEST);
		// echo "</pre>";
		// die;
		// echo $user_id;
		// die;
		$query = "SELECT * FROM user WHERE user_id = $user_id";
		// echo $query;
		// die;
		$result = $user->execute_query($query);
		if ($result->num_rows>0) {
			$row = mysqli_fetch_assoc($result);
			extract($row);
		?>

			<div class="container-fluid my-2">
				<div class="row">
					<div class="col-sm-3"></div>
					<div class="col-sm-6" style="overflow: none;">
						<p class="rounded p-1 text-center text-white" style="background-color: <?=$_REQUEST['color']??""?>;"><?=$_REQUEST['msg']??""?></p>
						<h4 class="my-3 text-center register bg-dark bg-gradient text-light">Update Profile</h4>
							<form action="process.php" method="POST" enctype="multipart/form-data">
								<!-- first name  -->
								<div class="mb-3">
									<div class="text-center">
										<img src="<?=$user_image?>" class="rounded-pill" alt="..." style="height: 200px; width: 25%;">
									</div>
								</div>	
							<div class="mb-3">
								<label for="" class="form-label">First Name</label>
								<div class="d-flex">
									<span class="input-group-text"> <i class="fa fa-user"></i> </span>
									<input type="text" name="first_name" class="form-control f_name" id="first_name" placeholder="Enter Your First Name" value="<?=$first_name?>">
								</div>
							</div>
							<!-- last name -->
							<div class="mb-3">
								<label for="" class="form-label">Last Name</label>
								<div class="d-flex">
									<span class="input-group-text"> <i class="fa fa-user"></i> </span>
									<input type="text" name="last_name" class="form-control l_name" id="last_name" placeholder="Enter Your Last Name" value="<?=$last_name?>">
								</div>
							</div>
							<!-- email -->
							<div class="mb-3">
								<label for="" class="form-label">Email address</label>
								<div class="d-flex">
									<span class="input-group-text"> <i class="fa fa-envelope"></i> </span>
									<input type="email" name="email" class="form-control email" id="email" placeholder="Enter Your Email" value="<?=$email?>">
								</div>
									<div id="email_message" class="message_color"></div>
							</div>
							<!-- password -->
							<div class="mb-3">
								<label for="" class="form-label">Password</label>
								<div class="d-flex">
									<span class="input-group-text"> <i class="fa fa-lock"></i> </span>
									<input type="password" name="password" class="form-control password" id="password" placeholder="Enter Your Password" minlength="8" value="<?=$password?>" >
									<input type="checkbox" name="" id="check" onchange="showPass(this)">
								</div>				    	
							</div>
							<!-- gender -->
							<div class="mb-3">
								<label for="" class="form-label">Gender</label>
								<div class="d-flex">
									<span class="input-group-text d-flex"> <i class="fa fa-person-half-dress"></i> </span>
									<div class=" form-control gender">
										<input type="radio"  name="gender" id="" value="<?=$gender?>" 
										<?php 
										if(isset($gender) && $gender=='Male')
											echo "checked";

										?>
									> Male
										<input type="radio"  name="gender" id="" value="<?=$gender?>" <?php 
										if (isset($gender) && $gender=='Female')
											echo "checked";
										?>> Female
									</div>
								</div>
							</div>
							<!-- date of birth -->
							<div class="mb-3">
								<label for="" class="form-label d-block">Date of Birth</label>
								<div class="d-flex">	
									<span class="input-group-text d-flex"> <i class="fa fa-calendar-days"></i> </span>
									<div class=" form-control date">
										<input type="text" id="date-input" name="date_of_birth" placeholder="Enter your Date of Birth" class="form-control " value="<?=$date_of_birth?>" />
									</div>
								</div>
							</div>
							<!-- image -->
							<div class="mb-3">
								<input type="hidden" name="old_user_image" value="<?=$user_image?>">
								<label for="" class="form-label">Profile Picture</label>
								<div class="d-flex">
									<span class="input-group-text d-flex"> <i class="fa fa-image"></i> </span>
									<input type="file" class="form-control" name="edit_image_by_user" id="image">
								</div>
								<div class="rounded p-1 text-center text-white "> style="background-color:<?$_REQUEST['color']?>;"><?=$_REQUEST['img_msg']??""?></div>
							</div>
							<!-- address -->
							<div class="mb-3">
								<label for="" class="form-label">Address</label>
								<div class="d-flex">
									<span class="input-group-text d-flex"> <i class="fa fa-home"></i> </span>
									<input type="text" class="form-control address" name="address" id="address"placeholder="Enter Your Address" value="<?=$address?>">
								</div>
							</div>
							<!-- submit -->
							<input type="hidden" name="user_id_is" value="<?=$user_id?>">
							<button type="reset" class="btn btn-danger">Cancel</button>
							<button type="submit" value="edit_detail_by_user" name="edit_detail_by_user" class="btn btn-primary">Edit User Detail</button>
							</form>
						</div>
					</div>
					<div class="col-sm-3"></div>
				</div>
			</div>
		<?php
		}
	}
	// print_r($_REQUEST);
	elseif(isset($action) && $action=="theme_setting"){
		// print_r($_REQUEST);
		?>
		<div class="container-fluid my-2">
				<div class="row">
					<div class="col-sm-3"></div>
					<div class="col-sm-6" style="overflow: none;">
						<p class="rounded p-1 text-center text-white" style="background-color: <?=$_REQUEST['color']??""?>;"><?=$_REQUEST['msg']??""?></p>
						<h4 class="my-3 text-center register bg-dark bg-gradient text-light">Theme setting</h4>
						<form action="process.php" method="POST">
						  <div class="mb-3">
						    <label  class="form-label">Font-family</label>
						    <input type="text" class="form-control"name="theme[font_family]" >
						  </div>
						  <div class="mb-3">
						    <label  class="form-label">Post Background Color</label>
						    <input type="text" class="form-control" name="theme[post_bg_color]" >
						  </div>
						  <div class="mb-3">
						    <label  class="form-label">Post Title Color</label>
						    <input type="text" class="form-control" name="theme[title_color]" >
						  </div>
						  <div class="mb-3">
						    <label  class="form-label">Post Description Text Color Color</label>
						    <input type="text" class="form-control" name="theme[desc_text_color]" >
						  </div>
						  <div class="mb-3">
						    <label  class="form-label">Post Description Background Color</label>
						    <input type="text" class="form-control" name="theme[post_desc_bg_color]" >
						  </div>
						  <div class="mb-3">
						    <label  class="form-label">Post Title Font Size</label>
						    <input type="text" class="form-control" name="theme[title_font_size]">
						  </div>
						  <div class="mb-3">
						    <label  class="form-label">Post Description Font Size</label>
						    <input type="text" class="form-control" name="theme[desc_font_size]">
						  </div>
						  <div class="form-check">
							  <input class="form-check-input" type="radio" name="_theme_setting" id="exampleRadios1" value="Active" checked >
							  <label class="form-check-label" for="exampleRadios1">
							    Active Theme Setting
							  </label>
							</div>
							<div class="form-check">
							  <input class="form-check-input" type="radio" name="_theme_setting" id="exampleRadios2" value="Inactive" >
							  <label class="form-check-label" for="exampleRadios2">
							   Inactive Theme Setting
							  </label>
							</div>

						  <input type="submit" class="btn btn-primary" name="theme_setting" value="Change Theme" id="">
						  <input type="reset" class="btn btn-danger" value="Cancel" id="">

						</form>

					</div>
					<div class="col-3"></div>
				</div>
			</div>


		<?php
	}
	include_once("header_and_footer/footers.php");
	?>