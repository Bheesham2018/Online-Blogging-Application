<?php
if(!isset($_REQUEST['title'])&& $_REQUEST['title']!=="View_Post"){
    header("index.php?title=Home");
    die;
}
require_once("config/class_object.php");
include_once("header_and_footer/headers.php");
?>
<?php
extract($_REQUEST);
// print_r($_REQUEST);
if(isset($action) && $action=="total_post"){
    $query = "SELECT * FROM setting WHERE setting_status='Active'&& user_id = '".$_SESSION['user']['user_id']."'";
    // echo $query;
    // die;
    $result = $user->execute_query($query);
    if ($result->num_rows>0) {
        $value=[];
        while($row=mysqli_fetch_assoc($result)){
            extract($row);
            $value["$setting_key"] = "$setting_value";
        }
    extract($value);

    }
    // print_r($value);
    // echo $post_bg_color;
    // die;
    $query = "SELECT post.*, blog.blog_title, user.first_name, user.last_name FROM post JOIN blog ON blog.blog_id = post.blog_id JOIN user ON user.user_id = blog.user_id  WHERE post_id ='".$post_id."' && post_status = 'Active'";
    // echo $query;
    $result = $user->execute_query($query);
    ?>
    <div class="container-fluid">
        <div class="row mx-0 bg-dark bg-gradient text-light">
			<h3 class=" my-1 rounded text-center">Post</h3>
        </div>
    </div>
    <?php
    if($result->num_rows>0){
        $row=mysqli_fetch_assoc($result);
        extract($row);
        ?>
        <?php $font_family = $font_family??"New Times Roman";?>
        <div class="container-fluid my-2" style="font-family: <?=$font_family?>;">
            <?php 
            $post_bg_color = $post_bg_color??"rgb(212 212 216)";
            ?>
        <div class="row  m-0 my-3 text-<?=$post_bg_text_color?>" style="background-color: <?=$post_bg_color?>;">
				<div class="col-sm-3 justify-content-center">
					<img src="<?=$featured_image?>" class=" my-2"  alt="" style="height: 15rem;width: 100%;">
				</div>
				<div class="col-sm-3">
					<div class="row">
						<div class="col-12">
                            <?php 
                            $title_font_size=$title_font_size??0;
                            $title_color=$title_color??"black"
                            ?>
							<h2 class="fs-<?=$title_font_size?> text-<?=$title_color?>"><i><b>Blog:</b></i> <?=$blog_title?></h2>
                            <h2 class="fs-<?=$title_font_size?> text-<?=$title_color?>"><i><b>Author:</b></i> <?=$first_name." ".$last_name?></h2>
						</div>
					</div>
					<div class="row">
						<div class="col-12">
							<h6 class="text-<?=$title_color?>"><?=$created_at?></h6>
						</div>
					</div>
					
                <?php
                $categories="SELECT post.post_id, category.category_title FROM post JOIN post_category ON post.post_id = post_category.post_id JOIN category ON post_category.category_id=category.category_id WHERE post.post_id='".$post_id."'";
                $post_result = $user->execute_query($categories);
                ?>
                <h4 class="fs-<?=$title_font_size?> text-<?=$title_color?>"><b><i> Categories </i> </b></h4>

                <?php
               if($post_result->num_rows>0){
                 while($posts = mysqli_fetch_assoc($post_result)){
                    extract($posts);
                    ?>
                    <div class="row">
                        <div class="col-12">
                            <span class="rounded bg-warning bg-gradient-subtile px-1"><?=$category_title?></span>
                        </div>
                    </div>
                    <?php
                }
               }
               else{
                ?>
                <div class="row">
                        <div class="col-12">
                            <span class="rounded bg-warning bg-gradient-subtile px-1">No Category Selected</span>
                        </div>
                    </div>
                <?php
               }
                ?>
                            
						
				</div>
				<div class="col-sm-6">
                    <?php 
                    $desc_text_color = $desc_text_color??"black";
                    $post_desc_bg_color = $post_desc_bg_color??"rgb(212 212 216)";
                    $desc_font_size = $desc_font_size??0;
                    ?>
                    <h4 class="fs-<?=$desc_font_size?>  text-<?=$desc_text_color?>" style="background-color:<?=$post_desc_bg_color?>">Post Title</h4>
					<p class="fs-<?=$desc_font_size?>  text-<?=$desc_text_color?>" style="background-color:<?=$post_desc_bg_color?>"><?=$post_title?></p>
                    <h4 class="fs-<?=$desc_font_size?>  text-<?=$desc_text_color?>" style="background-color:<?=$post_desc_bg_color?>">Post Summary</h4>
					<p class="fs-<?=$desc_font_size?>  text-<?=$desc_text_color?>" style="background-color:<?=$post_desc_bg_color?>"><?=$post_summary?></p>
                    <h4 class="fs-<?=$desc_font_size?>  text-<?=$desc_text_color?>" style="background-color:<?=$post_desc_bg_color?>">Post Description</h4>
                    <p class="fs-<?=$desc_font_size?>  text-<?=$desc_text_color?>" style="background-color:<?=$post_desc_bg_color?>"><?=$post_description?></p>

                    <?php
                    $attachment_result = "SELECT * FROM post_atachment WHERE post_id = '".$post_id."'";
                    $attachment_result=$user->execute_query($attachment_result);
                    while($result_are = mysqli_fetch_assoc($attachment_result)){
                        extract($result_are);
                        // echo $post_attachment_path;
                        ?>
                        <div class="row">
                            <div class="col-12">
                               <div class="links">
                                <?php
                                $explode = explode('.',"$post_attachment_path");
                                if(isset($explode[1])&&($explode[1]=='jpeg' || $explode[1]=='png'||$explode[1]=='svg'||$explode[1]=='webp'||$explode[1]=='jpg')){
                                    ?>
                                    <a href="<?=$post_attachment_path?>" target="_blank" ><?=$post_attachment_title?></a>
                                    <?php
                                }
                                else{
                                    ?>
                                     <a href="<?=$post_attachment_path?>" target="_blank" download><?=$post_attachment_title?></a>
                                    <?php
                                }
                                ?>
                               </div>
                            </div>
                        </div>
                        <?php
                    }
                    ?>
                       <div class="row">
                           <div class="col-5"></div>
                           <div class="col-4"></div>
                           <div class="col-3">
                              <?php
                              $query_of_comment = "SELECT user.user_image,user.first_name, user.last_name, post_comment.* FROM post_comment JOIN post ON post.post_id=post_comment.post_id JOIN user ON post_comment.user_id = user.user_id WHERE post.post_id='".$post_id."' && post_comment.is_active='Active' ";
                              // echo $query_of_comment;
                              $query_of_comment_execute=$user->execute_query($query_of_comment);
                              // die;
                              if($query_of_comment_execute->num_rows>2){
                                ?>
                                <button type="button" class="btn btn-success float-end show" onclick="show_all_comments(<?=$post_id?>)">View Comments</button>
                               <button type="button" class="btn btn-success float-end hide" onclick="hide_all_comments(<?=$post_id?>)" style ="display: none;">Hide Comments</button>
                                <?php
                              }
                              ?>
                           </div>
                       </div>

                    <?php
                    $get_comment = "SELECT user.user_image,user.first_name, user.last_name, post_comment.* FROM post_comment JOIN post ON post.post_id=post_comment.post_id JOIN user ON post_comment.user_id = user.user_id WHERE post.post_id='".$post_id."' && post_comment.is_active='Active' ORDER BY post_comment_id DESC LIMIT 2";
                    // echo $get_comment;
                    // die;
                    $comment_result = $user->execute_query($get_comment);
                    // print_r($comment_result);
                    // die;
                    ?>
                    <div id="comments_hide">
                    <?php
                    while($comments = mysqli_fetch_assoc($comment_result)){
                        extract($comments);
                        ?>
                        <div class="row my-2  mx-0 text-<?=$title_color?>" >
                            <div class="col-sm-8  border rounded" >
                                <div class="d-flex">
                                    <img src="<?=$user_image?>" style="height:40px; width:40px;" class="img-thumbnail rounded-pill" alt="...">
                                    <h5><?=$first_name." ".$last_name?></h5>
                                    </div>
                                <div class="row">
                                    <div class="col-1"></div>
                                    <div class="col-11">
                                        <p><?=$created_at?></p> 
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-1"></div>
                                    <div class="col-11">
                                        <p><?=$comment?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    ?>
                    </div>
                        <div id="all_comments">  
                        </div>
				</div>
                
                <div class="row my-2">
                <div class="col-sm-6"></div>
                <div class="col-sm-6">
                <div class="mb-3 d-flex">
                <?php if($is_comment_allowed==1){
                    ?>
                    <input type="text" class="form-control " id="send_comment" placeholder="Send Comment" required>
                    <button type="btn" class="btn btn-primary" onclick="send_comment(<?=$post_id?>)">Send</button>
                    <?php
                    }
                    ?>   
                    </div>
                </div>
                </div>
			</div>
                        
        </div>
        <?php
    }
    ?>
    <?php
}

?>

<?php
include_once("header_and_footer/footers.php");
?>