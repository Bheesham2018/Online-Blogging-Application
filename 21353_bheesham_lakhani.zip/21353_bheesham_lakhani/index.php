<?php
	// session_start();
require_once("config/class_object.php");
include_once("header_and_footer/headers.php");
?>
<!-- left-side bar -->
<div class="container-fluid my-2" id="about">
	<div class="row bg-light">
		<div class="col-sm-12"> 
			<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
				<div class="carousel-inner">
					<div class="carousel-item active">
					<img src="https://thumbs.dreamstime.com/b/old-book-flying-letters-magic-light-background-bookshelf-library-ancient-books-as-symbol-knowledge-history-218640948.jpg" class="d-block w-100" height="400" alt="...">
					</div>
					<div class="carousel-item">
					<img src="https://www.strath.ac.uk/media/1newwebsite/departmentsubject/education/1600x600/education_title_2.jpg" class="d-block w-100" height="400" alt="...">
					</div>
					<div class="carousel-item">
					<img src="https://www.solimarinternational.com/wp-content/uploads/iStock-2151948886.jpg" class="d-block w-100" height="400" alt="...">
					</div>
					<div class="carousel-item">
					<img src="https://indiaforbeginners.com/wp-content/uploads/2023/05/iStock-635726296-Taj-Mahal-2-768x508.jpg" class="d-block w-100" height="400" alt="...">
					</div>
					<div class="carousel-item">
					<img src="https://www.checkfront.com/wp-content/uploads/2022/05/img_62749d7437998.jpg" class="d-block w-100" height="400" alt="...">
					</div>
					<div class="carousel-item">
					<img src="https://cdn.prod.website-files.com/5e0f1144930a8bc8aace526c/65dd33d49a346d9be0b075ea_65dd12fa299e167d189f00f7-fed9c2116dfcf56370cea3063f4e88fa.jpeg" class="d-block w-100" height="400" alt="...">
					</div>
					<div class="carousel-item">
					<img src="https://i.ytimg.com/vi/ujxGrBsgKpg/maxresdefault.jpg" class="d-block w-100" height="400" alt="...">
					</div>
				</div>
				<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
					<span class="carousel-control-prev-icon" aria-hidden="true"></span>
					<span class="visually-hidden">Previous</span>
				</button>
				<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
					<span class="carousel-control-next-icon" aria-hidden="true"></span>
					<span class="visually-hidden">Next</span>
				</button>
			</div>

		</div>
	</div>
</div>
<!-- content -->
<div class="container-fluid my-2">
	<div class="row my-2 ">
		<div class="col-sm-3">
			<h3 class=" my-1  text-center p-2 bg-dark bg-gradient text-light">Blog</h3>
			<?php
				$limit = 10;		
				$page = isset($_GET['page'])?$_GET['page']:1;
				$offset = 	($page-1)*$limit;
			   $query = "SELECT *, blog.user_id 'blog_user_id'  FROM blog JOIN user ON user.user_id = blog.user_id WHERE blog_status= 'Active' ORDER BY blog.blog_id DESC LIMIT $offset,$limit";
			   $result = $user->execute_query($query);
			   if($result->num_rows>0)
			   { 
			   	while ($row=mysqli_fetch_assoc($result)) {
			   		extract($row); 
				?>
				
					<div class="row  m-0 my-0 my-3" style="background-color: rgb(212 212 216);">
					<div class="col-4 justify-content-center">
						<img src="<?=$blog_background_image?>"style="height: 100px; width:100%;" class="img-thumbnail rounded-pill" alt="..."/>
					</div>
					<div class="col-8 ">
						<div class="row">
								<h4 class="text-dark" style="text-decoration:none;"><?=$blog_title?></h4>
							</div>
							<div class="row">
								<div class="d-flex ">
									<?php 
									if(isset($_SESSION['user']) && $blog_user_id!=$_SESSION['user']['user_id']){
									$follow = "SELECT * FROM following_blog WHERE follower_id ='".$_SESSION['user']['user_id']."' && blog_following_id = '".$blog_id."'";
										// echo $follow;
										// die;
									$query_execute  = $user->execute_query($follow);
									if($query_execute->num_rows>0){
										$fetch = mysqli_fetch_assoc($query_execute);
										extract($fetch);
										// echo $status;
										// die;
										if(isset($status)&& $status=="Followed"){
										?>
										<button type="button" class="btn btn-success" id="unfollow" onclick="unfollow_blog(<?=$blog_id?>)">Unfollow</button>
										<?php
									}
										elseif(isset($status) && $status=="Unfollowed"){
											?>
											<button type="button" class="btn btn-primary mx-1" id="follow" onclick="follow_blog(<?=$blog_id?>)">Follow</button>
											<?php
									}
								}
								else{
									?>
									<button type="button" class="btn btn-primary mx-1" id="follow" onclick="follow_blog(<?=$blog_id?>)">Follow</button>
									<?php
									}
									
									
										// }
									}
									?>
									
								</div>
							</div>
							<div class="row">
								<p class="float-start text-dark">Author: <?=$first_name." ".$last_name?></p>
							</div>
					</div>
					<?php
					if(isset($_SESSION['user'])){
						?>
						<a class="text_dec btn btn-success bg-gradient" href="total_blog_posts.php?action=total_blog_posts&title=Total_Blog_Posts&blog_id=<?=$blog_id?>&blog_name=<?=$blog_title?> &post_per_page=<?=$post_per_page?>">More Detail</a>
						<?php
					}
					?>
				</div>
				<?php
				}
			}
			?>
			<nav aria-label="Page navigation example">
				<ul class="pagination justify-content-center">
					<?php
					$get_post_for_pagination = "SELECT * FROM blog";
					$execute_post_query = $user->execute_query($get_post_for_pagination);
					if(mysqli_num_rows($execute_post_query)>0){
						$total_records = mysqli_num_rows($execute_post_query);
						$total_page = ceil($total_records/$limit);
						echo "<ul class='pagination justify-content-center'>";
						for($i=1;$i<=$total_page; $i++){
							?>
							<li class="page-item"><a class="page-link" href="index.php?page=<?=$i?>"><?=$i?></a></li>
							<?php
						}
						echo"</ul>";
					}
					?>				
			</nav>
		</div>
		<?php
		$limit = 10;		
		$page = isset($_GET['page'])?$_GET['page']:1;
		$offset = 	($page-1)*$limit;
		$run_query = "SELECT user.first_name, user.last_name ,post.* , blog.blog_title FROM post JOIN blog ON post.blog_id = blog.blog_id JOIN user ON user.user_id=blog.user_id && post.post_status = 'Active' ORDER BY post_id DESC LIMIT $offset, $limit";
		// echo $run_query;
		// die;
		$execute_query = $user->execute_query($run_query);
		?>
		<div class="col-sm-9  ">
			<div class="row my-1  mx-0 bg-dark bg-gradient text-light">
				<div class="col-sm-9 ">
						<h3 class=" my-1  rounded">Post</h3>
				</div>
				<div class="col-sm-3 ">
					<form class="d-flex m-2" role="search">
			        <input class="form-control me-2"  id="search_post" placeholder="Search" aria-label="Search">
			        <button class="btn btn-outline-success text-light" type="button" onclick="search_here()">Search</button>
			      </form>
				</div>
			</div>
			<div class="row mt-3">
				<div class="col-sm-3"></div>
					<div class="col-sm-6">
						<p class="rounded p-1 text-center text-white" style="background-color: <?=$_REQUEST['color']??""?>;"><?=$_REQUEST['msg']??""?></p>
					</div>
					<div class="col-sm-3"></div>
			</div>
			<div id="search_response">
				<?php
				if($execute_query->num_rows>0){
					while($row=mysqli_fetch_assoc($execute_query)){
						extract($row);
						?>
						
							<div class="row m-0 my-2" style="background-color: rgb(212 212 216);">
							<div class="col-sm-3 justify-content-center">
								<img src="<?=$featured_image?>" class="mt-3" style="height: 200px; width:100%" alt="">
							</div>
							<div class="col-sm-4 mt-2">
								<div class="row">
									<div class="col-12">
										<h2><?=$post_title?></h2>
									</div>
								</div>
								<div class="row">
									<div class="col-12">
										<h6><?=$created_at?></h6>
									</div>
								</div>
								<div class="row">
									<div class="col-12">
										<h4><b>By: <?=$first_name." ".$last_name?></b></h4>
									</div>
								</div>
							</div>
							<div class="col-sm-5 mt-2">
								<p class="text-dark text_dec "><?=substr($post_summary,0,1000).'...'?></p>
							</div>
							<?php 
							if(isset($_SESSION['user']['user_id'])){
								?>
								<div class="row">
									<div class="col-12">
										<a href="total_post.php?action=total_post&title=View_Post&post_id=<?=$post_id?>" class="text_dec text-dark float-end">Read More</a>
									</div>
								</div>
								<?php
							}
							else{
								?>
								<div class="row">
									<div class="col-12">
										<a href="login.php?msg=Please Login First..!&color=red&title=Login" class="text_dec text-dark float-end">Read More</a>
									</div>
								</div>
								<?php
							}
							?>
						</div>
					<?php 
					}
				}
				?>
				<nav aria-label="Page navigation example">
				<ul class="pagination justify-content-center">
					<?php
					$get_post_for_pagination = "SELECT * FROM post";
					$execute_post_query = $user->execute_query($get_post_for_pagination);
					if(mysqli_num_rows($execute_post_query)>0){
						$total_records = mysqli_num_rows($execute_post_query);
						$total_page = ceil($total_records/$limit);
						echo "<ul class='pagination justify-content-center'>";
						for($i=1;$i<=$total_page; $i++){
							?>
							<li class="page-item"><a class="page-link" href="index.php?page=<?=$i?>"><?=$i?></a></li>
							<?php
						}
						echo"</ul>";
					}
					?>				
			</nav>
		</div>
	</div>
</div>
</div>
<!-- Footer -->
 <?php
 include_once("header_and_footer/footers.php")
 ?>