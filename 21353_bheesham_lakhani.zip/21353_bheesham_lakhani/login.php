<?php
// session_start();
include_once("header_and_footer/headers.php")
?>
<div class="container-fluid my-2">
	<div class="row mx-0" style="background-color:#C7C7C7;">
		<div class="col-sm-3"></div>
		<div class="col-sm-6">
			<p class="rounded p-1 text-center text-white" style="background-color: <?=$_REQUEST['color']??""?>;"><?=$_REQUEST['msg']??""?></p>
			<a href="download_pdf.php?user_email=<?=$_REQUEST['email']??""?>">Download PDF</a>
			<h4 class="my-3 text-center register bg-dark bg-gradient text-light">Login Account</h4>
				<form action="process.php" method="POST">
				<div class="mb-3">
				    <label for="" class="form-label">Email address</label>
				    <div class="d-flex input-group-prepend">
						<span class="input-group-text"> <i class="fa fa-envelope"></i> </span>
					    <input type="email" name="email" class="form-control" id="login_email" placeholder="Enter Your Email">
				    </div>
				</div>
				  <!-- password -->
				<div class="mb-3">
				    <label for="" class="form-label">Password</label>
				    <div class="d-flex input-group-prepend">
						<span class="input-group-text"> <i class="fa fa-lock"></i> </span>
					    <input type="password" name="password" class="form-control" id="password" placeholder="Enter Your Password">
					    <input type="checkbox" name="" id="check" onchange="showPass(this)">
				    </div>				    	
				</div>
				 <button type="reset" class="btn btn-danger">Cancel</button>
				 <button type="submit" name="login" class="btn btn-primary" value="Login">Login</button>
				 <a href="forget_password.php?title=Forgot_Password" class="btn btn-warning">Forget Password</a>
			</form>
			<p>If You Have not an account <a href="register_form.php?title=Register">Register Here</a></p>
		</div>
		<div class="col-sm-3"></div>
	</div>
</div>
<?php
include_once("header_and_footer/footers.php")
?>