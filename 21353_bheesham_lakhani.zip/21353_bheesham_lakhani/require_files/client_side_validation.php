<?php
// server_side_validation
?>

<script>
    function click_submit(){
    var flag = true;
    var first_name = document.querySelector("#first_name").value;
    var last_name = document.querySelector("#last_name").value;
    var email = document.querySelector("#email").value;
    var gender = document.querySelector("input[type='radio']:checked");
    var date_of_birth = document.querySelector("#date-input").value;
    var address = document.querySelector("#address").value;
    var password = document.querySelector("#password").value;
    var image = document.querySelector("#image").value;

    var name_pattern = new RegExp(/^[A-Z]{1}[a-z]{2,}$/);
    var email_pattern = new RegExp(/^[a-z]+[@](gmail|hotmail|yahoo)[.](com|pk|net)$/);
    var password_pattern = new RegExp(/^[A-Z]{1,}[a-z]{2,}\d{1,}\W{1,}$/);

    var first_name_message = document.querySelector("#first_name_message");
    var last_name_message = document.querySelector("#last_name_message");
    var email_message = document.querySelector("#email_message");
    var password_message = document.querySelector("#password_message");




    //border red Line 
    var _f_name = document.querySelector(".f_name");
    var _l_name = document.querySelector(".l_name");
    var _email = document.querySelector(".email");
    var _date = document.querySelector(".date");
    var _gender = document.querySelector(".gender")
    var _address = document.querySelector(".address");
    var _password = document.querySelector(".password");
    var _image = document.querySelector(".this_image");



     if(first_name==''){
                _f_name.style.border = "1px solid red";
                flag = false;
            }
            else{
                first_name_message.innerHTML = "";
                _f_name.style.border = "";
                if(!name_pattern.test(first_name)){
                    first_name_message.innerHTML = "Does not match pattern: like Abc ";
                    flag = false;
                }
            }

            if(last_name==''){
                 _l_name.style.border = "1px solid red";
                flag = false;
            }
            else{
                _l_name.style.border = "";
                if(!name_pattern.test(last_name)){
                    last_name_message.innerHTML = "Does not match pattern: like Abc";
                    flag = false;
                }
            }

            if(email==''){
                _email.style.border = "1px solid red";
                flag = false;
            }
            else{
                _email.style.border = "";
                if(!email_pattern.test(email)){
                    email_message.innerHTML = "Does not match pattern: like example@gmail.com";
                    flag = false;
                }
            }
             if(gender ==null){
                _gender.style.border = "1px solid red";
                flag = false;
            }
            else{
                _gender.style.border = "";
            }

            if(date_of_birth == ""){
                _date.style.border = "1px solid red";
                flag = false;
            }
            else{
                _date.style.border = "";
            }

            if(address === ""){
            	_address.style.border = "1px solid red";
            	flag=false;
            }
            else{
            	_address.style.border = "";
            }
            if(image == ""){
            	_image.style.border = "1px solid red";
            	flag=false;
            }
            else{
                _image.style.border = "";

            }
            if(password == ""){
            	_password.style.border = "1px solid red";
            	flag=false;
            }
            else{
                _password.style.border = "";
                if(!password_pattern.test(password)){
                    flag=false;
                    password_message.innerHTML = "Password must be like that Example123@#";
                }
            	else{
                    password_message.innerHTML="";
                }
            }
    if(flag===true){
        return true;    
    }
    else{
        return false;
    }
    
 }
</script>