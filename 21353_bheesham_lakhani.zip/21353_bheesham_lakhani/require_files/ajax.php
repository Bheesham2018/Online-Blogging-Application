    <style type="text/css">
        .content{
            min-height: 700px;
        }
        .footer { 
            margin-top: auto;
        }
        .links a[href$=".png"]::before{
            content: '';
            display: inline-block; 
            width: 20px; 
            height: 20px; 
            background-image: url('icon_of_attachment/png.png');
            background-size: cover; 
            margin-left: 5px; 
            vertical-align: middle; 
        }
        .links a[href$=".jpeg"]::before {
            content: '';
            display: inline-block; 
            width: 20px; 
            height: 20px; 
            background-image: url('icon_of_attachment/jpg.png');
            background-size: cover; 
            margin-left: 5px; 
            vertical-align: middle; 
        }
        .links a[href$=".jpg"]::before {
            content: '';
            display: inline-block; 
            width: 20px; 
            height: 20px; 
            background-image: url('icon_of_attachment/jpg.png');
            background-size: cover; 
            margin-left: 5px; 
            vertical-align: middle; 
        }
        .links a[href$=".svg"]::before {
            content: '';
            display: inline-block; 
            width: 20px; 
            height: 20px; 
            background-image: url('icon_of_attachment/svg.png');
            background-size: cover; 
            margin-left: 5px; 
            vertical-align: middle; 
        }
        .links a[href$=".gif"]::before {
            content: '';
            display: inline-block; 
            width: 20px; 
            height: 20px; 
            background-image: url('icon_of_attachment/gif.png');
            background-size: cover; 
            margin-left: 5px; 
            vertical-align: middle; 
        }
        .links>a[href$=".webp"]::before{
            content: '';
            display: inline-block; 
            width: 20px; 
            height: 20px; 
            background-image: url('icon_of_attachment/webp.png');
            background-size: cover; 
            margin-left: 5px; 
            vertical-align: middle; 
        }
        .links>a[href$=".docs"]::before{
            content: '';
            display: inline-block; 
            width: 20px; 
            height: 20px; 
            background-image: url('icon_of_attachment/doc.png');
            background-size: cover; 
            margin-left: 5px; 
            vertical-align: middle; 
        }
        .links>a[href$=".pdf"]::before{
            content: '';
            display: inline-block; 
            width: 20px; 
            height: 20px; 
            background-image: url('icon_of_attachment/pdf.png');
            background-size: cover; 
            margin-left: 5px; 
            vertical-align: middle; 
        }
        .links>a[href$=".pptx"]::before{
            content: '';
            display: inline-block; 
            width: 20px; 
            height: 20px; 
            background-image: url('icon_of_attachment/ppt.png');
            background-size: cover; 
            margin-left: 5px; 
            vertical-align: middle; 
        }
        .home_hover:hover{
            background-color:white;
            border-radius:5px;
        }
        .text_dec{
            text-decoration: none;
            color: black;

        }
    .bg-image {
        background-image: url("https://i.pinimg.com/originals/7b/ee/68/7bee68a5c7e1577fb1f9f4b4a1f9461d.gif");
        background-repeat: no-repeat;
        background-position: center;
        background-size: cover;

    }
    .text-light:hover {
        background-color: darkslategrey;
        border-radius: 10px;
    }

    #blog {
        text-decoration: none;
    }
    .card {
        width: 250px;

    }

    .card-img-top {
/*        width: 0%;*/
        height: 60px;

    }
    .login {
        border-radius: 10px;
        box-shadow: 10px 10px 10px gray;
        padding: 10px;
    }

    .register {
        border-radius: 10px;
        box-shadow: 10px 10px 10px gray;
        padding: 10px;
    }

    #blog {
        text-decoration: none;
    }

    #blog:hover {
        background-color: lightgray;
        border-radius: 5px;
    }
    .box-shadow {
        box-shadow: 6px 10px 3px gray;
    }
    .message_color{
        color: red;
        text-align: center;
    }
    .image_size{
        width: 50px;
        height: 50px;
        border-radius: 50%;
    }
    .image{
        width: 75%;
        height: 100px;
    }
    </style>


<script>
    function show_all_comments($comments_post_id){
        // alert("ok");
        // console.log($comments_post_id);
        var comment_is  = new XMLHttpRequest();
        comment_is.onreadystatechange=function(){
            if (comment_is.readyState == 4 && comment_is.status == 200) {
                console.log($comments_post_id)
                document.querySelector("#all_comments").innerHTML = comment_is.responseText;
                document.querySelector("#comments_hide").innerHTML="";
                // console.log(comment_is.responseText);
                document.querySelector(".show").style.display="none";
                document.querySelector(".hide").style.display="block";     

            }
        }
        comment_is.open("GET","ajax_response.php?action=comment_is&all_comment="+$comments_post_id);
        comment_is.send();
    }
    function hide_all_comments($comments_post_id) {
         var hide_comment  = new XMLHttpRequest();
        hide_comment.onreadystatechange=function(){
            if (hide_comment.readyState == 4 && hide_comment.status == 200) {
                console.log($comments_post_id)
                document.querySelector("#all_comments").innerHTML = "";
                document.querySelector("#comments_hide").innerHTML=hide_comment.responseText;
                // console.log(hide_comment.responseText);
                document.querySelector(".hide").style.display="none";     
                document.querySelector(".show").style.display="block";     

            }
        }
        hide_comment.open("GET","ajax_response.php?action=hide_comment&all_comment="+$comments_post_id);
        hide_comment.send();
    }
    function search_here(){
        var search = document.querySelector("#search_post").value;
        var search_here = new XMLHttpRequest();  
        // alert('ok');
        search_here.onreadystatechange=function(){
            if (search_here.readyState == 4 && search_here.status == 200) {
                document.querySelector("#search_response").innerHTML = search_here.responseText;
                console.log(search_here.responseText);
                document.querySelector("#search_post").value="";     
            }
        }
        search_here.open("GET","ajax_response.php?action=search_here&search_is="+search);
        search_here.send();

    }
    // ......................................................
    function follow_blog($blog_id_is){
        // console.log($blog_id_is);
        var follow_blog = new XMLHttpRequest();
            follow_blog.onreadystatechange = function() {
                if (follow_blog.readyState == 4 && follow_blog.status == 200) {
                    // console.log(follow_blog.responseText);
                    // document.querySelector("#unfollow").style.display="none";
                    // document.querySelector("#get_follower_message").innerHTML = follow_blog.responseText;
                    window.location.href='index.php?title=Home';
                    
                }
            }
            follow_blog.open("GET","ajax_response.php?action=follow_blog&blog_id="+$blog_id_is);
            follow_blog.send();

    }
    function unfollow_blog($blog_id_is){
        // console.log($blog_id_is);
        var unfollow_blog = new XMLHttpRequest();
            unfollow_blog.onreadystatechange = function() {
                if (unfollow_blog.readyState == 4 && unfollow_blog.status == 200) {
                    // console.log(unfollow_blog.responseText);
                    // document.querySelector("#get_follower_message").innerHTML = unfollow_blog.responseText;
                    window.location.href='index.php?title=Home';
                }
            }
            unfollow_blog.open("GET","ajax_response.php?action=unfollow_blog&blog_id="+$blog_id_is);
            unfollow_blog.send();

    }
    // ......................................................
    function  send_comment($post_id){
        var comment_is = document.querySelector("#send_comment").value;
        // console.log (comment_is);
        // alert("ok")
        var send_comment = new XMLHttpRequest();
        send_comment.onreadystatechange=function(){
                // alert("ok");
            if(send_comment.readyState==4 && send_comment.status==200){
                // alert("ok")
                // console.log($post_id);
                console.log(send_comment.responseText);
                window.location.href = 'total_post.php?action=total_post&title=View_Post&post_id='+$post_id;
                document.querySelector("#send_comment").value= "";
            }
        }
        send_comment.open("GET", "ajax_response.php?action=send_comment&post_id="+$post_id+"&comment_is="+comment_is);
        send_comment.send();
    }
    function numberAttachment(){
        // alert("ok");
        var attachment = document.querySelector("#number_of_attachment").value;
        var how_many_attachment = document.querySelector("#attachment_number");
        var numberAttachment = new XMLHttpRequest();
            numberAttachment.onreadystatechange = function() {
                if (numberAttachment.readyState == 4 && numberAttachment.status == 200) {
                    // console.log(numberAttachment.responseText);
                    // console.log(attachment);
                    how_many_attachment.innerHTML = numberAttachment.responseText;
                    document.querySelector("#number_of_attachment").value="";
                }
            }
            numberAttachment.open("GET", "ajax_response.php?action=numberAttachment&attachment="+attachment);
            numberAttachment.send();
    }
    // ........................................blog status update...............................
    function active_status_blog($blog_id_) {
        var status = new XMLHttpRequest();
            status.onreadystatechange = function() {
                if (status.readyState == 4 && status.status == 200) {
                    console.log(status.responseText);
                    update_blog_status();
                }
            }
            status.open("GET", "ajax_response.php?action=active_blog_status&blog_id="+$blog_id_);
            status.send();
        
    }
    function inactive_status_blog($blog_id_) {
        var create = new XMLHttpRequest();
            create.onreadystatechange = function() {
                if (create.readyState == 4 && create.status == 200) {
                    // console.log(create.responseText);
                    update_blog_status();
                }
            }
            create.open("GET", "ajax_response.php?action=inactive_blog_status&blog_id="+$blog_id_);
            create.send();
        
    }
    // ..........................................blog status update..............................
    // ............................................comments.....................
    // active_comment_status
    function active_comment_status($comment_id) {
        var create = new XMLHttpRequest();
            create.onreadystatechange = function() {
                if (create.readyState == 4 && create.status == 200) {
                    console.log(create.responseText);
                    comments_are();
                }
            }
            create.open("GET", "ajax_response.php?action=active_comment_status&comment_id="+$comment_id);
            create.send();
        
    }
    // inactive_comment_status
    function inactive_comment_status($comment_id) {
        var create = new XMLHttpRequest();
            create.onreadystatechange = function() {
                if (create.readyState == 4 && create.status == 200) {
                    console.log(create.responseText);
                    comments_are();
                }
            }
            create.open("GET", "ajax_response.php?action=inactive_comment_status&comment_id="+$comment_id);
            create.send();
        
    }
    // ..............................comments.............................
    // ..........................................category........................................
    function active_category_status($category_id_) {
        var status = new XMLHttpRequest();
            status.onreadystatechange = function() {
                if (status.readyState == 4 && status.status == 200) {
                    // console.log(status.responseText);
                    update_category_status()
                }
            }
            status.open("GET", "ajax_response.php?action=active_category_status&category_id="+$category_id_);
            status.send();
        
    }
    function inactive_category_status($category_id_) {
        var status = new XMLHttpRequest();
            status.onreadystatechange = function() {
                if (status.readyState == 4 && status.status == 200) {
                    console.log(status.responseText);
                    update_category_status()
                }
            }
            status.open("GET", "ajax_response.php?action=inactive_category_status&category_id="+$category_id_);
            status.send();
        
    }
    // ..........................................category........................................

    //..........................................user_status_change...............................
    function status_of_user_change_to_active($user_id_) {
        var status = new XMLHttpRequest();
            status.onreadystatechange = function() {
                if (status.readyState == 4 && status.status == 200) {
                    // console.log($user_id_);
                    user_status();
                }
            }
            status.open("GET", "ajax_response.php?action=status_of_user_change_to_active&user_id="+$user_id_);
            status.send();
    }

    function status_of_user_change_to_inactive($user_id_) {
        var status = new XMLHttpRequest();
            status.onreadystatechange = function() {
                if (status.readyState == 4 && status.status == 200) {
                    // console.log(status.responseText);
                    user_status();
                }
            }
            status.open("GET", "ajax_response.php?action=status_of_user_change_to_inactive&user_id="+$user_id_);
            status.send();
    }
    //..........................................user_status_change...............................
    // rejected_user_request
    function approve_user_request_($user_id_,$user_email, $user_name) {
    // var loader= document.querySelector("#loader").value; 
        var status = new XMLHttpRequest();
            status.onreadystatechange = function() {
                if (status.readyState == 4 && status.status == 200) {
                    // console.log(status.responseText);
                    user_request();
                }
            }
            status.open("GET", "ajax_response.php?action=approve_user_request_&user_id="+$user_id_);
            status.send();
    }

    function rejected_user_request_($user_id_) {
        var status = new XMLHttpRequest();
            status.onreadystatechange = function() {
                if (status.readyState == 4 && status.status == 200) {
                    // console.log($user_id_);
                    user_request();
                }
            }
            status.open("GET", "ajax_response.php?action=rejected_user_request_&user_id="+$user_id_);
            status.send();
    }
    // .......................post_status_change...............
    function update_post_status_active($post_id_) {
        var status = new XMLHttpRequest();
            status.onreadystatechange = function() {
                if (status.readyState == 4 && status.status == 200) {
                    // console.log($post_id_);
                    console.log(status.responseText);
                    update_post_status();
                }
            }
            status.open("GET", "ajax_response.php?action=update_post_status_active&post_id="+$post_id_);
            status.send();
    }
    function update_post_status_inactive($post_id_) {
        // alert("ok");
        var status = new XMLHttpRequest();
            status.onreadystatechange = function() {
                if (status.readyState == 4 && status.status == 200) {
                    // console.log($post_id_);
                    console.log(status.responseText);
                    update_post_status();
                }
            }
            status.open("GET", "ajax_response.php?action=update_post_status_inactive&post_id="+$post_id_);
            status.send();
    }
    // .......................post_status_change...............

    // ..........................Comment_status_change..........................
    // comment_status_change_active
    function comment_status_change_active($post_id_) {
        // alert("ok");
        var status = new XMLHttpRequest();
            status.onreadystatechange = function() {
                if (status.readyState == 4 && status.status == 200) {
                    // console.log($post_id_);
                    console.log(status.responseText);
                    comment_update();
                }
            }
            status.open("GET", "ajax_response.php?action=comment_status_change_active&post_id="+$post_id_);
            status.send();
    }
    // comment_update
    // comment_status_change_inactive
    function comment_status_change_inactive($post_id_) {
        // alert("ok");
        var status = new XMLHttpRequest();
            status.onreadystatechange = function() {
                if (status.readyState == 4 && status.status == 200) {
                    // console.log($post_id_);
                    console.log(status.responseText);
                    comment_update();
                }
            }
            status.open("GET", "ajax_response.php?action=comment_status_change_inactive&post_id="+$post_id_);
            status.send();
    }
    // ..........................Comment_status_change..........................

        //posts,blog,users and more
        function create() {
            var create = new XMLHttpRequest();
            create.onreadystatechange = function() {
                if (create.readyState == 4 && create.status == 200) {
                    // console.log(create.responseText);
                    document.querySelector("#response_text").innerHTML = create.responseText;
                }
            }
            create.open("GET", "ajax_response.php?action=create");
            create.send();
        }
    	function update(){
    		var update = new XMLHttpRequest();
    		update.onreadystatechange = function() {
                if (update.readyState == 4 && update.status == 200) {
                    // console.log(update.responseText);
                    document.querySelector("#response_text").innerHTML = update.responseText;
                    new DataTable("#update_blog");
                }
            }
            update.open("GET", "ajax_response.php?action=update");
            update.send();
    	}
        function update_blog_status(){
            var update_blog_status = new XMLHttpRequest();
            update_blog_status.onreadystatechange = function() {
                if (update_blog_status.readyState == 4 && update_blog_status.status == 200) {
                    // console.log(update_blog_status.responseText);
                    document.querySelector("#response_text").innerHTML = update_blog_status.responseText;
                    new DataTable("#update_blog_status")
                }
            }
            update_blog_status.open("GET", "ajax_response.php?action=update_blog_status");
            update_blog_status.send(); 
        }
        function active_blog(){
            var active_blog = new XMLHttpRequest();
            active_blog.onreadystatechange = function() {
                if (active_blog.readyState == 4 && active_blog.status == 200) {
                    // console.log(active_blog.responseText);
                    document.querySelector("#response_text").innerHTML = active_blog.responseText;
                    new DataTable("#active_blog");
    			}
    		}
            active_blog.open("GET", "ajax_response.php?action=active_blog");
            active_blog.send();
        }
        function inactive_blog(){
            var inactive_blog = new XMLHttpRequest();
            inactive_blog.onreadystatechange = function() {
                if (inactive_blog.readyState == 4 && inactive_blog.status == 200) {
                    // console.log(inactive_blog.responseText);
                    document.querySelector("#response_text").innerHTML = inactive_blog.responseText;
                    new DataTable("#inactive_blog");
    			}
    		}
            inactive_blog.open("GET", "ajax_response.php?action=inactive_blog");
            inactive_blog.send();
        }
        function all_category(){
            var all_category = new XMLHttpRequest();
            all_category.onreadystatechange = function() {
                if (all_category.readyState == 4 && all_category.status == 200) {
                    // console.log(all_category.responseText);
                    document.querySelector("#response_text").innerHTML = all_category.responseText;
                    new DataTable("#all_category");
                    }
                }
                all_category.open("GET", "ajax_response.php?action=all_category");
                all_category.send(); 
        }
        function add_category(){
            var add_category = new XMLHttpRequest();
            // alert("hi");
            add_category.onreadystatechange = function() {
                if (add_category.readyState == 4 && add_category.status == 200) {
                    // console.log(add_category.responseText);
                    document.querySelector("#response_text").innerHTML = add_category.responseText;
                    new DataTable("#add_category");
                    }
                }
                add_category.open("GET", "ajax_response.php?action=add_category");
                add_category.send();
        }
        function update_category(){
            var update_category = new XMLHttpRequest();
            // alert("hi");
            update_category.onreadystatechange = function() {
                if (update_category.readyState == 4 && update_category.status == 200) {
                    // console.log(update_category.responseText);
                    document.querySelector("#response_text").innerHTML = update_category.responseText;
                    new DataTable("#update_category");
                    }
                }
                update_category.open("GET", "ajax_response.php?action=update_category");
                update_category.send();
        }
        // update_category_status
        function update_category_status(){
             var update_category_status = new XMLHttpRequest();
            // alert("hi");
            update_category_status.onreadystatechange = function() {
                if (update_category_status.readyState == 4 && update_category_status.status == 200) {
                    // console.log(update_category_status.responseText);
                    document.querySelector("#response_text").innerHTML = update_category_status.responseText;
                    new DataTable("#update_category_status");
                    }
                }
                update_category_status.open("GET", "ajax_response.php?action=update_category_status");
                update_category_status.send();
        }
        function active_category(){
            var active_category = new XMLHttpRequest();
            // alert("hi");
            active_category.onreadystatechange = function() {
                if (active_category.readyState == 4 && active_category.status == 200) {
                    // console.log(active_category.responseText);
                    document.querySelector("#response_text").innerHTML = active_category.responseText;
                    new DataTable("#active_category");
                    }
                }
                active_category.open("GET", "ajax_response.php?action=active_category");
                active_category.send(); 
        }
        function inactive_category(){
            var inactive_category = new XMLHttpRequest();
            // alert("hi");
            inactive_category.onreadystatechange = function() {
                if (inactive_category.readyState == 4 && inactive_category.status == 200) {
                    // console.log(inactive_category.responseText);
                    document.querySelector("#response_text").innerHTML = inactive_category.responseText;
                    new DataTable("#inactive_category");
                    }
                }
                inactive_category.open("GET", "ajax_response.php?action=inactive_category");
                inactive_category.send(); 
        }
        function add_user(){
            var add_user = new XMLHttpRequest();
            // alert("hi");
            add_user.onreadystatechange = function() {
                if (add_user.readyState == 4 && add_user.status == 200) {
                    // console.log(add_user.responseText);
                    document.querySelector("#response_text").innerHTML = add_user.responseText;
                    }
                }
                add_user.open("GET", "ajax_response.php?action=add_user");
                add_user.send(); 
        }
        function user_request(){
            var user_request = new XMLHttpRequest();
            // alert("hi");
            user_request.onreadystatechange = function() {
                if (user_request.readyState == 4 && user_request.status == 200) {
                    // console.log(user_request.responseText);
                    document.querySelector("#response_text").innerHTML = user_request.responseText;
                    new DataTable("#user_request");
                    }
                }
                user_request.open("GET", "ajax_response.php?action=user_request");
                user_request.send(); 
        }
         function user_status(){
                var user_status = new XMLHttpRequest();
                user_status.onreadystatechange = function() {
                    if (user_status.readyState == 4 && user_status.status == 200) {
                        // console.log(user_status.responseText);
                        document.querySelector("#response_text").innerHTML = user_status.responseText;
                        new DataTable("#user_status")
                    }
                }
                user_status.open("GET", "ajax_response.php?action=user_status");
                user_status.send(); 
            }
            function edit_user_detail(){
                var edit_user_detail = new XMLHttpRequest();
                edit_user_detail.onreadystatechange = function() {
                    if (edit_user_detail.readyState == 4 && edit_user_detail.status == 200) {
                        // console.log(edit_user_detail.responseText);
                        document.querySelector("#response_text").innerHTML = edit_user_detail.responseText;
                        new DataTable("#edit_user_detail")
                    }
                }
                edit_user_detail.open("GET", "ajax_response.php?action=edit_user_detail");
                edit_user_detail.send(); 
            }
        function new_user(){
            var new_user = new XMLHttpRequest();
            // alert("hi");
            new_user.onreadystatechange = function() {
                if (new_user.readyState == 4 && new_user.status == 200) {
                    // console.log(new_user.responseText);
                    document.querySelector("#response_text").innerHTML = new_user.responseText;
                    new DataTable("#new_user");
                    }
                }
                new_user.open("GET", "ajax_response.php?action=new_user");
                new_user.send(); 
        }
        function approved_user(){
            var approved_user = new XMLHttpRequest();
            // alert("hi");
            approved_user.onreadystatechange = function() {
                if (approved_user.readyState == 4 && approved_user.status == 200) {
                    // console.log(approved_user.responseText);
                    document.querySelector("#response_text").innerHTML = approved_user.responseText;
                    new DataTable("#approved_user");
                    }
                }
                approved_user.open("GET", "ajax_response.php?action=approved_user");
                approved_user.send(); 
        }
        // pending_user
        function pending_user(){
            var pending_user = new XMLHttpRequest();
            // alert("hi");
            pending_user.onreadystatechange = function() {
                if (pending_user.readyState == 4 && pending_user.status == 200) {
                    // console.log(pending_user.responseText);
                    document.querySelector("#response_text").innerHTML = pending_user.responseText;
                    new DataTable("#pending_user");
                    }
                }
                pending_user.open("GET", "ajax_response.php?action=pending_user");
                pending_user.send(); 
        }
        // rejected_user
        function rejected_user(){
            var rejected_user = new XMLHttpRequest();
            // alert("hi");
            rejected_user.onreadystatechange = function() {
                if (rejected_user.readyState == 4 && rejected_user.status == 200) {
                    // console.log(rejected_user.responseText);
                    document.querySelector("#response_text").innerHTML = rejected_user.responseText;
                    new DataTable("#rejected_user");
                    }
                }
                rejected_user.open("GET", "ajax_response.php?action=rejected_user");
                rejected_user.send(); 
        }
        // active_user
        function active_user(){
            var active_user = new XMLHttpRequest();
            // alert("hi");
            active_user.onreadystatechange = function() {
                if (active_user.readyState == 4 && active_user.status == 200) {
                    // console.log(active_user.responseText);
                    document.querySelector("#response_text").innerHTML = active_user.responseText;
                    new DataTable("#active_user");
                    }
                }
                active_user.open("GET", "ajax_response.php?action=active_user");
                active_user.send(); 
        }
        // inactive_user
        function inactive_user(){
            var inactive_user = new XMLHttpRequest();
            // alert("hi");
            inactive_user.onreadystatechange = function() {
                if (inactive_user.readyState == 4 && inactive_user.status == 200) {
                    // console.log(inactive_user.responseText);
                    document.querySelector("#response_text").innerHTML = inactive_user.responseText;
                    new DataTable("#inactive_user");
                    }
                }
                inactive_user.open("GET", "ajax_response.php?action=inactive_user");
                inactive_user.send(); 
        }
           // create post
        function create_post() {
            var create_post = new XMLHttpRequest();
            create_post.onreadystatechange = function() {
                if (create_post.readyState == 4 && create_post.status == 200) {
                    // console.log(create_post.responseText);
                    document.querySelector("#response_text").innerHTML = create_post.responseText;
                    document.querySelectorAll('[data-multi-select]').forEach(select => new MultiSelect(select));
                }
            }
            create_post.open("GET", "ajax_response.php?action=create_post");
            create_post.send();
        }
        // update post
        function update_post() {
            var update_post = new XMLHttpRequest();
            update_post.onreadystatechange = function() {
                if (update_post.readyState == 4 && update_post.status == 200) {
                    // console.log(update_post.responseText);
                    document.querySelector("#response_text").innerHTML = update_post.responseText;
                    new DataTable("#update_post")
                }
            }
            update_post.open("GET", "ajax_response.php?action=update_post");
            update_post.send();
        }
        // update_post_status
         function update_post_status() {
            var update_post_status = new XMLHttpRequest();
            update_post_status.onreadystatechange = function() {
                if (update_post_status.readyState == 4 && update_post_status.status == 200) {
                    // console.log(update_post_status.responseText);
                    document.querySelector("#response_text").innerHTML = update_post_status.responseText;
                    new DataTable("#update_post_status")
                }
            }
            update_post_status.open("GET", "ajax_response.php?action=update_post_status");
            update_post_status.send();
        }
        // comment_update
        function comment_update() {
            var comment_update = new XMLHttpRequest();
            comment_update.onreadystatechange = function() {
                if (comment_update.readyState == 4 && comment_update.status == 200) {
                    // console.log(comment_update.responseText);
                    document.querySelector("#response_text").innerHTML = comment_update.responseText;
                    new DataTable("#comment_update")
                }
            }
            comment_update.open("GET", "ajax_response.php?action=comment_update");
            comment_update.send();
        }
        // active_post
        function active_post(){
            var active_post = new XMLHttpRequest();
            // alert("hi");
            active_post.onreadystatechange = function() {
                if (active_post.readyState == 4 && active_post.status == 200) {
                    // console.log(active_post.responseText);
                    document.querySelector("#response_text").innerHTML = active_post.responseText;
                    new DataTable("#active_post");
                    }
                }
                active_post.open("GET", "ajax_response.php?action=active_post");
                active_post.send(); 
        } 

        // inactive_post
        function inactive_post(){
            var inactive_post = new XMLHttpRequest();
            // alert("hi");
            inactive_post.onreadystatechange = function() {
                if (inactive_post.readyState == 4 && inactive_post.status == 200) {
                    // console.log(inactive_post.responseText);
                    document.querySelector("#response_text").innerHTML = inactive_post.responseText;
                    new DataTable("#inactive_post");
                    }
                }
                inactive_post.open("GET", "ajax_response.php?action=inactive_post");
                inactive_post.send(); 
        }
        // feedback
        function feedback(){
            var feedback = new XMLHttpRequest();
            // alert("hi");
            feedback.onreadystatechange = function() {
                if (feedback.readyState == 4 && feedback.status == 200) {
                    // console.log(feedback.responseText);
                    document.querySelector("#response_text").innerHTML = feedback.responseText;
                    new DataTable("#feedback");
                    }
                }
                feedback.open("GET", "ajax_response.php?action=feedback");
                feedback.send(); 
        }
        // followers_are
        function followers_are(){
            var followers_are = new XMLHttpRequest();
            // alert("hi");
            followers_are.onreadystatechange = function() {
                if (followers_are.readyState == 4 && followers_are.status == 200) {
                    // console.log(followers_are.responseText);
                    document.querySelector("#response_text").innerHTML = followers_are.responseText;
                    new DataTable("#followers_are");
                    }
                }
                followers_are.open("GET", "ajax_response.php?action=followers_are");
                followers_are.send(); 
        }
        // negative_comment
        function comments_are(){
            var comments_are = new XMLHttpRequest();
            // alert("hi");
            comments_are.onreadystatechange = function() {
                if (comments_are.readyState == 4 && comments_are.status == 200) {
                    // console.log(comments_are.responseText);
                    document.querySelector("#response_text").innerHTML = comments_are.responseText;
                    new DataTable("#comments_are");
                    }
                }
                comments_are.open("GET", "ajax_response.php?action=comments_are");
                comments_are.send(); 
        }
       
        // update_blog_status

</script>