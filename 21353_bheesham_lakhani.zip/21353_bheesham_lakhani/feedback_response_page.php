<?php
require_once("header_and_footer/headers.php")
?>
<style type="text/css">
	.pos{
		position: fixed;
		bottom: 0;
	}
</style>
<div class="container-fluid">
	<div class="row">
		<div class="col-2"></div>
		<div class="col-8">
			<div class="row">
				<div class="col-12">
					<div class="text-center">
					  <img src="https://www.clickworker.com/wp-content/uploads/2021/04/Feedback-einholen.png" class="rounded img-fluid" alt="...">
					</div>
				</div>
			</div>
			<div class="text-center">
				<h1>Thank You for Submitting </h1>
				<a href="index.php?title=Home" class="btn btn-primary">Back To Home</a>
			</div>

		</div>
		<div class="col-2"></div>
	</div>
</div>

<?php
require_once("header_and_footer/footers.php")
?>