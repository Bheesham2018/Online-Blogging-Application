/*
SQLyog Ultimate v12.5.0 (64 bit)
MySQL - 10.4.27-MariaDB : Database - 21353_bheesham_lakhani
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`21353_bheesham_lakhani` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `21353_bheesham_lakhani`;

/*Table structure for table `blog` */

DROP TABLE IF EXISTS `blog`;

CREATE TABLE `blog` (
  `blog_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `blog_title` varchar(200) DEFAULT NULL,
  `post_per_page` int(11) DEFAULT NULL,
  `blog_background_image` text DEFAULT NULL,
  `blog_status` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`blog_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `blog_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `blog` */

insert  into `blog`(`blog_id`,`user_id`,`blog_title`,`post_per_page`,`blog_background_image`,`blog_status`,`created_at`,`updated_at`) values 
(1,1,'NEWS',6,'blog_images/1727241593_news.jpg','Active','2024-09-25 10:19:53',NULL),
(2,1,'Affiliate',6,'blog_images/1727242408_Affiliated.png','Active','2024-09-25 10:58:35','2024-09-25 10:58:35');

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_title` varchar(100) DEFAULT NULL,
  `category_description` text DEFAULT NULL,
  `category_status` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `category` */

insert  into `category`(`category_id`,`category_title`,`category_description`,`category_status`,`created_at`,`updated_at`) values 
(1,'Journalism','Journalism is the practice of gathering, compiling, and distributing unbiased fact-based news and other relevant information to the general audience. A journalist is in charge of gathering news from numerous sources (such as media, tipsters, inside sources, and eyewitnesses) and delivering it to the public via a media channel, such as print, web, television, or radio. There are a number of universities that offer journalism courses and diplomas in journalism which can be pursued by individuals to kick-start their careers.','Active','2024-09-25 10:29:42',NULL),
(2,'Hard News','Hard News involves time-sensitive news, which is severe and is reported as breaking news immediately. Some of its examples are Political Journalism, Investigative Journalism, Business Journalism, Crime Journalism, Global news, Sports Journalism, etc. These news stories involve serious facts, and in-depth research and follow an inverted pyramid structure – 5 W’s and 1H – Who, What, Why, When, Where, and How for writing news','Active','2024-09-25 10:30:02',NULL),
(3,'Soft News','Soft News involves entertainment and lifestyle-centric news stories. They primarily carry information for the amusement or personal usage of the public. Some examples are entertainment and lifestyle Journalism on movies, fashion, food, beauty, and skincare, etc','Active','2024-09-25 10:30:51',NULL),
(4,'Offline Promotions','Though the internet provides a plethora of sponsoring opportunities, you shouldn’t ignore other conventional methods. Having your business promoted by your local radio, newspaper, flyers, and much more can still yield some favorable results. You can advertise your website as well as any of your physical locations.  Not your standard affiliate partners but keep reading.','Active','2024-09-25 10:35:19',NULL),
(5,'Pay Per Call','This method is similar to pay-per-click, except it applies to phone numbers instead of links. Make sure the phone number you promote is trackable. It’ll help you determine the origins of your leads and conversions.','Active','2024-09-25 10:36:03',NULL),
(6,'Email Marketing','Though texting and social networking are dominating electronic communication, emailing is still pretty popular. You can send newsletters, offers, and plenty of other content to potential and current consumers. The emails will directly contain your affiliate links. Though having those links embedded in blogs can attract potential consumers, it’s different when you’re sending that content straight to individuals. If they’re receiving your emails, it’s most likely because they deliberately signed up to obtain them. This type of affiliate marketing engages with an audience that’s already interested in a particular niche having to do with your products and services.','Active','2024-09-25 10:36:25',NULL);

/*Table structure for table `following_blog` */

DROP TABLE IF EXISTS `following_blog`;

CREATE TABLE `following_blog` (
  `follow_id` int(11) NOT NULL AUTO_INCREMENT,
  `follower_id` int(11) DEFAULT NULL,
  `blog_following_id` int(11) DEFAULT NULL,
  `status` enum('Followed','Unfollowed') DEFAULT 'Followed',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`follow_id`),
  KEY `blog_following_id` (`blog_following_id`),
  KEY `follower_id` (`follower_id`),
  CONSTRAINT `following_blog_ibfk_1` FOREIGN KEY (`blog_following_id`) REFERENCES `blog` (`blog_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `following_blog_ibfk_2` FOREIGN KEY (`follower_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `following_blog` */

/*Table structure for table `post` */

DROP TABLE IF EXISTS `post`;

CREATE TABLE `post` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_id` int(11) DEFAULT NULL,
  `post_title` varchar(200) NOT NULL,
  `post_summary` text NOT NULL,
  `post_description` longtext NOT NULL,
  `featured_image` text DEFAULT NULL,
  `post_status` enum('Active','InActive') DEFAULT NULL,
  `is_comment_allowed` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`post_id`),
  KEY `blog_id` (`blog_id`),
  CONSTRAINT `post_ibfk_1` FOREIGN KEY (`blog_id`) REFERENCES `blog` (`blog_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post` */

insert  into `post`(`post_id`,`blog_id`,`post_title`,`post_summary`,`post_description`,`featured_image`,`post_status`,`is_comment_allowed`,`created_at`,`updated_at`) values 
(1,1,'Can the 2024 Budget stabilise Pakistan&#039;s economy?','While immediate measures to control inflation are necessary, the budget should focus on long-term sustainable growth.','The upcoming 2024 budget is more than a routine fiscal exercise for Pakistan; it is a litmus test of the government&#039;s ability to steer the country out of a dire economic crisis. With inflation spiralling out of control, decimating household incomes, and economic growth stagnating, the upcoming fiscal plan is not merely a set of numbers but a critical blueprint for survival. This budget is the government&#039;s last-ditch effort to pull the economy back from the brink, offering a lifeline to millions grappling with the soaring cost of living and the pervasive sense of economic despair. It is a moment of reckoning, demanding bold, innovative, and decisive action to stabilise the economy, restore public confidence, and pave the way for sustainable growth.','post_featured_image/1727243077_budget.jpg','Active',1,'2024-09-25 10:44:37',NULL),
(2,1,'A tragicomedy of academic oppression in Pakistan','For those of us on Tenure Track System, it&#039;s seems like a drought: no salary increase but higher taxes in every budget','You might be thinking being a professor in Pakistan is supposed to be a glamorous gig, right? Tweed jackets with elbow patches, philosophical musings over steaming cups of chai, and the chance to shape young minds like a sculptor molding clay. Sounds like a dream job, doesn&#039;t it? Well, let me burst that iconic bubble for you, folks. For those of us on the Tenure Track System (TTS) in this country, it&#039;s more like waiting for rain in a drought: no salary increase but higher taxes in every budget.','post_featured_image/1727243219_HEC.jpg','Active',1,'2024-09-25 10:46:59',NULL),
(3,1,'Reading Mohammad Khalid Akhtar’s futuristic satire on International Translation Day','Kanhaiya Lal Kapoor deemed it the first social and political satire in Urdu','Bees Sau Gyaara (2011) was the first book of renowned author Mohammad Khalid Akhtar, who is celebrating his birth centenary this year. This novel was first published in 1950, 70 years ago this month under the arrangement of Maktaba-e-Jadeed in Lahore. The distinguished Urdu satirist Kanhaiya Lal Kapoor deemed it the first social and political satire in Urdu and had expressed the wish to be the novel’s writer.','post_featured_image/1727243423_nnnnnnn.jpg','Active',1,'2024-09-25 10:50:23',NULL),
(5,2,'The biggest topic on everyone’s minds this year at INBOUND was the same as last year: AI. But the nature of the conversation has changed.','   In 2023, headlines indicated that AI would change everything, for better or for worse. It was going to bring an economic revolution, usher in a gold rush, and destroy humanity, all at once.\r\nThe growth formula is simple: More traffic * Higher Conversion * Better Retention = Higher growth. But unfortunately, it is broken.','One year later, the headlines say the opposite story: the AI revolution is losing steam and the AI hype bubble is deflating. So what’s the truth? Is the recent wave of AI disruption false hype, or a true revolution?\r\n\r\nAt INBOUND, I made the case that these are not the right questions to ask or answer. Because first and foremost, go-to-market professionals are asking themselves a simpler question: how do I drive growth?\r\n\r\nAfter all, everyone seems to feel the same way: lately, it’s been harder to grow. So it’s worth understanding why it’s been so tough, what has changed in the customer journey, and answer the question: where do we grow from here?','post_featured_image/1727246097_atta_e_marketing.webp','Active',1,'2024-09-25 11:38:18','2024-09-25 11:38:18');

/*Table structure for table `post_atachment` */

DROP TABLE IF EXISTS `post_atachment`;

CREATE TABLE `post_atachment` (
  `post_atachment_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) DEFAULT NULL,
  `post_attachment_title` varchar(200) DEFAULT NULL,
  `post_attachment_path` text DEFAULT NULL,
  `is_active` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`post_atachment_id`),
  KEY `fk1` (`post_id`),
  CONSTRAINT `fk1` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post_atachment` */

insert  into `post_atachment`(`post_atachment_id`,`post_id`,`post_attachment_title`,`post_attachment_path`,`is_active`,`created_at`,`updated_at`) values 
(2,1,'Budget_1','post_attachement/624283914-Budget_1.jpg','Active','2024-09-25 10:44:37',NULL),
(3,2,'HEC_1','post_attachement/1312500922-HEC_1.jpg','Active','2024-09-25 10:46:59',NULL),
(5,5,'attachment','post_attachement/60335570-attachment.webp','Active','2024-09-25 11:38:18','2024-09-25 11:38:18');

/*Table structure for table `post_category` */

DROP TABLE IF EXISTS `post_category`;

CREATE TABLE `post_category` (
  `post_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`post_category_id`),
  KEY `post_id` (`post_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `post_category_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `post_category_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post_category` */

insert  into `post_category`(`post_category_id`,`post_id`,`category_id`,`created_at`,`updated_at`) values 
(4,1,3,'2024-09-25 10:44:37',NULL),
(5,1,2,'2024-09-25 10:44:37',NULL),
(6,1,1,'2024-09-25 10:44:37',NULL),
(7,2,3,'2024-09-25 10:46:59',NULL),
(8,2,2,'2024-09-25 10:47:00',NULL),
(9,2,1,'2024-09-25 10:47:00',NULL),
(11,5,6,'2024-09-25 11:38:19','2024-09-25 11:38:19');

/*Table structure for table `post_comment` */

DROP TABLE IF EXISTS `post_comment`;

CREATE TABLE `post_comment` (
  `post_comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `is_active` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`post_comment_id`),
  KEY `user_id` (`user_id`),
  KEY `post_id` (`post_id`),
  CONSTRAINT `post_comment_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `post_comment_ibfk_2` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post_comment` */

insert  into `post_comment`(`post_comment_id`,`post_id`,`user_id`,`comment`,`is_active`,`created_at`) values 
(1,5,1,'Great','Active','2024-09-25 09:34:53'),
(2,5,1,'Good','Active','2024-09-25 09:35:09'),
(3,5,1,'Betreen','Active','2024-09-25 09:35:36');

/*Table structure for table `role` */

DROP TABLE IF EXISTS `role`;

CREATE TABLE `role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_type` varchar(50) NOT NULL,
  `is_active` enum('Active','InActive') DEFAULT 'Active',
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `role` */

insert  into `role`(`role_id`,`role_type`,`is_active`) values 
(1,'Admin','Active'),
(2,'User','Active');

/*Table structure for table `setting` */

DROP TABLE IF EXISTS `setting`;

CREATE TABLE `setting` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `setting_key` varchar(100) DEFAULT NULL,
  `setting_value` varchar(100) DEFAULT NULL,
  `setting_status` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`setting_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `setting_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `setting` */

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` text NOT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `user_image` text DEFAULT NULL,
  `address` text DEFAULT NULL,
  `is_approved` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `is_active` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `user` */

insert  into `user`(`user_id`,`role_id`,`first_name`,`last_name`,`email`,`password`,`gender`,`date_of_birth`,`user_image`,`address`,`is_approved`,`is_active`,`created_at`,`updated_at`) values 
(1,1,'Bheesham','Lakhani','bk@gmail.com','Bklakhani12!','Male','2002-07-14','uploads/1727241257_1726864218_img_1.jpg','Karachi','Approved','Active','2024-09-25 10:15:30',NULL),
(2,2,'Safdar','Qureshi','safdar@gmail.com','Safsar123@@##','Male','2006-06-14','uploads/1727246608_img_cricket.jpg','Hyderabad','Pending','InActive','2024-09-25 11:49:23',NULL);

/*Table structure for table `user_feedback` */

DROP TABLE IF EXISTS `user_feedback`;

CREATE TABLE `user_feedback` (
  `feedback_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  `feedback` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`feedback_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_feedback_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `user_feedback` */

insert  into `user_feedback`(`feedback_id`,`user_id`,`user_name`,`user_email`,`feedback`,`created_at`) values 
(1,1,'Bheesham Lakhani','bk@gmail.com','Nice','2024-09-25 09:38:02');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
