/*
@license

dhtmlxCalendar v.8.4.2 Standard
This software is covered by GPL-2.0 License. Usage without proper license is prohibited.

(c) XB Software.
*/


Useful links
-------------

- Online  documentation
	https://docs.dhtmlx.com/