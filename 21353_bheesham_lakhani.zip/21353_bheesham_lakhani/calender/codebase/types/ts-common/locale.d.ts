export declare function setLocale(component: string, value: any): void;
