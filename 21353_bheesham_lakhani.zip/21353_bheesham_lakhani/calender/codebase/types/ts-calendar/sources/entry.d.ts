import "../../styles/calendar.scss";
import "../../styles/themes.scss";
export { tooltip } from "../../ts-message";
export { Popup } from "../../ts-popup";
export { Calendar } from "./Calendar";
export { awaitRedraw, setTheme } from "../../ts-common/dom";
export declare const i18n: any;
