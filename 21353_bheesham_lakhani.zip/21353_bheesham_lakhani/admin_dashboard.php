<?php
	// session_start();
	// error_reporting(0);
	
	if(!isset($_REQUEST['title'])&&$_REQUEST['title']!="Admin_page"){
		header("location:index.php?title=Home");
		// die;
	}

	require_once("config/class_object.php");
	include_once("header_and_footer/headers.php");
	// print_r
	
	?>
	
	<div class="container-fluid">
	    <div class="row mx-0 my-1">
	        <div class="col-sm-2 border-dark" style="background-color:#C7C7C7;">
	            <div class="flex-shrink-0 p-3" style="width: 280px;">
	                <ul class="list-unstyled ps-0">
					<a class="text_dec home_hover" href="admin_dashboard.php"><span class="fs-5 fw-semibold"><b>Dashboard</b></span></a>
	                    <li class="mb-1">
	                        <button class="btn btn-toggle d-inline-flex align-items-center rounded border-0 collapsed"
	                            data-bs-toggle="collapse" data-bs-target="#manage-blog" aria-expanded="true">
	                            Manage Blog
	                        </button>
	                        <div class="collapse" id="manage-blog">
	                            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="create()">Create Blog</a></li>
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="update()">Update Blog</a></li>
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="update_blog_status()">Update Blog status</a></li>
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="active_blog()">Active Blog</a></li>
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="inactive_blog()">Inactive Blog</a></li>
	                            </ul>
	                        </div>
	                    </li>
	                    <li class="mb-1">
	                        <button class="btn btn-toggle d-inline-flex align-items-center rounded border-0 collapsed"
	                            data-bs-toggle="collapse" data-bs-target="#category" aria-expanded="false">
	                            Manage Category
	                        </button>
	                        <div class="collapse " id="category">
	                            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="all_category()">All Category</a></li>
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="add_category()">Add Category</a></li>
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="update_category()">Update Category</a></li>
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="update_category_status()">Update Category Status</a></li>
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="active_category()">Active Category</a></li>
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="inactive_category()">Inactive Category</a></li>
	                            </ul>
	                        </div>
	                    </li>
	                    <li class="mb-1">
	                        <button class="btn btn-toggle d-inline-flex align-items-center rounded border-0 collapsed"
	                            data-bs-toggle="collapse" data-bs-target="#manage-users" aria-expanded="false">
	                            Manage Users
	                        </button>
	                        <div class="collapse" id="manage-users">
	                            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
	                            	<li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="add_user()">Add New User</a></li>
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="user_status()">User Status</a></li>
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"	
	                                				onclick="edit_user_detail()">Edit_user_detail</a></li>
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="user_request()">User Request</a></li>
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="new_user()">New Users</a></li>
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="approved_user()">Approved Users</a></li>
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="pending_user()">Pending Users</a></li>
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="rejected_user()">Rejected Users</a></li>
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="active_user()">Active Users</a></li>
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="inactive_user()">Inactive Users</a></li>
	                            </ul>
	                        </div>
	                    </li>
	                    <li class="mb-1">
	                        <button class="btn btn-toggle d-inline-flex align-items-center rounded border-0 collapsed"
	                            data-bs-toggle="collapse" data-bs-target="#manage-comments" aria-expanded="false">
	                            Manage Posts
	                        </button>
	                        <div class="collapse show" id="manage-comments">
	                            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="create_post()">Create Post</a></li>
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="update_post()">Update Post</a></li>
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="update_post_status()">Update Post Status</a></li>
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="comment_update()">Comment Action</a></li>
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="active_post()">Active Post</a></li>
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="inactive_post()">Inactive Post</a></li>
									<li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="comments_are()">Comments</a></li>

	                            </ul>
	                        </div>
	                    </li>
	                    <li class="mb-1">
	                        <button class="btn btn-toggle d-inline-flex align-items-center rounded border-0 collapsed"
	                            data-bs-toggle="collapse" data-bs-target="#manage-feedback" aria-expanded="false">
	                            Manage FeedBack
	                        </button>
	                        <div class="collapse" id="manage-feedback">
	                            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
	                                <li><a href="#" class="link-body-emphasis d-inline-flex text-decoration-none rounded"
	                                        onclick="feedback()">Feedback</a></li>
	                        </div>
	                    </li>
	                    <li class="mb-1">
	                        <button class="btn btn-toggle d-inline-flex align-items-center rounded border-0 collapsed"
	                            data-bs-toggle="collapse" data-bs-target="#Follower" aria-expanded="false">
	                            Follower
	                        </button>
	                        <div class="collapse" id="Follower">
	                            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
	                                <li><a href="#"
	                                        class="link-body-emphasis d-inline-flex text-decoration-none rounded" onclick="followers_are()">Followers</a>
	                                </li>
	                            </ul>
	                        </div>
	                    </li>
	                    <li class="mb-1">
	                        <button class="btn btn-toggle d-inline-flex align-items-center rounded border-0 collapsed"
	                            data-bs-toggle="collapse" data-bs-target="#account-collapse" aria-expanded="false">
	                            Account
	                        </button>
	                        <div class="collapse" id="account-collapse">
	                            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
	                                <li><a href="#"
	                                        class="link-body-emphasis d-inline-flex text-decoration-none rounded">Profile</a>
	                                </li>
	                                <li><a href="#"
	                                        class="link-body-emphasis d-inline-flex text-decoration-none rounded">Settings</a>
	                                </li>
	                                <li><a href="logout.php"
                                        class="link-body-emphasis d-inline-flex text-decoration-none rounded">Sign
                                        out</a></li>
	                            </ul>
	                        </div>
	                    </li>
	                </ul>
	            </div>
	        </div>
	        <div class="col-sm-10 border-dark" style="background-color:#C7C7C7;"
	            id="response_text">
	            <div class="row">
	                <div class="col-12">
	                    <h1 class="bg-dark bg-gradient text-white rounded-bottom text-center"><?=strtoupper($_COOKIE['admin_name'])?></h1>
	                </div>
						<div class="col-3"></div>
						<div class="col-6">
							<p class="rounded p-1 text-center text-white" style="background-color: <?=$_REQUEST['color']??""?>;"><?=$_REQUEST['msg']??""?></p>
						</div>
						<div class="col-3"></div>
	                <div class="col-sm-4">
	                    <div class="card m-2 bg-warning-subtle ">
	                        <div class="row">
	                            <div class="col-4 d-flex justify-content-end mt-3">
	                                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTphipBRFw5Lgt6jzuEZTKT6i9yUcBZTcrwySNrNdpnnUVJwKdtVqGLujZeAiCkZBwyuPs&usqp=CAU"
	                                    class="card-img-top rounded-pill ms-1" alt="...">
	                            </div>
	                            <div class="col-8 my-3">
	                                <h5 class="card-title">Total Blog</h5>
	                            </div>
	                        </div>
	                        <div class="row">
	                            <div class="col-12 d-flex justify-content-center">
	                                <?php 
									 $query = "SELECT COUNT(b.blog_id) 'total_blog' FROM blog b  WHERE b.user_id = '".$_SESSION['user']['user_id']."'";
									 $result = $user->execute_query($query);
									 if($result->num_rows > 0){
                                        while($row = mysqli_fetch_assoc($result)){
                                              extract($row);
										}
										?>
                                     <h1><?=$total_blog?></h1>
										<?php
									 }
									?>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	                <div class="col-sm-4">
	                    <div class="card m-2 bg-info-subtle">
	                        <div class="row">
	                            <div class="col-4 d-flex justify-content-end mt-3">
	                                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTphipBRFw5Lgt6jzuEZTKT6i9yUcBZTcrwySNrNdpnnUVJwKdtVqGLujZeAiCkZBwyuPs&usqp=CAU"
	                                    class="card-img-top rounded-pill ms-1" alt="...">
	                            </div>
	                            <div class="col-8 my-3">
	                                <h5 class="card-title">Total post</h5>
	                            </div>
	                        </div>
	                        <div class="row">
	                            <div class="col-12 d-flex justify-content-center">
								<?php 
									 $query = "SELECT COUNT(p.post_id) 'total_post' FROM post p JOIN blog ON blog.blog_id = p.blog_id WHERE blog.user_id = '".$_SESSION['user']['user_id']."' ";
									//  echo $query;
									//  die;
									 $result = $user->execute_query($query);
									 if($result->num_rows > 0){
                                        while($row = mysqli_fetch_assoc($result)){
                                              extract($row);
										}
										?>
                                     <h1><?=$total_post?></h1>
										<?php
									 }
									?>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	                <div class="col-sm-4">
	                    <div class="card m-2 bg-success-subtle ">
	                        <div class="row ">
	                            <div class="col-4 d-flex justify-content-end mt-3">
	                                <img src="icons/followers_icon.png" class="card-img-top rounded-pill ms-1" alt="...">
	                            </div>
	                            <div class="col-8 my-3">
	                                <h5 class="card-title">Followers</h5>
	                            </div>
	                        </div>
	                        <div class="row">
	                            <div class="col-12 d-flex justify-content-center">
								<?php 
									 $query = "SELECT COUNT(follow.follow_id) 'total_follower' FROM following_blog follow  JOIN blog ON follow.blog_following_id=blog.blog_id WHERE follow.status='Followed' && blog.user_id = '".$_SESSION['user']['user_id']."'";
									 $result = $user->execute_query($query);
									 if($result->num_rows > 0){
                                        while($row = mysqli_fetch_assoc($result)){
                                              extract($row);
										}
										?>
                                     <h1><?=$total_follower?></h1>
										<?php
									 }
									?>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	            <div class="row">
	                <div class="col-sm-4">
	                    <div class="card m-2 bg-info-subtle ">
	                        <div class="row">
	                            <div class="col-4 d-flex justify-content-end mt-3">
	                                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT2QrLAN2wsxqs4pilD8YvUhUHlggVbuFcWmg&s"
	                                    class="card-img-top rounded-pill ms-1" alt="...">
	                            </div>
	                            <div class="col-8 my-3">
	                                <h5 class="card-title">User Requests</h5>
	                            </div>
	                        </div>
	                        <div class="row">
	                            <div class="col-12 d-flex justify-content-center">
								<?php 
									 $query = "SELECT COUNT(user.user_id) 'total_user' FROM user WHERE is_approved='pending'&& is_active='Inactive'";
									 $result = $user->execute_query($query);
									 if($result->num_rows > 0){
                                        while($row = mysqli_fetch_assoc($result)){
                                              extract($row);
										}
										?>
                                     <h1><?=$total_user?></h1>
										<?php
									 }
									?>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	                <div class="col-sm-4">
	                    <div class="card m-2 bg-warning-subtle">
	                        <div class="row">
	                            <div class="col-4 d-flex justify-content-end mt-3">
	                                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSszMQ0dFzGSwqIBrUrGa_7RinbtfNKOgNi0A&s"
	                                    class="card-img-top rounded-pill ms-1" alt="...">
	                            </div>
	                            <div class="col-8 my-3">
	                                <h5 class="card-title">Total Users</h5>
	                            </div>
	                        </div>
	                        <div class="row">
	                            <div class="col-12 d-flex justify-content-center">
								<?php 
									 $query = "SELECT COUNT(user.user_id) 'total_user' FROM user";
									 $result = $user->execute_query($query);
									 if($result->num_rows > 0){
                                        while($row = mysqli_fetch_assoc($result)){
                                              extract($row);
										}
										?>
                                     <h1><?=$total_user?></h1>
									 <?php
									 }
									 ?>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	                <div class="col-sm-4">
	                    <div class="card m-2 bg-info-subtle ">
	                        <div class="row">
	                            <div class="col-4 d-flex justify-content-end mt-3">
	                                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTel6JlJ_oeJc6ADGDLFshZ65dXyAEd3SXcQQ&s"
	                                    class="card-img-top rounded-pill ms-1" alt="...">
	                            </div>
	                            <div class="col-8 my-3">
	                                <h5 class="card-title">Feedback</h5>
	                            </div>
	                        </div>
	                        <div class="row">
	                            <div class="col-12 d-flex justify-content-center">
								<?php 
									 $query = "SELECT COUNT(user_feedback.feedback_id) 'feedback' FROM user_feedback";
									 $result = $user->execute_query($query);
									 if($result->num_rows > 0){
                                        while($row = mysqli_fetch_assoc($result)){
                                              extract($row);
										}
										?>
                                     <h1><?=$feedback?></h1>
									 <?php
									 }
									 ?>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
				<div class="row">
	                <div class="col-sm-4">
	                    <div class="card m-2 bg-success-subtle ">
	                        <div class="row">
	                            <div class="col-4 d-flex justify-content-end mt-3">
	                                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSPxiTFS-jKSWIFhISJWbLbZ56kung5vSDWXwU2JgXuVSTbJD4GppriOVGcCLB6u2naVKA&usqp=CAU"
	                                    class="card-img-top rounded-pill ms-1" alt="...">
	                            </div>
	                            <div class="col-8 my-3">
	                                <h5 class="card-title">Active Blog</h5>
	                            </div>
	                        </div>
	                        <div class="row">
	                            <div class="col-12 d-flex justify-content-center">
								<?php 
									 $query = "SELECT COUNT(blog.blog_id) 'active_blog' FROM blog  WHERE blog.blog_status='Active' && blog.user_id = '".$_SESSION['user']['user_id']."'";
									//  echo $query;
									//  die;
									 $result = $user->execute_query($query);
									 if($result->num_rows > 0){
                                        while($row = mysqli_fetch_assoc($result)){
                                              extract($row);
										}
										?>
                                     <h1><?=$active_blog?></h1>
										<?php
									 }
									?>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	                <div class="col-sm-4">
	                    <div class="card m-2 bg-info-subtle">
	                        <div class="row">
	                            <div class="col-4 d-flex justify-content-end mt-3">
	                                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSPxiTFS-jKSWIFhISJWbLbZ56kung5vSDWXwU2JgXuVSTbJD4GppriOVGcCLB6u2naVKA&usqp=CAU"
	                                    class="card-img-top rounded-pill" alt="...">
	                            </div>
	                            <div class="col-8 my-3">
	                                <h5 class="card-title">Active Post</h5>
	                            </div>
	                        </div>
	                        <div class="row">
	                            <div class="col-12 d-flex justify-content-center">
								<?php 
									 $query = "SELECT COUNT(post.post_id) 'active_post' FROM post JOIN blog ON post.blog_id = blog.blog_id JOIN user ON user.user_id= blog.user_id WHERE user.user_id = '".$_SESSION['user']['user_id']."'";
									 $result = $user->execute_query($query);
									 if($result->num_rows > 0){
                                        while($row = mysqli_fetch_assoc($result)){
                                              extract($row);
										}
										?>
                                     <h1><?=$active_post?></h1>
									 <?php
									 }
									 ?>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	                <div class="col-sm-4">
	                    <div class="card m-2 bg-warning-subtle ">
	                        <div class="row">
	                            <div class="col-4 d-flex justify-content-end mt-3">
	                                <img src="https://st3.depositphotos.com/1688079/16412/i/450/depositphotos_164122888-stock-photo-comment-conversation-icon-elegant-blue.jpg"
	                                    class="card-img-top rounded-pill ms-1" alt="...">
	                            </div>
	                            <div class="col-8 my-3">
	                                <h5 class="card-title">Total Comments</h5>
	                            </div>
	                        </div>
	                        <div class="row">
	                            <div class="col-12 d-flex justify-content-center">
								<?php 
									 $query = "SELECT COUNT(post_comment.post_comment_id) 'total_comments' FROM post_comment  JOIN post ON post.post_id = post_comment.post_id JOIN blog ON blog.blog_id = post.blog_id WHERE blog.user_id ='".$_SESSION['user']['user_id']."'";
									 // echo $query;
									 // die;
									 $result = $user->execute_query($query);
									 if($result->num_rows > 0){
                                        while($row = mysqli_fetch_assoc($result)){
                                              extract($row);
										}
										?>
                                     <h1><?=$total_comments?></h1>
									 <?php
									 }
									 ?>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>
	</div>
	</div>

<?php
// }
// elseif(isset($_SESSION['user']['user_id'])&&$_SESSION['user']['role_id']==2){
//     header("index.php");
// }
// else{
//     header("location:login.php?msg=Please Login First...!&color=red");
// }

include_once("header_and_footer/footers.php");
// include_once("require_files/client_side_validation.php");
?>