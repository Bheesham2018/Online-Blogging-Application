<?php
require_once("config/connection.php");
$user = new blog(HOSTNAME,USERNAME,PASSWORD, DATABASE_NAME);
?>