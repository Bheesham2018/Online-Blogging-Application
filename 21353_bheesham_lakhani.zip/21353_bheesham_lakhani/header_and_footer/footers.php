</div>
	<footer class="mt-auto footer">
		<div class="container-fluid">
		<div class="row my-2 mx-0 bg-dark bg-gradient text-white rounded-bottom">
			<div class="col-sm-4 my-1 d-block" >
				<p>Links</p>
				<a href="index.php" class="d-block" style="text-decoration: none;">Home</a>
				<a href="#" class="d-block"style="text-decoration: none;">About</a>
				<a href="feedback.php" class="d-block"style="text-decoration: none;">Contact Us</a>
			</div>
			<div class="col-sm-4 my-1">
				<p>Copyright</p>
				<p>&copy; <a href="">Online Blog Management System</a> Date <i>09-04-2024</i></p>
			</div>
			<div class="col-sm-4 my-1">
				<p >Social Links</p>
				<div class="social">
				<span class="fa-brands fa-instagram"></span><a href="#" style="text-decoration: none;">Instagram</a>
				</div>
				<div class="social">
				<span class="fa-brands fa-linkedin in"></span><a href="#" style="text-decoration: none;">Linkedin</a>
				</div>
				<div class="social">
				<span class="fa-brands fa-facebook"></span><a href="#" style="text-decoration: none;">Facebook</a>
				</div>
			</div>
		</div> 
	</div>
	</footer>
<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.datatables.net/2.1.5/js/dataTables.js"></script>	
<script type="text/javascript">
    const calendar = new dhx.Calendar(null, {dateFormat: "%m/%d/%y"});
            const popup = new dhx.Popup();
            popup.attach(calendar);
            const dateInput = document.getElementById("date-input");
            dateInput.addEventListener("click", function() {
            popup.show(dateInput);
            });
            calendar.events.on("change", function() {
            dateInput.value = calendar.getValue();
            popup.hide();
            });
</script>
<script>
	function showPass($obj){

				// console.log($obj);
				// console.log($obj.checked);

				var pass = document.getElementById("password");

				// console.log(pass);
				// console.log(pass.type);

				if($obj.checked == true){

					pass.type = "text";
				}
				else{
					pass.type = "password";
				}
			}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script src="require_files/sidebars.js"></script>
<script type="text/javascript" src="require_files/jquery_select_multiple_box.js"></script>
<!-- <script type="text/javascript">	
	new DataTable('#blog');
</script> -->
</body>
</html>