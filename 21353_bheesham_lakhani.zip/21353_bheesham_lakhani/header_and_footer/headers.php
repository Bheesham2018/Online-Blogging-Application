<?php
session_start();
require_once 'require_files/ajax.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="require_files/sidebars.css">
    <script src="https://kit.fontawesome.com/f202638c65.js" crossorigin="anonymous"></script>
    <title><?= $_REQUEST['title']??"Home" ?></title>
    <link rel="stylesheet" href="https://cdn.datatables.net/2.1.5/css/dataTables.dataTables.css">
    <script type="text/javascript" src="calender/codebase/calendar.js"></script>
    <link rel="stylesheet" href="calender/codebase/calendar.css">
    <link rel="stylesheet" href="require_files/jquery_select_multiple_box.css">
</head>
<body>
    <div class="content">
    <div class="container-fluid my-2">
        <div class="row ">
            <div class="col-12 mx-0 ">
                <nav class="navbar navbar navbar-expand-lg rounded-top bg-dark bg-gradient p-1">
                    <a class="navbar-brand" href="index.php?title=Home">
                        <img src="https://e7.pngegg.com/pngimages/481/8/png-clipart-comparison-of-free-blog-hosting-services-computer-icons-blog-blogger-icon-blue-logo.png"
                            class="img-thumbnail rounded-pill" height="50" width="50" alt="...">
                    </a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                            <li class="nav-item">
                                <a class="nav-link active text-light"
                                    aria-current="page" href="index.php?title=Home">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-light"
                                    href="#about?title=about">About</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-light" href="feedback.php?title=feedback">
                                    Contact Us
                                </a>
                            </li>
                        </ul>
                        <!-- Login-btn -->
                        <?php
                        // print_r($_SESSION);
                        // die;
                        if(isset($_SESSION['user'])&&$_SESSION['user']['role_id']==2 ) {
                            ?>
                            <ul class="navbar-nav">
                                <li class="nav-item dropdown">
                                <button class="btn btn-dark dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                   <?=$_COOKIE['user_name']?>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-dark">
                                    <li><a class="dropdown-item" href="edit.php?action=edit_profile_by_user&title=Edit_Profile&user_id=<?=$_SESSION['user']['user_id']?>">Edit Profile</a></li>
                                    <li><a class="dropdown-item" href="edit.php?action=theme_setting&title=Theme_Setting&user_id=<?=$_SESSION['user']['user_id']?>">Theme Setting</a></li>
                                    <li><a class="dropdown-item" href="process.php?action=active_theme&user_id=<?=$_SESSION['user']['user_id']?>">Active Theme</a></li>
                                    <li><a class="dropdown-item" href="process.php?action=inactive_theme&user_id=<?=$_SESSION['user']['user_id']?>">InActive Theme</a></li>
                                    <li><a class="dropdown-item" href="logout.php">logout</a></li>
                                </ul>
                                </li>
                            </ul>
                            <img src="<?=$_COOKIE['user_image']?>" class="mx-2 image_size" alt="...">
                            <?php
                        }
                        elseif(isset($_SESSION['user'])&&$_SESSION['user']['role_id']==1 ){
                            $_SESSION['admin_page']="admin_page";
                            ?>
                                <li class="nav-item dropdown">
                                <button class="btn btn-dark dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                   <?=$_COOKIE['admin_name']?>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-dark">
                                    <li><a class="dropdown-item" href="admin_dashboard.php?title=Admin_Page&title=Admin_Page">Dashboard</a></li>
                                    <li><a class="dropdown-item" href="edit.php?action=edit_admin_detail&title=Edit_Profile&user_id=<?=$_SESSION['user']['user_id']?>">Profile</a></li>
                                    <li><a class="dropdown-item" href="edit.php?action=theme_setting&title=Theme_Setting&user_id=<?=$_SESSION['user']['user_id']?>">Theme Setting</a></li> 
                                    <li><a class="dropdown-item" href="process.php?action=active_theme&user_id=<?=$_SESSION['user']['user_id']?>">Active Theme</a></li>
                                    <li><a class="dropdown-item" href="process.php?action=inactive_theme&user_id=<?=$_SESSION['user']['user_id']?>">InActive Theme</a></li> 
                                    <li><a class="dropdown-item" href="#">Setting</a></li>
                                    <li><a class="dropdown-item" href="logout.php">logout</a></li>
                                </ul>
                                </li>
                            </ul>
                            <img src="<?=$_COOKIE['admin_image']?>" class="mx-2 image_size" alt="...">
                            <?php
                        }
                        else{
                        ?>
                        <a href="login.php?title=Login" class="btn btn-primary" style="margin-right: 3px;" >Login</a>
                        <a href="register_form.php?title=Register" class="btn btn-primary" style="margin-right: 3px;">Register</a>
                        <?php
                        }
                        ?>
                    </div>
                </nav>
            </div>
        </div>
    </div>